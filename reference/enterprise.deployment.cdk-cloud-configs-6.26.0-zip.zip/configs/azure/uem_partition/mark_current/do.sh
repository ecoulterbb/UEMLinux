#!/usr/bin/env bash
set -o errexit

source functions_cdktools.sh

bash wait_for_uos_quorum.sh

TF_STATE="../../../../azure-uem_partition-mark_current-terraform.tfstate"

echo "Marking new partition current..."
terraform init -input=false -plugin-dir=/opt/uemcloud/deploy/cdktools/terraform-plugins -upgrade
terraform_retry apply -input=false -auto-approve=true -state=$TF_STATE

bash bash_wait_for_wafl_uemcloud.sh
