#!/usr/bin/env bash
source bash_env.sh

function wait_for_uos_quorum() {
    SERVICE=$1
    UOS_QUORUM=$2
    BACKEND_VERSIONED=$3

    if [ -z "${UOS_QUORUM}" ]; then
        echo "No quorum set for UoS ${SERVICE^^}, moving on."
        return 0
    fi

    if [ -z "${UOS_COUNT}" ]; then
        echo "No uos count set for UoS ${SERVICE^^}, moving on."
        return 0
    fi

    if [ "${UOS_QUORUM}" -gt "${UOS_COUNT}" ]; then
        echo "[ERROR] UoS ${SERVICE^^} quorum ${UOS_QUORUM} cannot be greater than ${UOS_COUNT} total nodes."
        exit 1
    fi

    echo "Waiting for a quorum of ${UOS_QUORUM} out of ${UOS_COUNT} for UoS ${SERVICE^^}"
    while true; do
        BACKEND_VERSIONED_COUNT=$(dig +short -t A ${BACKEND_VERSIONED} | wc -w)
        if [ "$BACKEND_VERSIONED_COUNT" -ge "$UOS_QUORUM" ]; then
            echo "UoS quorum met, moving on."
            break
        else
            echo "UoS IP addresses detected for ${BACKEND_VERSIONED}: $(dig +short -t A ${BACKEND_VERSIONED})"
            sleep 30
        fi
    done
}

if [ "${DEPLOYMENT_START_CORE,,}" != "true" ]; then
    echo "Not waiting for UoS CORE quorum because CORE service is not configured to start."
else
    wait_for_uos_quorum 'core' "${UOS_CORE_QUORUM}" "${BACKEND_CORE_VERSIONED}."

    if [ "${DEPLOYMENT_START_UI,,}" != "true" ]; then
        echo "Not waiting for UoS UI quorum because UI service is not configured to start."
    else
        wait_for_uos_quorum 'ui' "${UOS_UI_QUORUM}" "${BACKEND_UI_VERSIONED}."
    fi
fi
