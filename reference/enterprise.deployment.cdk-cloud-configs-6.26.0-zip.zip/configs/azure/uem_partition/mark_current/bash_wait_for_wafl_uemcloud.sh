#!/usr/bin/env bash
source bash_env.sh

function wait_for_wafl() {
    SERVICE=$1
    POOL_SERVICE_URL=$2
    BACKEND_VERSIONED=$3

    echo "Waiting for an active WAFL node connected to current version of ${SERVICE}"
    while true; do
        POOL_SERVICE_VERSION=$(curl -x "" -s -m 5 "${POOL_SERVICE_URL}")
        if [ "$POOL_SERVICE_VERSION" == "$BACKEND_VERSIONED" ]; then
            echo "done."
            break
        else
            echo -n '.'
            sleep 5
        fi
    done
}

if [ "${DEPLOYMENT_START_CORE,,}" != "true" ]; then
    echo "Not waiting for any active WAFL nodes because core service is not configured to start."
else
    wait_for_wafl 'core' "http://${UOS_POOL_FQDN_INTERNAL}:1${CORE_HEALTHCHECK_PORT}/health/service_core.html" "${BACKEND_CORE_VERSIONED}."

    if [ "${DEPLOYMENT_START_UI,,}" != "true" ]; then
        echo "Not waiting for ui service because it is not configured to start."
    else
        wait_for_wafl 'ui' "http://${UOS_POOL_FQDN_INTERNAL}:1${UI_HEALTHCHECK_PORT}/health/service_ui.html" "${BACKEND_UI_VERSIONED}."
    fi
fi
