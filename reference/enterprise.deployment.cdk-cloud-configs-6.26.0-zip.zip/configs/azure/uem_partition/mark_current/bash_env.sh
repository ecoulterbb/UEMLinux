#!/usr/bin/env bash

export BACKEND_CORE_VERSIONED='${EPF::uos_backend_core_versioned}'
export BACKEND_UI_VERSIONED='${EPF::uos_backend_ui_versioned}'
export CORE_HEALTHCHECK_PORT='${EPF::core_healthcheck_port}'
export DEPLOYMENT_START_CORE='${EPF::deployment_start_core}'
export DEPLOYMENT_START_UI='${EPF::deployment_start_ui}'
export UI_HEALTHCHECK_PORT='${EPF::ui_healthcheck_port}'
export UOS_POOL_FQDN_INTERNAL='${EPF::uos_pool_fqdn_internal_hc}'
export UOS_COUNT='${EPF::uos_count}'
export UOS_CORE_QUORUM='${EPF::uos_core_quorum}'
export UOS_UI_QUORUM='${EPF::uos_ui_quorum}'