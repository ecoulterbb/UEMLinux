#!/usr/bin/env bash
set -o errexit

source functions_cdktools.sh

TF_STATE="../../../../azure-uem_partition-mark_current-terraform.tfstate"

if [ -f "$TF_STATE" ]; then
    terraform init -input=false -plugin-dir=/opt/uemcloud/deploy/cdktools/terraform-plugins -upgrade
    terraform_retry destroy -force -state=$TF_STATE
else
    echo "Skipping as state file $TF_STATE was not found."
fi
