#!/usr/bin/env bash

terraform_retry_import() {
    TF_STATE=${TF_STATE:-terraform.tfstate}

    # if VM doesn't exist in state, try importing so any previous failed copy will be cleaned up on retry
    if ! terraform state list -state=$TF_STATE | grep -F azurerm_virtual_machine_scale_set.uemuos; then
        terraform import -state=$TF_STATE azurerm_virtual_machine_scale_set.uemuos "/subscriptions/${EPF::azure_subscription_id}/resourceGroups/${EPF::azure_uemuos_resource_group}/providers/Microsoft.Compute/virtualMachineScaleSets/${EPF::epf_partition_name}-uos-${EPF::bundle_version}d${EPF::deployment_version}" || true
    fi

    if ! terraform state list -state=$TF_STATE | grep -F azurerm_virtual_machine_scale_set.uemuosui; then
        terraform import -state=$TF_STATE azurerm_virtual_machine_scale_set.uemuos "/subscriptions/${EPF::azure_subscription_id}/resourceGroups/${EPF::azure_uemuos_resource_group}/providers/Microsoft.Compute/virtualMachineScaleSets/${EPF::epf_partition_name}-uosui-${EPF::bundle_version}d${EPF::deployment_version}" || true
    fi

    if ! terraform state list -state=$TF_STATE | grep -F azurerm_virtual_machine_scale_set.uemuosegress; then
        terraform import -state=$TF_STATE azurerm_virtual_machine_scale_set.uemuos "/subscriptions/${EPF::azure_subscription_id}/resourceGroups/${EPF::azure_uemuos_resource_group}/providers/Microsoft.Compute/virtualMachineScaleSets/${EPF::epf_partition_name}-uos-${EPF::bundle_version}d${EPF::deployment_version}" || true
    fi

    if ! terraform state list -state=$TF_STATE | grep -F azurerm_virtual_machine_scale_set.uemuosuiegress; then
        terraform import -state=$TF_STATE azurerm_virtual_machine_scale_set.uemuos "/subscriptions/${EPF::azure_subscription_id}/resourceGroups/${EPF::azure_uemuos_resource_group}/providers/Microsoft.Compute/virtualMachineScaleSets/${EPF::epf_partition_name}-uosui-${EPF::bundle_version}d${EPF::deployment_version}" || true
    fi

    if ! terraform state list -state=$TF_STATE | grep -F azurerm_virtual_machine_scale_set.uemwafl; then
        terraform import -state=$TF_STATE azurerm_virtual_machine_scale_set.uemwafl "/subscriptions/${EPF::azure_subscription_id}/resourceGroups/${EPF::azure_uemwafl_resource_group}/providers/Microsoft.Compute/virtualMachineScaleSets/${EPF::epf_partition_name}-wafl-${EPF::bundle_version}d${EPF::deployment_version}" || true
    fi
}

terraform_retry_cleanup() {
    #import any objects that were created prior to the error state
    terraform_retry_import

    TF_STATE=${TF_STATE:-terraform.tfstate}
    # if there was a transient error, we should start from scratch
    echo "Destroying failed infrastructure..."
    terraform destroy -force -state=$TF_STATE
}

function clear_dns_pool () {
    BACKEND_VERSIONED=$1
    [ "${BACKEND_VERSIONED}" == "." ] && return 0

    if [ -f /etc/default/bbddns ]; then
        export $(sudo cat /etc/default/bbddns | grep -v "#" | xargs)
    fi

    [ -n "${TSIG_FWD}" ] && FWD_TSIG="-y ${TSIG_FWD}"
    [ -n "${DDNS_ANYCAST}" ] && DDNS_ANYCONF="server ${DDNS_ANYCAST}"

    echo "Clearing DNS A record ${BACKEND_VERSIONED}"
            /usr/bin/nsupdate -d ${FWD_TSIG} <<EOF
${DDNS_ANYCONF}
zone $DDNS_ZONE.
update delete ${BACKEND_VERSIONED} A
send
EOF
}

function clear_backend_uem_dns_pools () {
    echo "DNS Pool Clear script starting"

    # DNS pools to clear
    clear_dns_pool "${EPF::uos_backend_core_versioned}."
    clear_dns_pool "${EPF::uos_backend_ui_versioned}."

    echo "DNS Pool Clear script finished"
}

function clear_backend_node_dns_records () {
    set +o errexit
    TF_STATE=${TF_STATE:-terraform.tfstate}
    terraform state list -state=$TF_STATE | grep azurerm_virtual_machine_scale_set >/dev/null
    if [[ $? -ne 0 ]] ; then
        echo "DNS Computer Names Clear script skipped"
        return 0
    fi
    set -o errexit

    echo "DNS Computer Names Clear script starting"
    source az_get_computer_names.sh

    # DNS nodes to clear
    set +o errexit
    for NODE in ${BACKEND_COMPUTER_NAMES}; do
      clear_dns_pool "${NODE}.${DNS_INTERNAL_ZONE}."
    done
    set -o errexit

    echo "DNS Computer Names Clear script finished"
}

function update_client_secret_monitoring () {
    echo "Updating client secret monitoring records"
    mkdir -p /opt/uemcloud/.cs_monitoring
    echo $TF_VAR_azure_client_secret_key_id > /opt/uemcloud/.cs_monitoring/${EPF::epf_partition_name}.key_id.txt
    echo $TF_VAR_azure_client_secret_end_date > /opt/uemcloud/.cs_monitoring/${EPF::epf_partition_name}.end_date.txt
    chmod -R 755 /opt/uemcloud/.cs_monitoring
}

if [ ${EPF::uosui_count} -eq 0 ]; then
    export DEPLOY_UOS_UI=false
    export TF_VAR_azure_uemuosui=false
else
    export DEPLOY_UOS_UI=true
    export TF_VAR_azure_uemuosui=true
fi

if [ "${EPF::disable_wafl_maintenance_page}" == "true" ]; then
    export DISABLE_MAINTENANCE_PAGE_REWRITE=true
else
    export DISABLE_MAINTENANCE_PAGE_REWRITE=false
fi

export UOS_UI_JAVA_MEM_ARG=${EPF::uosui_java_vm_memory_args}
