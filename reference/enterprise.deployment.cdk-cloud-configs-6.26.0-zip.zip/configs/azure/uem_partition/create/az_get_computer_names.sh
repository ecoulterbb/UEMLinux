#!/usr/bin/env bash
set -o errexit
source az_env.sh

trap 'bash az_logout.sh' INT TERM EXIT
bash az_login.sh

# UOS
BACKEND_COMPUTER_NAMES=$(az_retry 60 vmss list-instances --ids /subscriptions/${AZURE_SUBSCRIPTION_ID}/resourceGroups/${AZURE_UOS_RESOURCE_GROUP}/providers/Microsoft.Compute/virtualMachineScaleSets/${PARTITION_NAME}-uos-${PARTITION_VERSION} --query '[].osProfile.computerName' --output tsv || true)

# UOSUI
if [ ${EPF::uosui_count} -ne 0 ]; then
    BACKEND_COMPUTER_NAMES=$(az_retry 60 vmss list-instances --ids /subscriptions/${AZURE_SUBSCRIPTION_ID}/resourceGroups/${AZURE_UOS_RESOURCE_GROUP}/providers/Microsoft.Compute/virtualMachineScaleSets/${PARTITION_NAME}-uosui-${PARTITION_VERSION} --query '[].osProfile.computerName' --output tsv || true)
fi

# WAFL
BACKEND_COMPUTER_NAMES="${BACKEND_COMPUTER_NAMES}"$'\n'"$(az_retry 60 vmss list-instances --ids /subscriptions/${AZURE_SUBSCRIPTION_ID}/resourceGroups/${AZURE_WAFL_RESOURCE_GROUP}/providers/Microsoft.Compute/virtualMachineScaleSets/${PARTITION_NAME}-wafl-${PARTITION_VERSION} --query '[].osProfile.computerName' --output tsv || true)"

export BACKEND_COMPUTER_NAMES
