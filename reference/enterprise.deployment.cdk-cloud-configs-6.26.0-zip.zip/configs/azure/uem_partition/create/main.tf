variable "apt_server" {}

variable "azure_asset_keyvault_client_secret_encrypted" {}
variable "azure_client_id" {}
variable "azure_client_secret" {}
variable "azure_deploy_keyvault_encryption_cert_thumbprint" {}
variable "azure_deploy_keyvault_encryption_cert_url" {}
variable "azure_deploy_keyvault_wafl_cert_chain_pem" {}
variable "azure_deploy_keyvault_wafl_cert_thumbprint" {}
variable "azure_deploy_keyvault_wafl_cert_url" {}
variable "azure_deploy_keyvault_id" {}
variable "azure_environment" {}
variable "azure_location" {}
variable "azure_managed_disk_type" {}
variable "azure_subscription_id" {}
variable "azure_tags" { type = "map" }
variable "azure_tenant_id" {}

variable "azure_uemuos_availability_zones" { type = "list" }
variable "azure_uemuos_bootdiag_enabled" {}
variable "azure_uemuos_bootdiag_storage_account_uri" {}
variable "azure_uemuos_resource_group" {}
variable "azure_uemuos_subnet_id" {}
variable "azure_uemuos_vm_size" {}
variable "azure_uemuos_vmss_capacity" {}
variable "azure_uemuos_vmss_nsg_id" {}

variable "azure_uemuosui" {}
variable "azure_uemuosui_vm_size" {}
variable "azure_uemuosui_vmss_capacity" {}

variable "azure_uemwafl_availability_zones" { type = "list" }
variable "azure_uemwafl_bootdiag_enabled" {}
variable "azure_uemwafl_bootdiag_storage_account_uri" {}
variable "azure_uemwafl_resource_group" {}
variable "azure_uemwafl_subnet_id" {}
variable "azure_uemwafl_vm_size" {}
variable "azure_uemwafl_vmss_capacity" {}
variable "azure_uemwafl_vmss_nsg_id" {}

variable "egress_lb" {}
variable "env_type" {}

variable "fluent_bit_enabled" {}
variable "fluent_bit_cert_path" {}
variable "fluent_bit_key_path" {}
variable "fluent_bit_custom_include" {}
variable "fluent_bit_custom_include_path" {}
variable "fluent_bit_syslog_to_kafka" {}

variable "hold_packages" {}

variable "nexpose_alt_account" {}

variable "partition_name" {}
variable "partition_version" {}

variable "rapid7_cfg_file" {}

variable "smtp_sparkpost_enabled" {}

variable "ssh_allowed_groups" { type = "list" }

variable "ua_token" {}

variable "uos_core_healthcheck_port" {}
variable "uos_core_i2c_basic_port" {}
variable "uos_jmxcollector_uemcloud_core_defaults" {}
variable "uos_jmxcollector_uemcloud_core_properties" {}
variable "uos_jmxcollector_uemcloud_ui_defaults" {}
variable "uos_jmxcollector_uemcloud_ui_properties" {}
variable "uos_jmx_exporter_uemcloud_core_defaults" {}
variable "uos_jmx_exporter_uemcloud_core_yaml" {}
variable "uos_jmx_exporter_uemcloud_ui_defaults" {}
variable "uos_jmx_exporter_uemcloud_ui_yaml" {}
variable "uos_password" {}
variable "uos_ui_healthcheck_port" {}
variable "uos_ui_pool_port" {}

variable "wafl_naxsi_rules_api" {}
variable "wafl_naxsi_rules_core_i2c_basic" {}
variable "wafl_naxsi_rules_ui" {}

variable "whitelight_enabled" {}

variable "zabbix_psk" {}
variable "zabbix_psk_identity" {}

#### COMMON ####

data "terraform_remote_state" "image_info" {
    backend = "local"

    config {
        path = "${path.module}/../bake/image_info/terraform.tfstate"
    }
}

data "terraform_remote_state" "uempartition_prepare" {
    backend = "local"

    config {
        path = "${path.module}/../../../../azure-uem_partition-prepare-terraform.tfstate"
    }
}

data "template_file" "cloudinit_userdata_zabbix_psk" {
    template = "${var.zabbix_psk == "" ? "" : file("${path.module}/cloudinit_userdata_zabbix_psk.tpl")}"
    vars = {
        zabbix_psk = "${base64encode(var.zabbix_psk)}"
        zabbix_psk_identity = "${var.zabbix_psk_identity}"
        zabbix_psk_ar_script = "${base64encode(file("${path.module}/zabbix_psk_ar.sh"))}"
    }
}

data "template_file" "cloudinit_userdata_server_info" {
    template = "${file("${path.module}/cloudinit_userdata_bb-server-info.tpl")}"
    vars = {
        server_info = "${base64encode(file("${path.module}/bb-server-info.txt"))}"
    }
}

data "template_file" "cloudinit_userdata_hold_packages" {
    template = "${var.hold_packages == "" ? "" : file("${path.module}/cloudinit_userdata_hold_packages.tpl")}"
    vars = {
        hold_packages = "${var.hold_packages}"
    }
}

data "template_file" "cloudinit_userdata_ubuntu_advantage" {
    template = "${var.ua_token == "" ? "" : file("${path.module}/cloudinit_userdata_ubuntu_advantage.tpl")}"
    vars = {
        ua_token = "${var.ua_token}"
    }
}

data "template_file" "cloudinit_userdata_nexpose" {
    template = "${var.nexpose_alt_account == "" ? "" : file("${path.module}/cloudinit_userdata_nexpose.tpl")}"
    vars = {
        nexpose_alt_account = "${var.nexpose_alt_account}"
    }
}

data "template_file" "cloudinit_userdata_rapid7_cfg" {
    template = "${var.rapid7_cfg_file == "/dev/null" ? "" : file("${path.module}/cloudinit_userdata_rapid7_cfg.tpl")}"
    vars = {
        rapid7_cfg = "${var.rapid7_cfg_file == "/dev/null" ? "" : base64encode(file("${var.rapid7_cfg_file}"))}"
    }
}


#### WAFL ####

data "template_file" "uemwafl_cloudinit_userdata" {
    template = "${file("${path.module}/cloudinit_userdata_uemwafl_azure.tpl")}"

    vars {
        apt_server = "${var.apt_server}"
        cert_chain_pem = "${base64encode(file("${var.azure_deploy_keyvault_wafl_cert_chain_pem}"))}"
        cert_path_prefix = "/var/lib/waagent/${var.azure_deploy_keyvault_wafl_cert_thumbprint}"
        encoded_fluentbit_env = "${base64encode(file("${path.module}/fluent-bit.wafl.env"))}"
        encoded_fluentbit_yaml = "${base64encode(file("${path.module}/fluent-bit.wafl.yaml"))}"
        encoded_fluentbit_cert = "${base64encode(file("${var.fluent_bit_cert_path}"))}"
        encoded_fluentbit_key = "${base64encode(file("${var.fluent_bit_key_path}"))}"
        encoded_fluentbit_include = "${var.fluent_bit_custom_include == "true" ? base64encode(file("${var.fluent_bit_custom_include_path}")) : var.fluent_bit_syslog_to_kafka == "true" ? base64encode(file("${path.module}/fluent-bit-include.syslog.yaml")) : base64encode(file("${path.module}/fluent-bit-include.null.yaml"))}"
        encoded_rsyslog_conf = "${var.fluent_bit_enabled == "true" ? base64encode(file("${path.module}/90-uemcloud-wafl.fluent-bit.conf")) : base64encode(file("${path.module}/90-uemcloud-wafl.conf")) }"
        encoded_wafl_clean_dns_sh = "${base64encode(file("${path.module}/wafl_clean_dns.sh"))}"
        encoded_wafl_health_sh = "${base64encode(file("${path.module}/wafl_health_uemcloud.sh"))}"
        encoded_wafl_init_worker = "${base64encode(file("${path.module}/wafl_init_worker_uemcloud.lua"))}"
        naxsi_uemcloud_api_rules = "${base64encode(file("${var.wafl_naxsi_rules_api}"))}"
        naxsi_uemcloud_core_i2c_basic_rules = "${base64encode(file("${var.wafl_naxsi_rules_core_i2c_basic}"))}"
        naxsi_uemcloud_ui_rules = "${base64encode(file("${var.wafl_naxsi_rules_ui}"))}"
        nginx_conf = "${base64encode(file("${path.module}/nginx.conf"))}"
        ssh_groups = "${base64encode(join("\n", var.ssh_allowed_groups))}"
        sudo_rules = "${base64encode(join("\n", formatlist("%%%s ALL=(ALL) ALL", var.ssh_allowed_groups)))}"
        whitelight_conf = "${base64encode(data.template_file.uemwafl_whitelight_conf.rendered)}"
    }
}

data "template_cloudinit_config" "uemwafl_cloudinit_userdata" {
    gzip = true
    base64_encode = true

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.uemwafl_cloudinit_userdata.rendered}"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_zabbix_psk.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_server_info.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_hold_packages.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_ubuntu_advantage.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_nexpose.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_rapid7_cfg.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${var.whitelight_enabled ? "" : file("${path.module}/cloudinit_userdata_whitelight_disable.tpl")}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }
}

data "template_file" "uemwafl_whitelight_conf" {
    template = "${file("${path.module}/whitelight-uemcloud.conf.tpl")}"

    vars {
        uemuos_core_i2c_basic_port = "${var.uos_core_i2c_basic_port}"
        uemuos_ui_pool_port = "${var.uos_ui_pool_port}"
        uemwafl_hc_core_port = "1${var.uos_core_healthcheck_port}"
        uemwafl_hc_ui_port = "1${var.uos_ui_healthcheck_port}"
    }
}

resource "azurerm_virtual_machine_scale_set" "uemwafl" {
    name = "${var.partition_name}-wafl-${var.partition_version}"
    location = "${var.azure_location}"
    overprovision = false
    resource_group_name = "${var.azure_uemwafl_resource_group}"
    upgrade_policy_mode = "Manual"
    zones = "${var.azure_uemwafl_availability_zones}"

    sku {
        name = "${var.azure_uemwafl_vm_size}"
        tier = "Standard"
        capacity = "${var.azure_uemwafl_vmss_capacity}"
    }

    os_profile {
        computer_name_prefix = "${var.partition_name}-wafl-${var.partition_version}-"
        custom_data = "${data.template_cloudinit_config.uemwafl_cloudinit_userdata.rendered}"
        admin_username = "disabledbygts"
        admin_password = "DisabledByGTS1!"
    }

    os_profile_linux_config {
        disable_password_authentication = false
    }

    os_profile_secrets {
        source_vault_id = "${var.azure_deploy_keyvault_id}"
        vault_certificates {
            certificate_url = "${var.azure_deploy_keyvault_wafl_cert_url}"
        }
    }

    network_profile {
        name = "${var.partition_name}-wafl-nic"
        network_security_group_id = "${var.azure_uemwafl_vmss_nsg_id}"
        primary = true

        ip_configuration {
            name = "${var.partition_name}-wafl-ipcf"
            primary = true
            subnet_id = "${var.azure_uemwafl_subnet_id}"
            load_balancer_backend_address_pool_ids = [
                "${data.terraform_remote_state.uempartition_prepare.lb_internal_wafl_bap_id}",
                "${data.terraform_remote_state.uempartition_prepare.lb_public_wafl_bap_id}"
            ]
        }
    }

    storage_profile_image_reference {
        id = "${data.terraform_remote_state.image_info.baked_wafl_id}"
    }

    storage_profile_os_disk {
        caching = "ReadWrite"
        create_option = "FromImage"
        managed_disk_type = "${var.azure_managed_disk_type}"
    }

    boot_diagnostics {
        enabled = "${var.azure_uemwafl_bootdiag_enabled}"
        storage_uri = "${var.azure_uemwafl_bootdiag_storage_account_uri}"
    }

    tags = "${merge(
                var.azure_tags,
                map("bb:component", "wafl"),
                map("uemcloud.owner_hostname", trimspace(file("/etc/hostname")))
            )}"

}


#### UOS ####

data "template_file" "uemuos_cloudinit_userdata" {
    template = "${file("${path.module}/cloudinit_userdata_uemuos_azure.tpl")}"

    vars {
        apt_server = "${var.apt_server}"
        cert_thumbprint = "${var.azure_deploy_keyvault_encryption_cert_thumbprint}"
        client_secret_encrypted = "${var.azure_asset_keyvault_client_secret_encrypted}"
        encoded_dns_pool_member_add = "${base64encode(file("${path.module}/dns_pool_member_add.sh"))}"
        encoded_fluentbit_env = "${base64encode(file("${path.module}/fluent-bit.uos.env"))}"
        encoded_fluentbit_yaml = "${base64encode(file("${path.module}/fluent-bit.uos.yaml"))}"
        encoded_fluentbit_cert = "${base64encode(file("${var.fluent_bit_cert_path}"))}"
        encoded_fluentbit_key = "${base64encode(file("${var.fluent_bit_key_path}"))}"
        encoded_fluentbit_include = "${var.fluent_bit_custom_include == "true" ? base64encode(file("${var.fluent_bit_custom_include_path}")) : var.fluent_bit_syslog_to_kafka == "true" ? base64encode(file("${path.module}/fluent-bit-include.syslog.yaml")) : base64encode(file("${path.module}/fluent-bit-include.null.yaml"))}"
        encoded_rsyslog_conf = "${var.fluent_bit_enabled == "true" ? base64encode(file("${path.module}/90-uemcloud-uos.fluent-bit.conf")) : base64encode(file("${path.module}/90-uemcloud-uos.conf")) }"
        jmxcollector_uemcloud_core_defaults = "${base64encode(file("${var.uos_jmxcollector_uemcloud_core_defaults}"))}"
        jmxcollector_uemcloud_core_properties = "${base64encode(file("${var.uos_jmxcollector_uemcloud_core_properties}"))}"
        jmxcollector_uemcloud_ui_defaults = "${base64encode(file("${var.uos_jmxcollector_uemcloud_ui_defaults}"))}"
        jmxcollector_uemcloud_ui_properties = "${base64encode(file("${var.uos_jmxcollector_uemcloud_ui_properties}"))}"
        jmx_exporter_uemcloud_core_defaults = "${base64encode(file("${var.uos_jmx_exporter_uemcloud_core_defaults}"))}"
        jmx_exporter_uemcloud_core_yaml = "${base64encode(file("${var.uos_jmx_exporter_uemcloud_core_yaml}"))}"
        jmx_exporter_uemcloud_ui_defaults = "${base64encode(file("${var.uos_jmx_exporter_uemcloud_ui_defaults}"))}"
        jmx_exporter_uemcloud_ui_yaml = "${base64encode(file("${var.uos_jmx_exporter_uemcloud_ui_yaml}"))}"
        log4j_properties = "/opt/uemcloud/CoreUILinux/etc/besngHome/logger/log4j.properties"
        machine_properties = "${base64encode(file("${path.module}/machine.properties.uemuos"))}"
        postgres_root_cert = "${base64encode(file("/opt/uemcloud/.postgresql/root.crt"))}"
        ssh_authorized_key = "${file("/opt/uemcloud/.ssh/id_rsa.pub")}"
        ssh_users = "${base64encode("uemcloud")}"
        ssh_groups = "${base64encode(join("\n", var.ssh_allowed_groups))}"
        sudo_rules = "${base64encode("uemcloud ALL=(ALL) ALL\n${join("\n", formatlist("%%%s ALL=(ALL) ALL", var.ssh_allowed_groups))}")}"
        user_lock_passwd = "${var.env_type == "lab" ? false : true}"
        user_passwd = "${var.env_type == "lab" ? var.uos_password : ""}"
    }
}

data "template_file" "uemuos_cloudinit_postfix" {
    template = "${var.smtp_sparkpost_enabled == "true" ? file("${path.module}/cloudinit_userdata_postfix_sparkpost.tpl") : file("${path.module}/cloudinit_userdata_postfix.tpl")}"

    vars {
        encoded_main_cf = "${base64encode(file("${path.module}/smtp_main.cf"))}"
        encoded_sender_access = "${base64encode(file("${path.module}/smtp_sender_access"))}"
        encoded_sender_canonical_maps = "${base64encode(file("${path.module}/smtp_sender_canonical_maps"))}"
    }
}

data "template_cloudinit_config" "uemuos_cloudinit_userdata" {
    gzip = true
    base64_encode = true

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.uemuos_cloudinit_postfix.rendered}"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.uemuos_cloudinit_userdata.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_zabbix_psk.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_server_info.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_hold_packages.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_ubuntu_advantage.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_nexpose.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_rapid7_cfg.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${var.whitelight_enabled ? "" : file("${path.module}/cloudinit_userdata_whitelight_disable.tpl")}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }
}

resource "azurerm_virtual_machine_scale_set" "uemuos" {
    count = "${lower(var.egress_lb) == "true" ? 0 : 1}"
    name = "${var.partition_name}-uos-${var.partition_version}"
    location = "${var.azure_location}"
    overprovision = false
    resource_group_name = "${var.azure_uemuos_resource_group}"
    upgrade_policy_mode = "Manual"
    zones = "${var.azure_uemuos_availability_zones}"

    sku {
        name = "${var.azure_uemuos_vm_size}"
        tier = "Standard"
        capacity = "${var.azure_uemuos_vmss_capacity}"
    }

    os_profile {
        computer_name_prefix = "${var.partition_name}-uos-${var.partition_version}-"
        custom_data = "${data.template_cloudinit_config.uemuos_cloudinit_userdata.rendered}"
        admin_username = "disabledbygts"
        admin_password = "DisabledByGTS1!"
    }

    os_profile_linux_config {
        disable_password_authentication = false
    }

    os_profile_secrets {
        source_vault_id = "${var.azure_deploy_keyvault_id}"
        vault_certificates {
            certificate_url = "${var.azure_deploy_keyvault_encryption_cert_url}"
        }
    }

    network_profile {
        name = "uemuos-vmss-nic"
        network_security_group_id = "${var.azure_uemuos_vmss_nsg_id}"
        primary = true

        ip_configuration {
            name = "uemuos-vmss-ipcf"
            primary = true
            subnet_id = "${var.azure_uemuos_subnet_id}"
        }
    }

    storage_profile_image_reference {
        id = "${data.terraform_remote_state.image_info.baked_uos_id}"
    }

    storage_profile_os_disk {
        caching = "ReadWrite"
        create_option = "FromImage"
        managed_disk_type = "${var.azure_managed_disk_type}"
    }

    boot_diagnostics {
        enabled = "${var.azure_uemuos_bootdiag_enabled}"
        storage_uri = "${var.azure_uemuos_bootdiag_storage_account_uri}"
    }

    tags = "${merge(
                var.azure_tags,
                map("bb:component", "uos"),
                map("uemcloud.owner_hostname", trimspace(file("/etc/hostname")))
            )}"

}

resource "azurerm_virtual_machine_scale_set" "uemuosegress" {
    count = "${lower(var.egress_lb) == "true" ? 1 : 0}"
    name = "${var.partition_name}-uos-${var.partition_version}"
    location = "${var.azure_location}"
    overprovision = false
    resource_group_name = "${var.azure_uemuos_resource_group}"
    upgrade_policy_mode = "Manual"
    zones = "${var.azure_uemuos_availability_zones}"

    sku {
        name = "${var.azure_uemuos_vm_size}"
        tier = "Standard"
        capacity = "${var.azure_uemuos_vmss_capacity}"
    }

    os_profile {
        computer_name_prefix = "${var.partition_name}-uos-${var.partition_version}-"
        custom_data = "${data.template_cloudinit_config.uemuos_cloudinit_userdata.rendered}"
        admin_username = "disabledbygts"
        admin_password = "DisabledByGTS1!"
    }

    os_profile_linux_config {
        disable_password_authentication = false
    }

    os_profile_secrets {
        source_vault_id = "${var.azure_deploy_keyvault_id}"
        vault_certificates {
            certificate_url = "${var.azure_deploy_keyvault_encryption_cert_url}"
        }
    }

    network_profile {
        name = "uemuos-vmss-nic"
        network_security_group_id = "${var.azure_uemuos_vmss_nsg_id}"
        primary = true

        ip_configuration {
            name = "uemuos-vmss-ipcf"
            primary = true
            subnet_id = "${var.azure_uemuos_subnet_id}"
            load_balancer_backend_address_pool_ids = [
                "${data.terraform_remote_state.uempartition_prepare.lb_public_egress_bap_id}"
            ]
        }
    }

    storage_profile_image_reference {
        id = "${data.terraform_remote_state.image_info.baked_uos_id}"
    }

    storage_profile_os_disk {
        caching = "ReadWrite"
        create_option = "FromImage"
        managed_disk_type = "${var.azure_managed_disk_type}"
    }

    boot_diagnostics {
        enabled = "${var.azure_uemuos_bootdiag_enabled}"
        storage_uri = "${var.azure_uemuos_bootdiag_storage_account_uri}"
    }

    tags = "${merge(
                var.azure_tags,
                map("bb:component", "uos"),
                map("uemcloud.owner_hostname", trimspace(file("/etc/hostname")))
            )}"

}

#### UOSUI ####

data "template_file" "uemuosui_cloudinit_userdata" {
    template = "${file("${path.module}/cloudinit_userdata_uemuos_azure.tpl")}"

    vars {
        apt_server = "${var.apt_server}"
        cert_thumbprint = "${var.azure_deploy_keyvault_encryption_cert_thumbprint}"
        client_secret_encrypted = "${var.azure_asset_keyvault_client_secret_encrypted}"
        encoded_dns_pool_member_add = "${base64encode(file("${path.module}/dns_pool_member_add.sh"))}"
        encoded_fluentbit_env = "${base64encode(file("${path.module}/fluent-bit.uos.env"))}"
        encoded_fluentbit_yaml = "${base64encode(file("${path.module}/fluent-bit.uos.yaml"))}"
        encoded_fluentbit_cert = "${base64encode(file("${var.fluent_bit_cert_path}"))}"
        encoded_fluentbit_key = "${base64encode(file("${var.fluent_bit_key_path}"))}"
        encoded_fluentbit_include = "${var.fluent_bit_custom_include == "true" ? base64encode(file("${var.fluent_bit_custom_include_path}")) : var.fluent_bit_syslog_to_kafka == "true" ? base64encode(file("${path.module}/fluent-bit-include.syslog.yaml")) : base64encode(file("${path.module}/fluent-bit-include.null.yaml"))}"
        encoded_rsyslog_conf = "${var.fluent_bit_enabled == "true" ? base64encode(file("${path.module}/90-uemcloud-uos.fluent-bit.conf")) : base64encode(file("${path.module}/90-uemcloud-uos.conf")) }"
        jmxcollector_uemcloud_core_defaults = "${base64encode(file("${var.uos_jmxcollector_uemcloud_core_defaults}"))}"
        jmxcollector_uemcloud_core_properties = "${base64encode(file("${var.uos_jmxcollector_uemcloud_core_properties}"))}"
        jmxcollector_uemcloud_ui_defaults = "${base64encode(file("${var.uos_jmxcollector_uemcloud_ui_defaults}"))}"
        jmxcollector_uemcloud_ui_properties = "${base64encode(file("${var.uos_jmxcollector_uemcloud_ui_properties}"))}"
        jmx_exporter_uemcloud_core_defaults = "${base64encode(file("${var.uos_jmx_exporter_uemcloud_core_defaults}"))}"
        jmx_exporter_uemcloud_core_yaml = "${base64encode(file("${var.uos_jmx_exporter_uemcloud_core_yaml}"))}"
        jmx_exporter_uemcloud_ui_defaults = "${base64encode(file("${var.uos_jmx_exporter_uemcloud_ui_defaults}"))}"
        jmx_exporter_uemcloud_ui_yaml = "${base64encode(file("${var.uos_jmx_exporter_uemcloud_ui_yaml}"))}"
        log4j_properties = "/opt/uemcloud/CoreUILinux/etc/besngHome/logger/log4j.properties"
        machine_properties = "${base64encode(file("${path.module}/machine.properties.uemuosui"))}"
        postgres_root_cert = "${base64encode(file("/opt/uemcloud/.postgresql/root.crt"))}"
        ssh_authorized_key = "${file("/opt/uemcloud/.ssh/id_rsa.pub")}"
        ssh_users = "${base64encode("uemcloud")}"
        ssh_groups = "${base64encode(join("\n", var.ssh_allowed_groups))}"
        sudo_rules = "${base64encode("uemcloud ALL=(ALL) ALL\n${join("\n", formatlist("%%%s ALL=(ALL) ALL", var.ssh_allowed_groups))}")}"
        user_lock_passwd = "${var.env_type == "lab" ? false : true}"
        user_passwd = "${var.env_type == "lab" ? var.uos_password : ""}"
    }
}

data "template_cloudinit_config" "uemuosui_cloudinit_userdata" {
    gzip = true
    base64_encode = true

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.uemuos_cloudinit_postfix.rendered}"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.uemuosui_cloudinit_userdata.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_zabbix_psk.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_server_info.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_hold_packages.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_ubuntu_advantage.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_nexpose.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_rapid7_cfg.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${var.whitelight_enabled ? "" : file("${path.module}/cloudinit_userdata_whitelight_disable.tpl")}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }
}

resource "azurerm_virtual_machine_scale_set" "uemuosui" {
    count = "${lower(var.egress_lb) != "true" && lower(var.azure_uemuosui) == "true" ? 1 : 0}"
    name = "${var.partition_name}-uosui-${var.partition_version}"
    location = "${var.azure_location}"
    overprovision = false
    resource_group_name = "${var.azure_uemuos_resource_group}"
    upgrade_policy_mode = "Manual"
    zones = "${var.azure_uemuos_availability_zones}"

    sku {
        name = "${var.azure_uemuosui_vm_size}"
        tier = "Standard"
        capacity = "${var.azure_uemuosui_vmss_capacity}"
    }

    os_profile {
        computer_name_prefix = "${var.partition_name}-uosui-${var.partition_version}-"
        custom_data = "${data.template_cloudinit_config.uemuosui_cloudinit_userdata.rendered}"
        admin_username = "disabledbygts"
        admin_password = "DisabledByGTS1!"
    }

    os_profile_linux_config {
        disable_password_authentication = false
    }

    os_profile_secrets {
        source_vault_id = "${var.azure_deploy_keyvault_id}"
        vault_certificates {
            certificate_url = "${var.azure_deploy_keyvault_encryption_cert_url}"
        }
    }

    network_profile {
        name = "uemuos-vmss-nic"
        network_security_group_id = "${var.azure_uemuos_vmss_nsg_id}"
        primary = true

        ip_configuration {
            name = "uemuos-vmss-ipcf"
            primary = true
            subnet_id = "${var.azure_uemuos_subnet_id}"
        }
    }

    storage_profile_image_reference {
        id = "${data.terraform_remote_state.image_info.baked_uos_id}"
    }

    storage_profile_os_disk {
        caching = "ReadWrite"
        create_option = "FromImage"
        managed_disk_type = "${var.azure_managed_disk_type}"
    }

    boot_diagnostics {
        enabled = "${var.azure_uemuos_bootdiag_enabled}"
        storage_uri = "${var.azure_uemuos_bootdiag_storage_account_uri}"
    }

    tags = "${merge(
                var.azure_tags,
                map("bb:component", "uosui"),
                map("uemcloud.owner_hostname", trimspace(file("/etc/hostname")))
            )}"

}

resource "azurerm_virtual_machine_scale_set" "uemuosuiegress" {
    count = "${lower(var.egress_lb) == "true" && lower(var.azure_uemuosui) == "true" ? 1 : 0}"
    name = "${var.partition_name}-uosui-${var.partition_version}"
    location = "${var.azure_location}"
    overprovision = false
    resource_group_name = "${var.azure_uemuos_resource_group}"
    upgrade_policy_mode = "Manual"
    zones = "${var.azure_uemuos_availability_zones}"

    sku {
        name = "${var.azure_uemuosui_vm_size}"
        tier = "Standard"
        capacity = "${var.azure_uemuosui_vmss_capacity}"
    }

    os_profile {
        computer_name_prefix = "${var.partition_name}-uosui-${var.partition_version}-"
        custom_data = "${data.template_cloudinit_config.uemuosui_cloudinit_userdata.rendered}"
        admin_username = "disabledbygts"
        admin_password = "DisabledByGTS1!"
    }

    os_profile_linux_config {
        disable_password_authentication = false
    }

    os_profile_secrets {
        source_vault_id = "${var.azure_deploy_keyvault_id}"
        vault_certificates {
            certificate_url = "${var.azure_deploy_keyvault_encryption_cert_url}"
        }
    }

    network_profile {
        name = "uemuos-vmss-nic"
        network_security_group_id = "${var.azure_uemuos_vmss_nsg_id}"
        primary = true

        ip_configuration {
            name = "uemuos-vmss-ipcf"
            primary = true
            subnet_id = "${var.azure_uemuos_subnet_id}"
            load_balancer_backend_address_pool_ids = [
                "${data.terraform_remote_state.uempartition_prepare.lb_public_egress_bap_id}"
            ]
        }
    }

    storage_profile_image_reference {
        id = "${data.terraform_remote_state.image_info.baked_uos_id}"
    }

    storage_profile_os_disk {
        caching = "ReadWrite"
        create_option = "FromImage"
        managed_disk_type = "${var.azure_managed_disk_type}"
    }

    boot_diagnostics {
        enabled = "${var.azure_uemuos_bootdiag_enabled}"
        storage_uri = "${var.azure_uemuos_bootdiag_storage_account_uri}"
    }

    tags = "${merge(
                var.azure_tags,
                map("bb:component", "uosui"),
                map("uemcloud.owner_hostname", trimspace(file("/etc/hostname")))
            )}"

}


