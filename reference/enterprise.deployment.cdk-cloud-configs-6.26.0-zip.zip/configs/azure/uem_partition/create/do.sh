#!/usr/bin/env bash
set -o errexit

source functions_cdktools.sh

# Workaround to add "pause.sh" to older cdk versions
CURRENT_CREATE_FOLDER="../../../../current/azure/uem_partition/create"
if [ -d "$CURRENT_CREATE_FOLDER" ]; then
    # remove when all old/source envs are running cdk-tools 4.30.0 or later
    pushd $CURRENT_CREATE_FOLDER
        if [ ! -f pause.sh ]; then
            cp do.sh pause.sh
            sed -i '/^terraform_retry apply/ s/$/ -var azure_uemwafl_vmss_capacity=0 -var azure_uemuos_vmss_capacity=0/' pause.sh
        else
            sed -i -E 's/^(terraform_retry apply -input=false -auto-approve=true) -var azure_uemuos_vmss_capacity=0/\1 -var azure_uemwafl_vmss_capacity=0 -var azure_uemuos_vmss_capacity=0/' pause.sh
        fi
    popd

    # remove when all old/source envs are running cdk-tools 4.34.0 or later
    clearDnsInPause=`grep "clear_backend_uem_dns_pools" $CURRENT_CREATE_FOLDER/pause.sh || true`
    if [ -z "$clearDnsInPause" ]; then
        echo "Patching clear_backend_uem_dns_pools in $CURRENT_CREATE_FOLDER/pause.sh"
        echo >> $CURRENT_CREATE_FOLDER/pause.sh
        echo "clear_backend_uem_dns_pools" >> $CURRENT_CREATE_FOLDER/pause.sh
    fi
fi
# end workaround

terraform init -input=false -plugin-dir=/opt/uemcloud/deploy/cdktools/terraform-plugins -upgrade

pushd ../access_asset_vault
source ./do.sh
popd
export TF_VAR_azure_asset_keyvault_client_secret_encrypted=${KEY_VAULT_CLIENT_SECRET}

update_client_secret_monitoring

# rsyslog to kafka toggle
if [ "${EPF::fluent_bit_syslog_to_kafka}" != "true" ]
then
    # add stop if not sending to kafka to prevent rsyslog becoming unresponsive
    sed -i '/# stop anchor/astop' 90-*.fluent-bit.conf
fi

# clone machine.properties
cp ../../../machine.properties machine.properties.uemuos
grep 'deployment.ui.only' machine.properties.uemuos || echo 'deployment.ui.only=false' >> machine.properties.uemuos
grep 'deploy.core' machine.properties.uemuos || echo 'deploy.core=true' >> machine.properties.uemuos
grep 'deploy.ui' machine.properties.uemuos || echo 'deploy.ui=true' >> machine.properties.uemuos
cp machine.properties.uemuos machine.properties.uemuosui
if [[ $DEPLOY_UOS_UI == "true" ]]; then
  # toggle deployment.ui.only flag on UOSUI pool
  sed -i "s/^deployment\.ui\.only=.*/deployment.ui.only=true/" machine.properties.uemuosui
  # update ui memory settings
  sed -i "s/^ui.java.vm.memory.args=.*/ui.java.vm.memory.args=${UOS_UI_JAVA_MEM_ARG}/" machine.properties.uemuosui
fi

if [[ $DISABLE_MAINTENANCE_PAGE_REWRITE == "true" ]]; then
  # comment out error_page ... /error/maintenance.html
  sed -i '/error\/maintenance.html/s/error_page/#error_page/' nginx.conf
fi

terraform_retry apply -input=false -auto-approve=true

pushd ../access_asset_vault
source ./undo.sh
popd
