#cloud-config
write_files:
- path: /etc/postfix/main.cf
  encoding: b64
  owner: root:root
  permissions: '0644'
  content: ${encoded_main_cf}
- path: /etc/postfix/sender_access
  encoding: b64
  owner: root:root
  permissions: '0644'
  content: ${encoded_sender_access}
- path: /etc/postfix/sender_canonical_maps
  encoding: b64
  owner: root:root
  permissions: '0644'
  content: ${encoded_sender_canonical_maps}
runcmd:
  # configure and restart postfix
  - /usr/sbin/postmap /etc/postfix/sender_canonical_maps
  - chmod 644 /etc/postfix/sender_canonical_maps.db
  - sed -i "s/mydestination =.*/mydestination = \$$myhostname, $$(hostname), localhost.localdomain, localhost/" /etc/postfix/main.cf
  - service postfix restart
