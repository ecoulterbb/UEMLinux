#cloud-config
domain: ${EPF::machine_domain}
auth_domain: ${EPF::auth_domain}
auth_adbinduser: ${EPF::auth_adbinduser}
auth_adbindpass: ${EPF::auth_adbindpass}
auth_adsearchbase: ${EPF::auth_adsearchbase}
users:
- name: uemcloud
  lock_passwd: ${user_lock_passwd}
  ssh-authorized-keys:
  - ${ssh_authorized_key}
${ apt_server != "" ? "
apt_preserve_sources_list: true
apt_sources:
  - source: deb ${EPF::apt_server} $RELEASE main restricted universe
  - source: deb ${EPF::apt_server} $RELEASE-security main restricted universe
  - source: deb ${EPF::apt_server} $RELEASE-updates main restricted universe
" : "apt_preserve_sources_list: true\n"}
chpasswd:
  list: |
    uemcloud:${user_passwd}
  expire: false
write_files:
- path: /etc/default/bbddns
  content: |
    DDNS_ZONE="${EPF::dns_internal_zone}"
    TSIG_FWD="${EPF::dns_tsig_fwd}"
    TSIG_PTR="${EPF::dns_tsig_ptr}"
    DDNS_TTL=300
  owner: root:root
  permissions: '600'
- path: /etc/cron.hourly/dns_pool_member_add
  content: ${encoded_dns_pool_member_add}
  encoding: b64
  owner: root:root
  permissions: '0700'
- path: /etc/ssh/groups.allow
  content: ${ssh_groups}
  encoding: b64
  owner: root:root
  permissions: '0600'
- path: /etc/ssh/users.allow
  content: ${ssh_users}
  encoding: b64
  owner: root:root
  permissions: '0600'
- path: /etc/sudoers.d/my-sudo-rules
  content: ${sudo_rules}
  encoding: b64
  owner: root:root
  permissions: '0600'
- path: /opt/uemcloud/machine.properties
  content: ${machine_properties}
  encoding: b64
  owner: uemcloud:uemcloud
- path: /opt/uemcloud/.postgresql/root.crt
  content: ${postgres_root_cert}
  encoding: b64
  owner: uemcloud:uemcloud
- path: /etc/default/fluent-bit
  content: ${encoded_fluentbit_env}
  encoding: b64
  owner: root:root
  permissions: '0644'
- path: /etc/fluent-bit/fluent-bit.yaml
  content: ${encoded_fluentbit_yaml}
  encoding: b64
  owner: root:root
  permissions: '0644'
- path: /etc/fluent-bit/fluent-bit-include.yaml
  content: ${encoded_fluentbit_include}
  encoding: b64
  owner: root:root
  permissions: '0644'
- path: /etc/fluent-bit/observability.uem.crt
  content: ${encoded_fluentbit_cert}
  encoding: b64
  owner: root:root
  permissions: '0644'
- path: /etc/fluent-bit/observability.uem.key
  content: ${encoded_fluentbit_key}
  encoding: b64
  owner: root:root
  permissions: '0644'
- path: /etc/rsyslog.d/90-uemcloud-uos.conf
  content: ${encoded_rsyslog_conf}
  encoding: b64
- path: /etc/default/jmxcollector-uemcloud-core
  content: ${jmxcollector_uemcloud_core_defaults}
  encoding: b64
  owner: uemcloud:uemcloud
  permissions: '0644'
- path: /opt/jmxcollector/jmxcollector-uemcloud-core.properties
  content: ${jmxcollector_uemcloud_core_properties}
  encoding: b64
  owner: uemcloud:uemcloud
  permissions: '0644'
- path: /etc/default/jmxcollector-uemcloud-ui
  content: ${jmxcollector_uemcloud_ui_defaults}
  encoding: b64
  owner: uemcloud:uemcloud
  permissions: '0644'
- path: /opt/jmxcollector/jmxcollector-uemcloud-ui.properties
  content: ${jmxcollector_uemcloud_ui_properties}
  encoding: b64
  owner: uemcloud:uemcloud
  permissions: '0644'
- path: /etc/default/jmx_exporter-uemcloud-core
  content: ${jmx_exporter_uemcloud_core_defaults}
  encoding: b64
  owner: root:root
  permissions: '0644'
- path: /opt/prometheus/jmx_exporter/jmx_exporter-uemcloud-core.yaml
  content: ${jmx_exporter_uemcloud_core_yaml}
  encoding: b64
  owner: root:root
  permissions: '0644'
- path: /etc/default/jmx_exporter-uemcloud-ui
  content: ${jmx_exporter_uemcloud_ui_defaults}
  encoding: b64
  owner: root:root
  permissions: '0644'
- path: /opt/prometheus/jmx_exporter/jmx_exporter-uemcloud-ui.yaml
  content: ${jmx_exporter_uemcloud_ui_yaml}
  encoding: b64
  owner: root:root
  permissions: '0644'
runcmd:
- sed -i "s/key=\"{{REPLACE_ME}}\"/key=\"$$(hostname).${EPF::machine_domain}\"/g" /etc/rsyslog.d/90-uemcloud-uos.conf
- sed -i "s/LocalHostName {{REPLACE_ME}}/LocalHostName $$(hostname).${EPF::machine_domain}/" /etc/rsyslog.d/90-uemcloud-uos.conf
- service rsyslog restart
# setup fluent-bit
- 'if [ "${EPF::fluent_bit_enabled}" = "true" ] ; then'
- sed -i "s/{{REPLACE_ME}}/$$(hostname).${EPF::machine_domain}/g" /etc/default/fluent-bit
- systemctl enable fluent-bit
- systemctl start fluent-bit
- 'fi'
# start jmxcollectors
- systemctl enable jmxcollector-uemcloud-core --now
- systemctl enable jmxcollector-uemcloud-ui --now
- systemctl enable jmxcollector-uemcloud-core-watchdog --now
- systemctl enable jmxcollector-uemcloud-ui-watchdog --now
# start jmx_exporters
- systemctl enable jmx_exporter-uemcloud-core --now
- systemctl enable jmx_exporter-uemcloud-ui --now
# configure and restart zabbix agent
- sed -i "s/Server=.*/Server=${EPF::zabbix_servers}/" /etc/zabbix/zabbix_agentd.conf
- sed -i "s/ServerActive=.*/ServerActive=${EPF::zabbix_servers}/" /etc/zabbix/zabbix_agentd.conf
- sed -i "s/HostMetadata=.*/HostMetadata=${EPF::zabbix_serviceteam}-UOS/" /etc/zabbix/zabbix_agentd.conf
- sed -i "s/Hostname=.*/Hostname=$$(hostname).${EPF::machine_domain}/" /etc/zabbix/zabbix_agentd.conf
- sed -i "s/ListenIP=.*/ListenIP=$$(ip -f inet -o addr | grep -wv '127.0.0.1' | tail -1 | awk '{print $4}' | cut -d/ -f 1)/" /etc/zabbix/zabbix_agentd.conf
- sed -i "s/UserParameter=system.serviceteam, echo.*/UserParameter=system.serviceteam, echo ${EPF::zabbix_serviceteam}/" /etc/zabbix/zabbix_agentd.conf
- sed -i "s/StartAgents=.*/StartAgents=${EPF::zabbix_startagents_uemuos}/" /etc/zabbix/zabbix_agentd.conf
- sed -i "s/EnableRemoteCommands=.*/EnableRemoteCommands=${EPF::zabbix_enableremotecommands}/" /etc/zabbix/zabbix_agentd.conf
- service zabbix-agent restart
# set up temporary data directory
- mkdir -p /mnt/tmpData
- chown -R uemcloud:uemcloud /mnt/tmpData
- ln -s /mnt/tmpData /opt/uemcloud/tmpData
# convert private key to needed format, remove secrets from disk
- rm -rf /var/lib/waagent/Certificates.*
- openssl pkcs8 -topk8 -inform PEM -outform PEM -nocrypt -in /var/lib/waagent/${cert_thumbprint}.prv -out /opt/uemcloud/decryption.key
- rm /var/lib/waagent/${cert_thumbprint}.prv
- chmod 400 /opt/uemcloud/decryption.key
- chown uemcloud:uemcloud /opt/uemcloud/decryption.key
- rm -rf /var/lib/waagent/ovf-env.xml
# patch etc/besngHome/logger/log4j.properties if necessary
- grep -q "log4j.logger.com.mchange.v2.c3p0" ${log4j_properties} || echo "log4j.logger.com.mchange.v2.c3p0=WARN" >> ${log4j_properties}
# start UEM services with env variable
- KEY_VAULT_CLIENT_SECRET=${client_secret_encrypted} /opt/uemcloud/ContextAndDeploy.sh
- bash /etc/cron.hourly/dns_pool_member_add
