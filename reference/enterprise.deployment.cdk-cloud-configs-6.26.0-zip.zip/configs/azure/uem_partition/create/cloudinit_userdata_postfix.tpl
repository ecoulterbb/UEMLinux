#cloud-config
write_files:
- path: /etc/postfix/sender_access
  encoding: b64
  owner: root:root
  permissions: '0644'
  content: ${encoded_sender_access}
runcmd:
  # configure and restart postfix
  - sed -i 's/relayhost =.*/relayhost = ${EPF::smtp_relay_host}/g' /etc/postfix/main.cf
  - sed -i "s/myhostname =.*/myhostname = $$(hostname).${EPF::machine_domain}/" /etc/postfix/main.cf
  - sed -i "s/mydestination =.*/mydestination = \$$myhostname, $$(hostname), localhost.localdomain, localhost/" /etc/postfix/main.cf
  - sed -i "s/inet_interfaces =.*/inet_interfaces = loopback-only/" /etc/postfix/main.cf
  - sed -i '$asmtpd_sender_restrictions = regexp:/etc/postfix/sender_access' /etc/postfix/main.cf
  - service postfix restart
