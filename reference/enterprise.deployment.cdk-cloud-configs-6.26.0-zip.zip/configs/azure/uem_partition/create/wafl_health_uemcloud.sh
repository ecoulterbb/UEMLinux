#!/usr/bin/env bash
set -o errexit

umask 022

BACKEND_CORE_CURRENT='${EPF::uos_backend_core_current}'
BACKEND_CORE_VERSIONED='${EPF::uos_backend_core_versioned}'
BACKEND_UI_CURRENT='${EPF::uos_backend_ui_current}'
BACKEND_UI_VERSIONED='${EPF::uos_backend_ui_versioned}'
CORE_HEALTHCHECK_PORT='${EPF::core_healthcheck_port}'
UI_HEALTHCHECK_PORT='${EPF::ui_healthcheck_port}'
UOS_POOL_FQDN_INTERNAL='${EPF::uos_pool_fqdn_internal_hc}'

HEALTH_PAGE_FOLDER='/usr/local/openresty/nginx/html/health'

mkdir -p "$HEALTH_PAGE_FOLDER"

function set_healthcheck_pages () {
    SERVICE=$1
    HEALTH_PORT=$2
    HEALTHY_BACKENDS=$3
    BACKEND_VERSIONED=$4
    BACKEND_CURRENT=$5

    WAFL_HEALTH_PAGE="${HEALTH_PAGE_FOLDER}/wafl_${SERVICE}.html"
    SERVICE_HEALTH_PAGE="${HEALTH_PAGE_FOLDER}/service_${SERVICE}.html"

    if [ -z "$HEALTHY_BACKENDS" ]; then
        echo "No healthy $SERVICE backends, setting WAFL NOT OK"
        rm -f "$WAFL_HEALTH_PAGE"

        # give LB a chance to take this node out of the pool
        sleep 6

        # get health of WAFL on LB
        WAFL_POOL_HEALTH=$(curl -x "" -s -m 10 -o /dev/null -w "%{http_code}" "http://${UOS_POOL_FQDN_INTERNAL}:${HEALTH_PORT}/health/wafl_${SERVICE}.html")
        if [ "$WAFL_POOL_HEALTH" == "200" ]; then
            echo "Another WAFL node is healthy, setting ${SERVICE} service NOT OK"
            rm -f "$SERVICE_HEALTH_PAGE"
        else
            echo "No other healthy WAFL nodes, setting ${SERVICE} service OK (maintenance page will be shown if applicable)"
            echo "$BACKEND_VERSIONED" > "$SERVICE_HEALTH_PAGE"
        fi
    else
        echo "Found healthy ${SERVICE} backend(s), setting WAFL OK"
        echo "$BACKEND_VERSIONED" > "$WAFL_HEALTH_PAGE"

        if [ "$BACKEND_VERSIONED" == "$BACKEND_CURRENT" ]; then
            echo "Running current version, setting ${SERVICE} service OK"
            echo "$BACKEND_VERSIONED" > "$SERVICE_HEALTH_PAGE"
        else
            # when this node is not running the current version, it means that an upgrade is underway
            # script runs every 60 seconds -- keep checking 12 times at 5 second intervals so we can pick up changes more quickly
            # after 12 x 5 runs, stop so that the next iteration of the script can take over
            for i in `seq 1 12`; do
                if [ -f "$SERVICE_HEALTH_PAGE" ]; then
                    # this node is "old" -- it was previously healthy and is now being taken out of service
                    # need to verify that a "new" node is up before marking this node unhealthy
                    # to do this, we check the pool on the LB and see what version that node is running
                    # since there is no persistence on the LB, it should eventually send us to a "new" node once they are on
                    POOL_SERVICE_VERSION=$(curl -x "" -s -m 5 "http://${UOS_POOL_FQDN_INTERNAL}:${HEALTH_PORT}/health/service_${SERVICE}.html")
                    if [ "$POOL_SERVICE_VERSION" == "$BACKEND_CURRENT" ]; then
                        echo "NOT running current version, and saw updated WAFL node running -- setting ${SERVICE} service NOT OK"
                        rm -f "$SERVICE_HEALTH_PAGE"
                        break
                    else
                        echo "NOT running current version, but didn't see updated WAFL node running -- leaving ${SERVICE} service OK"
                    fi
                else
                    # this node is "new" -- waiting for it to be marked current
                    echo "NOT running current version, leaving ${SERVICE} service NOT OK"
                fi
                echo "Checking again in 5 seconds..."
                sleep 5
            done
        fi
    fi
}

function remove_failed_backends () {
    EXPIRED_BACKENDS=$1
    BACKEND_VERSIONED=$2

    if [ -f /etc/default/bbddns ]; then
        . /etc/default/bbddns
    fi

    [ -n "${TSIG_FWD}" ] && FWD_TSIG="-y ${TSIG_FWD}"
    [ -n "${DDNS_ANYCAST}" ] && DDNS_ANYCONF="server ${DDNS_ANYCAST}"

    if [ -n "$EXPIRED_BACKENDS" ]; then
        for IP_ADDRESS in $EXPIRED_BACKENDS; do
            echo "Removing IP ${IP_ADDRESS} from DNS pool ${BACKEND_VERSIONED} after more than ${FAILED_CHECKS} consecutive failed health checks"
            /usr/bin/nsupdate -d ${FWD_TSIG} <<EOF
${DDNS_ANYCONF}
zone $DDNS_ZONE.
update delete ${BACKEND_VERSIONED} A $IP_ADDRESS
send
EOF

        done
    fi
}

function reload_if_upstream_changed () {
    CURRENT_IPS=$1
    BACKEND_VERSIONED=$2

    BACKEND_VERSIONED_LOOKUP=$(dig +short -t A ${BACKEND_VERSIONED} | sort | paste -sd "," -)

    if [[ $? -ne 0 ]]; then
        echo "Error resolving ${BACKEND_VERSIONED}, exiting"
        exit 2
    fi

    if [[ -z "${BACKEND_VERSIONED_LOOKUP}" ]]; then
        echo "No IPs found ${BACKEND_VERSIONED}, exiting."
        exit 2
    fi

    if [ "$CURRENT_IPS" != "$BACKEND_VERSIONED_LOOKUP" ]; then
        echo "Different IPs found, reloading openresty..."
        service openresty reload
        # wait for openresty to reload, so subsequent calls will not need to reload it again
        sleep 5
    fi
}

echo "WAFL script starting"
# DNS pools indicating "current" version (updated by SAD)
BACKEND_CORE_CURRENT_LOOKUP=$(dig +short -t CNAME ${BACKEND_CORE_CURRENT})
BACKEND_UI_CURRENT_LOOKUP=$(dig +short -t CNAME ${BACKEND_UI_CURRENT})

# Get current backend health status
BACKENDS=$(curl -x "" 'http://127.0.0.1:7999/backendstatus?format=json')
# the health check module sometimes returns a trailing comma in the JSON which
# is not valid -- strip the comma if it is present
BACKENDS=$(echo $BACKENDS | sed 's/}, ]/}]/')

# reload openresty if DNS entry has changed
reload_if_upstream_changed $(echo $BACKENDS | jq -r ".uos_core_i2c_basic_backend[] | .ip" | sort | paste -sd "," -) $BACKEND_CORE_VERSIONED
reload_if_upstream_changed $(echo $BACKENDS | jq -r ".uos_ui_backend[] | .ip" | sort | paste -sd "," -) $BACKEND_UI_VERSIONED
reload_if_upstream_changed $(echo $BACKENDS | jq -r ".uos_core_rest_api_backend[] | .ip" | sort | paste -sd "," -) $BACKEND_CORE_VERSIONED

# set health check pages
HEALTHY_CORE_BACKENDS=$(echo $BACKENDS | jq "add[] | select(.status == \"up\" and .port == ${CORE_HEALTHCHECK_PORT})")
HEALTHY_UI_BACKENDS=$(echo $BACKENDS | jq "add[] | select(.status == \"up\" and .port == ${UI_HEALTHCHECK_PORT})")

set_healthcheck_pages 'core' "1$CORE_HEALTHCHECK_PORT" "$HEALTHY_CORE_BACKENDS" "$BACKEND_CORE_VERSIONED." "$BACKEND_CORE_CURRENT_LOOKUP"
set_healthcheck_pages 'ui' "1$UI_HEALTHCHECK_PORT" "$HEALTHY_UI_BACKENDS" "$BACKEND_UI_VERSIONED." "$BACKEND_UI_CURRENT_LOOKUP"

# Remove backend nodes that have been failed for a long time
# Calculated to be wafl_healthcheck_uos_remove_timer / wafl_healthcheck_interval (default: 1hr / 30s = 120)
FAILED_CHECKS=$(( (${EPF::wafl_healthcheck_uos_remove_timer}) / (${EPF::wafl_healthcheck_interval}) ))

EXPIRED_CORE_BACKENDS=$(echo $BACKENDS | jq -r "add[] | select(.status == \"down\" and .port == ${CORE_HEALTHCHECK_PORT} and .fails > ${FAILED_CHECKS}) | .ip" | sort -u)
EXPIRED_UI_BACKENDS=$(echo $BACKENDS | jq -r "add[] | select(.status == \"down\" and .port == ${UI_HEALTHCHECK_PORT} and .fails > ${FAILED_CHECKS}) | .ip" | sort -u)

remove_failed_backends "$EXPIRED_CORE_BACKENDS" "$BACKEND_CORE_VERSIONED"
remove_failed_backends "$EXPIRED_UI_BACKENDS" "$BACKEND_UI_VERSIONED"

echo "WAFL script finished"
