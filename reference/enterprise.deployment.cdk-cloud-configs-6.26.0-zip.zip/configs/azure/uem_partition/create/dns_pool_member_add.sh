#!/usr/bin/env bash

BACKEND_CORE_VERSIONED='${EPF::uos_backend_core_versioned}'
BACKEND_UI_VERSIONED='${EPF::uos_backend_ui_versioned}'

function add_to_dns_pool () {
    BACKEND_VERSIONED=$1
    DDNS_TTL=60
    IP_ADDRESS=$(hostname -I | tr -d  ' ')

    if [ -f /etc/default/bbddns ]; then
        . /etc/default/bbddns
    fi

    [ -n "${TSIG_FWD}" ] && FWD_TSIG="-y ${TSIG_FWD}"
    [ -n "${DDNS_ANYCAST}" ] && DDNS_ANYCONF="server ${DDNS_ANYCAST}"

    echo "Adding IP ${IP_ADDRESS} to DNS pool ${BACKEND_VERSIONED}"
            /usr/bin/nsupdate -d ${FWD_TSIG} <<EOF
${DDNS_ANYCONF}
zone $DDNS_ZONE.
update add ${BACKEND_VERSIONED} $DDNS_TTL A $IP_ADDRESS
send
EOF

}

echo "DNS Pool Member Add script starting"

# DNS pools that this UOS node joins
# add uos hosts to core backend (uosui host are not added)
if [[ "$(hostname)" =~ "-uos-" ]] ; then
    add_to_dns_pool "${BACKEND_CORE_VERSIONED}."
fi

# add uosui hosts to ui backend and add uos hosts if no uosui nodes are configured
if [[ "$(hostname)" =~ "-uosui-" ]] || [ ${EPF::uosui_count} -eq 0 ]; then
    add_to_dns_pool "${BACKEND_UI_VERSIONED}."
fi

echo "DNS Pool Member Add script finished"
