#The connections below will inject bypass rules into "ip xfrm policy"
#to ensure that all inbound UEM Cloud traffic is not encrypted with IPSEC

conn whitelist-incoming-uemuos-ui
    left=%defaultroute
    leftprotoport=tcp/${uemuos_ui_pool_port}
    right=0.0.0.0
    rightsubnet=0.0.0.0/0
    rightprotoport=tcp/%any
    auto=route
    type=passthrough
    priority=1000

conn whitelist-incoming-uemuos-core-i2c-basic
    left=%defaultroute
    leftprotoport=tcp/${uemuos_core_i2c_basic_port}
    right=0.0.0.0
    rightsubnet=0.0.0.0/0
    rightprotoport=tcp/%any
    auto=route
    type=passthrough
    priority=1000

conn whitelist-incoming-uemwafl-hc-core
    left=%defaultroute
    leftprotoport=tcp/${uemwafl_hc_core_port}
    right=0.0.0.0
    rightsubnet=0.0.0.0/0
    rightprotoport=tcp/%any
    auto=route
    type=passthrough
    priority=1000

conn whitelist-incoming-uemwafl-hc-ui
    left=%defaultroute
    leftprotoport=tcp/${uemwafl_hc_ui_port}
    right=0.0.0.0
    rightsubnet=0.0.0.0/0
    rightprotoport=tcp/%any
    auto=route
    type=passthrough
    priority=1000
