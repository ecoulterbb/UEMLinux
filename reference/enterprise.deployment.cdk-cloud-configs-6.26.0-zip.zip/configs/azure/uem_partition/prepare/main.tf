variable "azure_atm_enabled" {}
variable "azure_client_id" {}
variable "azure_client_secret" {}
variable "azure_disable_internal_dns_record" {}
variable "azure_dns_internal_zone" {}
variable "azure_dns_resource_group" {}
variable "azure_dns_ttl" {}
variable "azure_dns_zone" {}
variable "azure_enable_internal_dns_record_internal_zone" {}
variable "azure_environment" {}
variable "azure_hostedapp_storage_account_manage" {}
variable "azure_hostedapp_storage_account_name" {}
variable "azure_hostedapp_storage_account_tier" {}
variable "azure_hostedapp_storage_account_replication_type" {}
variable "azure_location" {}
variable "azure_public_ip_prefix_id" {}
variable "azure_subscription_id" {}
variable "azure_tags" { type = "map" }
variable "azure_tenant_id" {}
variable "azure_uemuos_resource_group" {}
variable "azure_uemwafl_public_core" {}
variable "azure_uemwafl_publicip_resource_group" {}
variable "azure_uemwafl_resource_group" {}
variable "azure_uemwafl_subnet_id" {}
variable "dns_internal_zone" {}
variable "dns_tsig_fwd" {}
variable "dns_tsig_ptr" {}
variable "dns_update_server" {}

variable "egress_lb" {}
variable "egress_ports_per_host" {}

variable "offline_deployment" {}

variable "partition_name" {}

variable "pg_admin_username" {}
variable "pg_admin_password" {}
variable "pg_collation" {}
variable "pg_dbrole_name" {}
variable "pg_dbrole_password" {}
variable "pg_host" {}
variable "pg_prepare_db" {}
variable "pg_sslmode" {}

variable "uos_core_healthcheck_port" {}
variable "uos_core_i2c_basic_port" {}
variable "uos_ui_healthcheck_port" {}
variable "uos_ui_pool_port" {}

resource "azurerm_storage_account" "hostedapp" {
    count = "${var.azure_hostedapp_storage_account_manage ? 1 : 0}"

    name = "${var.azure_hostedapp_storage_account_name}"
    account_kind = "BlobStorage"
    account_tier = "${var.azure_hostedapp_storage_account_tier}"
    account_replication_type = "${var.azure_hostedapp_storage_account_replication_type}"
    enable_blob_encryption = "true"
    enable_file_encryption = "true"
    location = "${var.azure_location}"
    resource_group_name = "${var.azure_uemuos_resource_group}"

    tags = "${merge(
                var.azure_tags,
                map("uemcloud.owner_hostname", trimspace(file("/etc/hostname")))
            )}"
}

data "azurerm_storage_account" "hostedapp" {
    count = "${var.azure_hostedapp_storage_account_manage ? 0 : 1}"

    name = "${var.azure_hostedapp_storage_account_name}"
    resource_group_name = "${var.azure_uemuos_resource_group}"
}

data "template_file" "deployer_properties" {
    template = <<-EOT
    gcs.mdm.apps.hosted.azure.storage.account.key=$${azure_hostedapp_storage_account_key}
    gcs.mdm.apps.hosted.azure.storage.blob.uri=$${azure_hostedapp_storage_blob_uri}
    EOT

    # The join() hack is required because currently the ternary operator
    # evaluates the expressions on both branches of the condition before
    # returning a value.  In this case, if we create a storage account we want
    # to use that, otherwise we want to use the data source to get the info.
    # Only one of those will be valid at a time because their count is
    # conditional on the azure_hostedapp_storage_account_manage parameter.
    #
    # This is tracked upstream and should be fixed soon with HCL changes in
    # terraform 0.12: https://github.com/hashicorp/hil/issues/50
    #
    vars {
        azure_hostedapp_storage_account_key = "${var.azure_hostedapp_storage_account_manage ? replace(jsonencode(join(" ", azurerm_storage_account.hostedapp.*.primary_access_key)), "\"", "") : replace(jsonencode(join(" ", data.azurerm_storage_account.hostedapp.*.primary_access_key)), "\"", "")}"
        azure_hostedapp_storage_blob_uri = "${var.azure_hostedapp_storage_account_manage ? replace(jsonencode(join(" ", azurerm_storage_account.hostedapp.*.primary_blob_endpoint)), "\"", "") : replace(jsonencode(join(" ", data.azurerm_storage_account.hostedapp.*.primary_blob_endpoint)), "\"", "")}"
    }
}

resource "local_file" "deployer_properties" {
    filename = "/opt/uemcloud/deploy/${var.partition_name}/deployer-partition.properties"
    content = "${data.template_file.deployer_properties.rendered}"
}

resource "azurerm_lb" "internal" {
    name = "${var.partition_name}-internal"
    location = "${var.azure_location}"
    resource_group_name = "${var.azure_uemwafl_resource_group}"
    sku = "Standard"

    frontend_ip_configuration {
        name = "${var.partition_name}-internal-ipcf"
        subnet_id = "${var.azure_uemwafl_subnet_id}"
    }

    tags = "${merge(
                var.azure_tags,
                map("uemcloud.owner_hostname", trimspace(file("/etc/hostname")))
            )}"
}

output "lb_internal_ip" {
    value = "${azurerm_lb.internal.private_ip_address}"
}

resource "azurerm_lb_backend_address_pool" "internal_wafl" {
    name = "${var.partition_name}-internal-wafl"
    resource_group_name = "${var.azure_uemwafl_resource_group}"
    loadbalancer_id = "${azurerm_lb.internal.id}"
}

output "lb_internal_wafl_bap_id" {
    value = "${azurerm_lb_backend_address_pool.internal_wafl.id}"
}

resource "azurerm_lb_probe" "wafl_to_healthy_core" {
    name = "wafl_to_healthy_core"
    resource_group_name = "${var.azure_uemwafl_resource_group}"
    loadbalancer_id = "${azurerm_lb.internal.id}"

    interval_in_seconds = "5"
    port = "1${var.uos_core_healthcheck_port}"
    protocol = "http"
    request_path = "/health/wafl_core.html"
}

resource "azurerm_lb_rule" "wafl_to_healthy_core" {
    name = "wafl_to_healthy_core"
    resource_group_name = "${var.azure_uemwafl_resource_group}"
    loadbalancer_id = "${azurerm_lb.internal.id}"
    frontend_ip_configuration_name = "${azurerm_lb.internal.name}-ipcf"
    backend_address_pool_id = "${azurerm_lb_backend_address_pool.internal_wafl.id}"

    frontend_port = "1${var.uos_core_healthcheck_port}"
    backend_port = "1${var.uos_core_healthcheck_port}"
    probe_id = "${azurerm_lb_probe.wafl_to_healthy_core.id}"
    protocol = "tcp"
}

resource "azurerm_lb_probe" "wafl_to_healthy_ui" {
    name = "wafl_to_healthy_ui"
    resource_group_name = "${var.azure_uemwafl_resource_group}"
    loadbalancer_id = "${azurerm_lb.internal.id}"

    interval_in_seconds = "5"
    port = "1${var.uos_ui_healthcheck_port}"
    protocol = "http"
    request_path = "/health/wafl_ui.html"
}

resource "azurerm_lb_rule" "wafl_to_healthy_ui" {
    name = "wafl_to_healthy_ui"
    resource_group_name = "${var.azure_uemwafl_resource_group}"
    loadbalancer_id = "${azurerm_lb.internal.id}"
    frontend_ip_configuration_name = "${azurerm_lb.internal.name}-ipcf"
    backend_address_pool_id = "${azurerm_lb_backend_address_pool.internal_wafl.id}"

    frontend_port = "1${var.uos_ui_healthcheck_port}"
    backend_port = "1${var.uos_ui_healthcheck_port}"
    probe_id = "${azurerm_lb_probe.wafl_to_healthy_ui.id}"
    protocol = "tcp"
}

resource "azurerm_lb_probe" "internal_core" {
    name = "core"
    resource_group_name = "${var.azure_uemwafl_resource_group}"
    loadbalancer_id = "${azurerm_lb.internal.id}"

    interval_in_seconds = "5"
    port = "1${var.uos_core_healthcheck_port}"
    protocol = "http"
    request_path = "/health/service_core.html"
}

resource "azurerm_lb_rule" "internal_core_i2c_basic" {
    name = "core_i2c_basic"
    resource_group_name = "${var.azure_uemwafl_resource_group}"
    loadbalancer_id = "${azurerm_lb.internal.id}"
    frontend_ip_configuration_name = "${azurerm_lb.internal.name}-ipcf"
    backend_address_pool_id = "${azurerm_lb_backend_address_pool.internal_wafl.id}"

    frontend_port = "${var.uos_core_i2c_basic_port}"
    backend_port = "${var.uos_core_i2c_basic_port}"
    probe_id = "${azurerm_lb_probe.internal_core.id}"
    protocol = "tcp"
}

resource "azurerm_lb" "public" {
    name = "${var.partition_name}-public"
    location = "${var.azure_location}"
    resource_group_name = "${var.azure_uemwafl_resource_group}"
    sku = "Standard"

    frontend_ip_configuration {
        name = "${var.partition_name}-public-ipcf"
        public_ip_address_id = "${azurerm_public_ip.partition.id}"
    }

    tags = "${merge(
                var.azure_tags,
                map("uemcloud.owner_hostname", trimspace(file("/etc/hostname")))
            )}"
}

resource "azurerm_lb_backend_address_pool" "public_wafl" {
    name = "${var.partition_name}-public-wafl"
    resource_group_name = "${var.azure_uemwafl_resource_group}"
    loadbalancer_id = "${azurerm_lb.public.id}"
}

output "lb_public_wafl_bap_id" {
    value = "${azurerm_lb_backend_address_pool.public_wafl.id}"
}


resource "azurerm_lb_probe" "public_ui" {
    name = "ui"
    resource_group_name = "${var.azure_uemwafl_resource_group}"
    loadbalancer_id = "${azurerm_lb.public.id}"

    interval_in_seconds = "5"
    port = "1${var.uos_ui_healthcheck_port}"
    protocol = "http"
    request_path = "/health/service_ui.html"
}

resource "azurerm_lb_rule" "public_ui" {
    name = "ui"
    resource_group_name = "${var.azure_uemwafl_resource_group}"
    loadbalancer_id = "${azurerm_lb.public.id}"
    frontend_ip_configuration_name = "${azurerm_lb.public.name}-ipcf"
    backend_address_pool_id = "${azurerm_lb_backend_address_pool.public_wafl.id}"

    frontend_port = "${var.uos_ui_pool_port}"
    backend_port = "${var.uos_ui_pool_port}"
    idle_timeout_in_minutes = 6
    load_distribution = "SourceIP"
    probe_id = "${azurerm_lb_probe.public_ui.id}"
    protocol = "tcp"
}

resource "azurerm_lb_probe" "public_core" {
    # fedramp only
    count = "${lower(var.azure_environment) == "usgovernment" || lower(var.azure_uemwafl_public_core) == "true" ? 1 : 0}"
    name = "core"
    resource_group_name = "${var.azure_uemwafl_resource_group}"
    loadbalancer_id = "${azurerm_lb.public.id}"

    interval_in_seconds = "5"
    port = "1${var.uos_core_healthcheck_port}"
    protocol = "http"
    request_path = "/health/service_core.html"
}

resource "azurerm_lb_rule" "public_core_i2c_basic" {
    # fedramp only
    count = "${lower(var.azure_environment) == "usgovernment" || lower(var.azure_uemwafl_public_core) == "true" ? 1 : 0}"
    name = "core_i2c_basic"
    resource_group_name = "${var.azure_uemwafl_resource_group}"
    loadbalancer_id = "${azurerm_lb.public.id}"
    frontend_ip_configuration_name = "${azurerm_lb.public.name}-ipcf"
    backend_address_pool_id = "${azurerm_lb_backend_address_pool.public_wafl.id}"

    frontend_port = "${var.uos_core_i2c_basic_port}"
    backend_port = "${var.uos_core_i2c_basic_port}"
    probe_id = "${azurerm_lb_probe.public_core.id}"
    protocol = "tcp"
}

resource "azurerm_dns_a_record" "pool_internal" {
    count = "${lower(var.azure_environment) == "usgovernment" || lower(var.azure_disable_internal_dns_record) == "true" || var.offline_deployment ? 0 : 1}"
    name = "${var.partition_name}-internal"
    zone_name = "${var.azure_dns_zone}"
    resource_group_name = "${var.azure_dns_resource_group}"
    records = ["${azurerm_lb.internal.private_ip_address}"]
    ttl = "${var.azure_dns_ttl}"

    tags = "${merge(
                var.azure_tags,
                map("uemcloud.owner_hostname", trimspace(file("/etc/hostname")))
            )}"
}

resource "azurerm_dns_a_record" "pool_public" {
    count = "${lower(var.azure_environment) == "usgovernment" || lower(var.azure_atm_enabled) == "true" || var.offline_deployment ? 0 : 1}"
    name = "${var.partition_name}"
    zone_name = "${var.azure_dns_zone}"
    resource_group_name = "${var.azure_dns_resource_group}"
    records = ["${azurerm_public_ip.partition.ip_address}"]
    ttl = "${var.azure_dns_ttl}"

    tags = "${merge(
                var.azure_tags,
                map("uemcloud.owner_hostname", trimspace(file("/etc/hostname")))
            )}"
}

resource "dns_a_record_set" "pool_internal_usgov" {
     # fedramp only
     count = "${lower(var.azure_environment) == "usgovernment" ? 1 : 0}"
     zone = "${var.dns_internal_zone}."
     # use replace to allow names not directly under the dns_internal_zone, and ensure it doesn't end with a dot
     # e.g. if machine_domain is bemscloud.sw.rim.net and dns_internal_zone is sw.rim.net
     name = "${var.partition_name}-internal"
     addresses = ["${azurerm_lb.internal.private_ip_address}"]
     ttl = 61
}

resource "dns_a_record_set" "pool_internal_idns" {
     # for partitions using non-Azure DNS zones
     count = "${lower(var.azure_enable_internal_dns_record_internal_zone) == "true" && ! var.offline_deployment ? 1 : 0}"
     zone = "${var.dns_internal_zone}."
     # use replace to allow names not directly under the dns_internal_zone, and ensure it doesn't end with a dot
     # e.g. if machine_domain is bemscloud.sw.rim.net and dns_internal_zone is sw.rim.net
     name = "${var.partition_name}-internal"
     addresses = ["${azurerm_lb.internal.private_ip_address}"]
     ttl = 61
}

resource "azurerm_lb" "egress" {
    count = "${lower(var.egress_lb) == "true" ? 1 : 0}"
    name = "${var.partition_name}-egress"
    location = "${var.azure_location}"
    resource_group_name = "${var.azure_uemuos_resource_group}"
    sku = "Standard"

    frontend_ip_configuration {
        name = "${var.partition_name}-egress-ipcf"
        public_ip_address_id = "${azurerm_public_ip.egress.id}"
    }

    tags = "${merge(
                var.azure_tags,
                map("uemcloud.owner_hostname", trimspace(file("/etc/hostname")))
            )}"
}

resource "azurerm_lb_backend_address_pool" "egress" {
    count = "${lower(var.egress_lb) == "true" ? 1 : 0}"
    name = "${var.partition_name}-egress"
    resource_group_name = "${var.azure_uemuos_resource_group}"
    loadbalancer_id = "${azurerm_lb.egress.id}"
}

resource "azurerm_lb_outbound_rule" "egress" {
    count = "${lower(var.egress_lb) == "true" ? 1 : 0}"
    name = "${var.partition_name}-egress"
    resource_group_name = "${var.azure_uemuos_resource_group}"

    loadbalancer_id = "${azurerm_lb.egress.id}"
    protocol = "All"
    enable_tcp_reset = "true"
    idle_timeout_in_minutes = "30"
    allocated_outbound_ports = "${var.egress_ports_per_host}"
    backend_address_pool_id = "${azurerm_lb_backend_address_pool.egress.id}"
    frontend_ip_configuration {
        name = "${var.partition_name}-egress-ipcf"
    }
}


output "lb_public_egress_bap_id" {
    value = "${ join ("",azurerm_lb_backend_address_pool.egress.*.id) }"
}
