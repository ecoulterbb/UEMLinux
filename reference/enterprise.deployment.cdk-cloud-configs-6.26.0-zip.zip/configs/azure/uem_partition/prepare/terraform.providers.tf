provider "azurerm" {
    version = "~> ${EPF::terraform_provider_azurerm_package_version}"

    subscription_id = "${var.azure_subscription_id}"
    client_id       = "${var.azure_client_id}"
    client_secret   = "${var.azure_client_secret}"
    tenant_id       = "${var.azure_tenant_id}"

    environment     = "${var.azure_environment}"
    skip_provider_registration = ${EPF::terraform_provider_azurerm_skip_registration}
}

provider "dns" {
    version = "~> ${EPF::terraform_provider_dns_package_version}"

    update {
        server = "${var.dns_update_server}"
        key_name = "${var.dns_tsig_fwd == "" ? "" : "${lower(element(split(":", var.dns_tsig_fwd), 0))}."}"
        key_algorithm = "${var.dns_tsig_fwd == "" ? "" : "hmac-md5"}"
        key_secret = "${var.dns_tsig_fwd == "" ? "" : element(split(":", var.dns_tsig_fwd), 1)}"
    }
}

provider "local" {
    version = "~> ${EPF::terraform_provider_local_package_version}"
}

provider "null" {
    version = "~> ${EPF::terraform_provider_null_package_version}"
}

provider "template" {
    version = "~> ${EPF::terraform_provider_template_package_version}"
}
