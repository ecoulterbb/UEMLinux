#!/usr/bin/env bash
set -o errexit

source functions_cdktools.sh

TF_STATE="../../../../azure-uem_partition-prepare-terraform.tfstate"


# BEGIN Remove after upgrade from PU05 QF1
# EMM-110138 allow usage of externally-created ABSA
# We don't want to delete existing storage account if we previously created it,
# so remove it from state if it's present and should no longer be managed by us
if grep 'azure_hostedapp_storage_account_manage = "false"' terraform.tfvars >/dev/null; then
    terraform state rm -state=$TF_STATE azurerm_storage_account.hostedapp >/dev/null 2>&1 || true
fi
# END Remove after upgrade from PU05 QF1

terraform init -input=false -plugin-dir=/opt/uemcloud/deploy/cdktools/terraform-plugins -upgrade
terraform_retry apply -input=false -auto-approve=true -state=$TF_STATE
