#!/usr/bin/env bash
source az_env.sh

echo "Azure CLI: logging out..."
az_retry 60 logout

rm -rf $AZURE_CONFIG_DIR
