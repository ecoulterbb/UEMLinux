#!/usr/bin/env bash
set -o errexit

source functions_cdktools.sh

TF_STATE="terraform.tfstate"

if [ -f "$TF_STATE" ]; then
    terraform init -input=false -plugin-dir=/opt/uemcloud/deploy/cdktools/terraform-plugins -upgrade
    terraform_retry destroy -force -state=$TF_STATE

    trap 'bash az_logout.sh' INT TERM EXIT
    bash az_login.sh

    echo "Checking for valid baked image..."
    if bash az_bakedimage_tagged.sh; then
        echo "Valid baked image found, leaving as-is."
    else
        echo "Valid baked image not found, removing failed baking attempt."
        bash az_bakedimage_delete.sh
    fi
else
    echo "Skipping as state file $TF_STATE was not found."
fi
