#cloud-config
bootcmd:
  # hold packages
  - apt-mark hold ${hold_kernel}
ITAKERESPONSIBILITYFORBOOTPATCHING: nobootpatching
