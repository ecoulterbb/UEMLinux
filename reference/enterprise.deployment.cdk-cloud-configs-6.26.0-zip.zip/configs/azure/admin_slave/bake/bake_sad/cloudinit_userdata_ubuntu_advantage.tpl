#cloud-config
bootcmd:
  # run ua attach and enable esm repos and fips-updates
  - 'test -z "${ua_token}" || ( ua attach --no-auto-enable ${ua_token} && ua enable esm-apps esm-infra && ua enable fips-updates --assume-yes --access-only) || true'
  # add UbuntuFIPSUpdates to allowed unattended upgrades origins
  - 'grep UbuntuFIPSUpdates /etc/apt/apt.conf.d/50unattended-upgrades >/dev/null || sed -i "/Unattended-Upgrade::Allowed-Origins/a\        \"UbuntuFIPSUpdates:\$${distro_codename}-updates\";" /etc/apt/apt.conf.d/50unattended-upgrades'
