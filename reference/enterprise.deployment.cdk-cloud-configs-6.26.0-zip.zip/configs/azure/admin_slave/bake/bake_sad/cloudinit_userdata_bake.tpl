#cloud-config
users:
  - name: cdktools-baker
    lock_passwd: true
    ssh-authorized-keys:
      - ${ssh_authorized_key}
    sudo: ALL=(ALL) NOPASSWD:ALL
${ apt_server != "" ? "
apt_preserve_sources_list: true
apt_sources:
  - source: deb ${apt_server} $RELEASE main restricted universe
  - source: deb ${apt_server} $RELEASE-security main restricted universe
  - source: deb ${apt_server} $RELEASE-updates main restricted universe
" : "apt_preserve_sources_list: true\n"}
write_files:
  - path: /etc/ssh/users.allow
    owner: root:root
    permissions: '0600'
    content: |
        cdktools-baker
