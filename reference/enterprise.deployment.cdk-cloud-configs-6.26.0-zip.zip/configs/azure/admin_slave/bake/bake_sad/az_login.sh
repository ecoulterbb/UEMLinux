#!/usr/bin/env bash
set -o errexit
source az_env.sh

rm -rf $AZURE_CONFIG_DIR

echo "Azure CLI: logging in..."

if [[ $AZURE_TENANT_ID == '${EPF::azure_tenant_id}' ]]
then
    echo "Skipping login as AZURE_TENANT_ID not contextualized"
    exit 0
fi

if [ "${AZURE_ENVIRONMENT,,}" == "usgovernment" ]; then
    az_retry 60 cloud set --name AzureUSGovernment
fi

az_retry 60 login --username $AZURE_CLIENT_ID --password="$AZURE_CLIENT_SECRET" --service-principal --tenant $AZURE_TENANT_ID
