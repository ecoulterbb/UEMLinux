#!/usr/bin/env bash
source az_env.sh

BLOB_BAKED_SUCCESSFULLY=$(az_retry 60 storage blob metadata show --name $AZURE_BAKEDIMAGE_NAME.vhd --container-name $AZURE_BAKEDIMAGE_STORAGE_CONTAINER --account-name $AZURE_BAKEDIMAGE_STORAGE_ACCOUNT | jq -r .cdktools_baked_successfully)

if [ "${BLOB_BAKED_SUCCESSFULLY,,}" == "true" ]; then
    echo "Valid tag found -- blob was baked successfully.  Verifying that image exists and also has a valid tag..."
    IMAGE_DATA=$(az_retry 60 image show --name $AZURE_BAKEDIMAGE_NAME --resource-group $AZURE_BAKEDIMAGE_RESOURCE_GROUP)
    IMAGE_BAKED_SUCCESSFULLY=$(echo $IMAGE_DATA | jq -r .tags.cdktools_baked_successfully)
    if [ "${IMAGE_BAKED_SUCCESSFULLY,,}" == "true" ]; then
        echo "Valid tag found -- image was baked successfully."

        echo "Updating 'last used' tag..."
        LAST_USED_STRING=$(date '+%Y-%m-%d@%H:%M:%S%z')
        EXPIRY_DATE_STRING=$(date -d "$AZURE_IMAGE_EXPIRATION_LENGTH" '+%Y/%m/%d')

        PREVIOUS_METADATA=$(az_retry 60 storage blob metadata show --name $AZURE_BAKEDIMAGE_NAME.vhd --container-name $AZURE_BAKEDIMAGE_STORAGE_CONTAINER --account-name $AZURE_BAKEDIMAGE_STORAGE_ACCOUNT | jq -r '[del(.cdktools_image_last_used) | del(.expirydate) | to_entries[] | "\(.key)=\(.value)"] | join(" ")')
        az_retry 60 storage blob metadata update --name $AZURE_BAKEDIMAGE_NAME.vhd --container-name $AZURE_BAKEDIMAGE_STORAGE_CONTAINER --account-name $AZURE_BAKEDIMAGE_STORAGE_ACCOUNT --metadata $PREVIOUS_METADATA "cdktools_image_last_used=${LAST_USED_STRING}" "expirydate=${EXPIRY_DATE_STRING}"

        exit 0
    else
        echo "Did not find valid baked image, even though there is a valid baked blob."
        if bash az_baking_enabled.sh; then
            echo "Removing baked blobs and images so they will be rebaked on the next attempt."
            bash az_bakedimage_delete.sh
        fi
        exit 1
    fi
else
    echo "Did not find valid baked blob."
    exit 1
fi
