provider "azurerm" {
    version = "~> ${EPF::terraform_provider_azurerm_package_version}"

    subscription_id = "${var.azure_subscription_id}"
    client_id       = "${var.azure_client_id}"
    client_secret   = "${var.azure_client_secret}"
    tenant_id       = "${var.azure_tenant_id}"

    environment     = "${var.azure_environment}"
    skip_provider_registration = ${EPF::terraform_provider_azurerm_skip_registration}
}

provider "template" {
    version = "~> ${EPF::terraform_provider_template_package_version}"
}
