#!/usr/bin/env bash
set -o errexit
source az_env.sh

BLOB_EXISTS=$(az_retry 60 storage blob exists --name $AZURE_BAKEDIMAGE_NAME.vhd --container-name $AZURE_BAKEDIMAGE_STORAGE_CONTAINER --account-name $AZURE_BAKEDIMAGE_STORAGE_ACCOUNT | jq -r .exists)

if [ "${BLOB_EXISTS,,}" == "true" ]; then
    echo "Removing baked blob $AZURE_BAKEDIMAGE_NAME.vhd..."
    az_retry 60 storage blob delete --name $AZURE_BAKEDIMAGE_NAME.vhd --container-name $AZURE_BAKEDIMAGE_STORAGE_CONTAINER --account-name $AZURE_BAKEDIMAGE_STORAGE_ACCOUNT
fi

echo "Removing baked image $AZURE_BAKEDIMAGE_NAME if it exists..."
az_retry 60 image delete --name $AZURE_BAKEDIMAGE_NAME --resource-group $AZURE_BAKEDIMAGE_RESOURCE_GROUP

echo "Removing baked disk $AZURE_BAKEDIMAGE_NAME if it exists..."
az_retry 60 disk delete --name $AZURE_BAKEDIMAGE_NAME --resource-group $AZURE_BAKEDIMAGE_RESOURCE_GROUP --yes
