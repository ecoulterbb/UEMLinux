#!/usr/bin/env bash
set -o errexit
source az_env.sh

if [ "$AZURE_BAKING_ENABLED" == "true" ]; then
    exit 0
fi

exit 1
