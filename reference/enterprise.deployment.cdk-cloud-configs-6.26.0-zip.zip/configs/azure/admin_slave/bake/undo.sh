#!/usr/bin/env bash
set -o errexit

pushd bake_sad
echo "Processing SAD image..."
bash ./undo.sh
popd
