#!/usr/bin/env bash

if [ -f "functions_local.sh" ]; then
    source functions_local.sh
fi

function_exists() {
    declare -f -F $1 > /dev/null
    return $?
}

terraform_retry() {
    COUNT=0
    until terraform "$@"; do
        if [[ $((COUNT++)) -ge 5 ]]; then
            echo "Failed after 5 attempts."
            return 1
        fi
        echo "Retrying in 10 seconds (attempt ${COUNT} of 5)..."
        sleep 10
        function_exists terraform_retry_cleanup && terraform_retry_cleanup
    done
    return 0
}
