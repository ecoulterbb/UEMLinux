#!/usr/bin/env bash
set -o errexit

source functions_cdktools.sh

terraform init -input=false -plugin-dir=/opt/uemcloud/deploy/cdktools/terraform-plugins -upgrade
terraform_retry apply -input=false -auto-approve=true
