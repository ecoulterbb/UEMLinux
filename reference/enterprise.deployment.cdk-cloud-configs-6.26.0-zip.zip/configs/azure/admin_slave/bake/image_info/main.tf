variable "azure_bakedimage_name_sad" {}
variable "azure_bakedimage_resource_group" {}
variable "azure_client_id" {}
variable "azure_client_secret" {}
variable "azure_environment" {}
variable "azure_subscription_id" {}
variable "azure_tenant_id" {}

data "azurerm_image" "baked_sad" {
    name = "${var.azure_bakedimage_name_sad}"
    resource_group_name = "${var.azure_bakedimage_resource_group}"
}

output "baked_sad_id" {
    value = "${data.azurerm_image.baked_sad.id}"
}
