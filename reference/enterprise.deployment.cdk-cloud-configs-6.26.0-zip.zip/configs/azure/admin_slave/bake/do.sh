#!/usr/bin/env bash
set -o errexit

pushd bake_sad
echo "Processing SAD image..."
bash ./do.sh
popd

pushd image_info
echo "Gathering baked image information..."
bash ./do.sh
popd
