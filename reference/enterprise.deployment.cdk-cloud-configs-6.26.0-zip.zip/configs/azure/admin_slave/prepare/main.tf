variable "azure_client_id" {}
variable "azure_client_secret" {}
variable "azure_environment" {}
variable "azure_location" {}
variable "azure_sad_resource_group" {}
variable "azure_sad_shared_disk_size" {}
variable "azure_subscription_id" {}
variable "azure_tags" { type = "map" }
variable "azure_tenant_id" {}

variable "product_name" {}

variable "sad_prefix" {}

resource "azurerm_managed_disk" "shared" {
    name = "${var.sad_prefix}-shared"
    location = "${var.azure_location}"
    resource_group_name = "${var.azure_sad_resource_group}"
    storage_account_type = "Standard_LRS"
    create_option = "Empty"
    disk_size_gb = "${var.azure_sad_shared_disk_size}"

    # if we have upgraded from unmanaged disks, don't trigger recreation
    lifecycle {
        ignore_changes = ["create_option"]
    }

    tags = "${merge(
                var.azure_tags,
                map("${var.product_name}cloud.owner_hostname", trimspace(file("/etc/hostname")))
            )}"
}
