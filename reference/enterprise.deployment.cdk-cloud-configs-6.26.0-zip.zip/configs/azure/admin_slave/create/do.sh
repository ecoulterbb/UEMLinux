#!/usr/bin/env bash
set -o errexit

source functions_cdktools.sh

unset SSH_AUTH_SOCK

# rsyslog to fluent-bit
if [ "${EPF::fluent_bit_enabled}" == "true" ]
then
    # send local logs to fluentbit
    sed -i 's/# fluent anchor//' 90-*.conf
fi

# rsyslog to kafka toggle
if [ "${EPF::fluent_bit_syslog_to_kafka}" != "true" ]
then
    # add stop if not sending to kafka to prevent rsyslog becoming unresponsive
    sed -i '/# stop anchor/astop' 90-*.conf
fi

terraform init -input=false -plugin-dir=/opt/uemcloud/deploy/cdktools/terraform-plugins -upgrade
terraform_retry apply -input=false -auto-approve=true
