#cloud-config
runcmd:
  # stop and disable whitelight
  - systemctl stop ipsec.service
  - systemctl disable ipsec.service
