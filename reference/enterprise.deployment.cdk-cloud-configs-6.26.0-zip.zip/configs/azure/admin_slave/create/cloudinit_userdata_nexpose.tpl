#cloud-config
runcmd:
  # allow alternate nexpose account
  - 'echo "${nexpose_alt_account}" >> /etc/ssh/gts-shared-services.allow'
  - 'cat /etc/sudoers.d/csvulnscan | sed -e "s/csvulnscan/${nexpose_alt_account}/;s/CSVULNSCAN/ALTCSVULNSCAN/g" > /etc/sudoers.d/altvulnscan'
