#!/usr/bin/env bash
set -o errexit
source az_env.sh

trap 'bash az_logout.sh' INT TERM EXIT
bash az_login.sh

az_retry 60 vm deallocate --resource-group $AZURE_SAD_RESOURCE_GROUP --name $AZURE_SAD_NAME
