variable "apt_server" {}

variable "azure_client_id" {}
variable "azure_client_secret" {}
variable "azure_deploy_keyvault_encryption_cert_thumbprint" {}
variable "azure_deploy_keyvault_encryption_cert_url" {}
variable "azure_deploy_keyvault_id" {}
variable "azure_environment" {}
variable "azure_location" {}
variable "azure_managed_disk_type" {}
variable "azure_sad_bootdiag_enabled" {}
variable "azure_sad_bootdiag_storage_account_uri" {}
variable "azure_sad_nsg_id" {}
variable "azure_sad_resource_group" {}
variable "azure_sad_subnet_id" {}
variable "azure_sad_vm_size" {}
variable "azure_sad_vnet_id" {}
variable "azure_subscription_id" {}
variable "azure_tags" { type = "map" }
variable "azure_tenant_id" {}

variable "env_type_sad" {}

variable "fluent_bit_enabled" {}
variable "fluent_bit_cert_path" {}
variable "fluent_bit_key_path" {}
variable "fluent_bit_custom_include" {}
variable "fluent_bit_custom_include_path" {}
variable "fluent_bit_syslog_to_kafka" {}

variable "hold_packages" {}

variable "nexpose_alt_account" {}

variable "product_name" {}

variable "rapid7_cfg_file" {}

variable "sad_ansible_playbook" {}
variable "sad_name" {}
variable "sad_password" {}

variable "ssh_allowed_groups" { type = "list" }
variable "sudo_groups" { type = "list" }

variable "whitelight_enabled" {}

variable "ua_token" {}

variable "zabbix_psk" {}
variable "zabbix_psk_identity" {}

data "terraform_remote_state" "image_info" {
    backend = "local"

    config {
        path = "${path.module}/../bake/image_info/terraform.tfstate"
    }
}

resource "azurerm_network_interface" "sad" {
    name = "${var.sad_name}-ni"
    network_security_group_id = "${var.azure_sad_nsg_id}"
    location = "${var.azure_location}"
    resource_group_name = "${var.azure_sad_resource_group}"

    ip_configuration {
        name = "${var.sad_name}-ipcf"
        subnet_id = "${var.azure_sad_subnet_id}"
        private_ip_address_allocation = "dynamic"
    }

    tags = "${merge(
                var.azure_tags,
                map("${var.product_name}cloud.owner_hostname", trimspace(file("/etc/hostname")))
            )}"
}

resource "azurerm_virtual_machine" "sad" {
    name = "${var.sad_name}"
    location = "${var.azure_location}"
    resource_group_name = "${var.azure_sad_resource_group}"
    network_interface_ids = ["${azurerm_network_interface.sad.id}"]
    vm_size = "${var.azure_sad_vm_size}"
    delete_os_disk_on_termination = true

    tags = "${merge(
                var.azure_tags,
                map("bb:component", "sad"),
                map("${var.product_name}cloud.owner_hostname", trimspace(file("/etc/hostname")))
            )}"

    boot_diagnostics {
        enabled = "${var.azure_sad_bootdiag_enabled}"
        storage_uri = "${var.azure_sad_bootdiag_storage_account_uri}"
    }

    storage_image_reference {
        id = "${data.terraform_remote_state.image_info.baked_sad_id}"
    }

    storage_os_disk {
        name = "${var.sad_name}-os"
        caching = "ReadWrite"
        create_option = "fromImage"
        managed_disk_type = "${var.azure_managed_disk_type}"
    }

    os_profile {
        computer_name = "${var.sad_name}"
        admin_username = "disabledbygts"
        admin_password = "DisabledByGTS1!"
        custom_data = "${data.template_cloudinit_config.sad_cloudinit_userdata.rendered}"
    }

    os_profile_linux_config {
        disable_password_authentication = false
    }

    os_profile_secrets {
        source_vault_id = "${var.azure_deploy_keyvault_id}"
        vault_certificates {
            certificate_url = "${var.azure_deploy_keyvault_encryption_cert_url}"
        }
    }

    connection {
        type = "ssh"
        host = "${azurerm_network_interface.sad.private_ip_address}"
        user = "uemcloud"
        private_key = "${file(pathexpand("~/.ssh/id_rsa"))}"
    }

# workaround for terraform 0.11 crypto issue connecting to ubuntu 22.04+
#    provisioner "remote-exec" {
#        inline = [
#            "while [ ! -f /var/lib/cloud/instance/boot-finished ]; do echo 'Waiting for cloud-init...'; sleep 5; done"
#        ]
#        connection {
#            script_path = "/var/tmp/wait_for_cloud_init.sh"
#        }
#    }

    provisioner "local-exec" {
        command = <<-EOT
            while ! nc -w2 -zv ${azurerm_network_interface.sad.private_ip_address} 22 ; do sleep 5 ; done
            sleep 10
            ssh -qn -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null ${azurerm_network_interface.sad.private_ip_address} 'while [ ! -f /var/lib/cloud/instance/boot-finished ]; do echo "Waiting for cloud-init..."; sleep 5; done'
        EOT
    }

    provisioner "local-exec" {
        command = <<-EOT
            export ANSIBLE_HOST_KEY_CHECKING=False
            export ANSIBLE_SSH_PIPELINING=True
            ansible-playbook -i '${azurerm_network_interface.sad.private_ip_address},' -u uemcloud --extra-vars 'vars_file=${path.module}/ansible_vars.yml' ${var.sad_ansible_playbook}
        EOT
    }
}

data "template_file" "sad_cloudinit_userdata" {
    template = "${file("${path.module}/cloudinit_userdata_sad_azure.tpl")}"
    vars = {
        apt_server = "${var.apt_server}"
        cert_thumbprint = "${var.azure_deploy_keyvault_encryption_cert_thumbprint}"
        encoded_fluentbit_env = "${base64encode(file("${path.module}/fluent-bit.sad.env"))}"
        encoded_fluentbit_yaml = "${base64encode(file("${path.module}/fluent-bit.sad.yaml"))}"
        encoded_fluentbit_cert = "${base64encode(file("${var.fluent_bit_cert_path}"))}"
        encoded_fluentbit_key = "${base64encode(file("${var.fluent_bit_key_path}"))}"
        encoded_fluentbit_include = "${var.fluent_bit_custom_include == "true" ? base64encode(file("${var.fluent_bit_custom_include_path}")) : var.fluent_bit_syslog_to_kafka == "true" ? base64encode(file("${path.module}/fluent-bit-include.syslog.yaml")) : base64encode(file("${path.module}/fluent-bit-include.null.yaml"))}"
        product_name = "${var.product_name}"
        ssh_authorized_key = "${file("/opt/uemcloud/.ssh/id_rsa.pub")}"
        ssh_users = "${base64encode("uemcloud")}"
        ssh_groups = "${base64encode(join("\n", var.ssh_allowed_groups))}"
        sudo_rules = "${base64encode("uemcloud ALL=(ALL) NOPASSWD:ALL\n${join("\n", formatlist("%%%s ALL=(ALL) ALL", var.sudo_groups))}")}"
        user_lock_passwd = "${var.env_type_sad == "lab" ? false : true}"
        user_passwd = "${var.env_type_sad == "lab" ? var.sad_password : ""}"
    }
}

data "template_file" "cloudinit_userdata_onboot" {
    template = "${file("${path.module}/cloudinit_userdata_onboot.tpl")}"
    vars = {
        tempdisk = "${base64encode(file("${path.module}/01_tempdisk.sh"))}"
        dhcpclient = "${base64encode(file("${path.module}/02_dhcpclient.sh"))}"
    }
}

data "template_file" "cloudinit_userdata_zabbix_psk" {
    template = "${var.zabbix_psk == "" ? "" : file("${path.module}/cloudinit_userdata_zabbix_psk.tpl")}"
    vars = {
        zabbix_psk = "${base64encode(var.zabbix_psk)}"
        zabbix_psk_identity = "${var.zabbix_psk_identity}"
        zabbix_psk_ar_script = "${base64encode(file("${path.module}/zabbix_psk_ar.sh"))}"
    }
}

data "template_file" "cloudinit_userdata_server_info" {
    template = "${file("${path.module}/cloudinit_userdata_bb-server-info.tpl")}"
    vars = {
        server_info = "${base64encode(file("${path.module}/bb-server-info.txt"))}"
    }
}

data "template_file" "cloudinit_userdata_hold_packages" {
    template = "${var.hold_packages == "" ? "" : file("${path.module}/cloudinit_userdata_hold_packages.tpl")}"
    vars = {
        hold_packages = "${var.hold_packages}"
    }
}

data "template_file" "cloudinit_userdata_ubuntu_advantage" {
    template = "${var.ua_token == "" ? "" : file("${path.module}/cloudinit_userdata_ubuntu_advantage.tpl")}"
    vars = {
        ua_token = "${var.ua_token}"
    }
}

data "template_file" "cloudinit_userdata_nexpose" {
    template = "${var.nexpose_alt_account == "" ? "" : file("${path.module}/cloudinit_userdata_nexpose.tpl")}"
    vars = {
        nexpose_alt_account = "${var.nexpose_alt_account}"
    }
}

data "template_file" "cloudinit_userdata_rapid7_cfg" {
    template = "${var.rapid7_cfg_file == "/dev/null" ? "" : file("${path.module}/cloudinit_userdata_rapid7_cfg.tpl")}"
    vars = {
        rapid7_cfg = "${var.rapid7_cfg_file == "/dev/null" ? "" : base64encode(file("${var.rapid7_cfg_file}"))}"
    }
}

data "template_cloudinit_config" "sad_cloudinit_userdata" {
    gzip = true
    base64_encode = true

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.sad_cloudinit_userdata.rendered}"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_onboot.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_zabbix_psk.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_server_info.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_hold_packages.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_ubuntu_advantage.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_nexpose.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_rapid7_cfg.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${var.whitelight_enabled ? "" : file("${path.module}/cloudinit_userdata_whitelight_disable.tpl")}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }
}

output "dest_slaveadmin_ip" {
    value = "${azurerm_network_interface.sad.private_ip_address}"
}
