#cloud-config
write_files:
- path: /var/tmp/rapid7_cfg.sh
  encoding: b64
  owner: root:root
  permissions: '0755'
  content: ${rapid7_cfg}
runcmd:
  # run rapid7_cfg.sh
  - '/var/tmp/rapid7_cfg.sh'
