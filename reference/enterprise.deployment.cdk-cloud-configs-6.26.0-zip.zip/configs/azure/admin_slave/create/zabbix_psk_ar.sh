#!/bin/bash
# wait until log file exists

until [[ -f /var/log/zabbix/zabbix_agentd.log ]];
do
    sleep 15
done

# watch /var/log/zabbix.log for unencrypted connect to Zabbix
until grep 'connection of type "unencrypted" is not allowed for host' /var/log/zabbix/zabbix_agentd.log;
do
    sleep 15
done
# then swap it over
sed -i 's/^TLSConnect=unencrypted/TLSConnect=psk/' /etc/zabbix/zabbix_agentd.conf
service zabbix-agent restart
