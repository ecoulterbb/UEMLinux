#cloud-config
write_files:
- path: /etc/bb-server-info.txt
  encoding: b64
  owner: root:root
  permissions: '0644'
  content: ${server_info}
