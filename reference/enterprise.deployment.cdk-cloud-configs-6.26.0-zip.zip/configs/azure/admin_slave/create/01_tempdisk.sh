#!/bin/bash

# set up temporary directory (used by NOC for heap dumps)
if [ ! -e /mnt/tmp ]
then
    mkdir -p /mnt/tmp
    chown -R uemcloud:uemcloud /mnt/tmp
fi

# set up log directory on temporary disk
if [ ! -e /mnt/log/bemscloud ]
then
    mkdir -p /mnt/log/${EPF::product_name}cloud
    chmod -R 755 /mnt/log/${EPF::product_name}cloud
fi
