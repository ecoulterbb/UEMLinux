#cloud-config
write_files:
- path: /etc/zabbix/psk/zabbix.psk
  encoding: b64
  owner: zabbix:zabbix
  permissions: '0400'
  content: ${zabbix_psk}
- path: /tmp/zabbix_psk_ar.sh
  encoding: b64
  owner: zabbix:zabbix
  permissions: '0700'
  content: ${zabbix_psk_ar_script}
runcmd:
  # configure zabbix PSK
  - sed -i -e '$aTLSConnect=unencrypted' /etc/zabbix/zabbix_agentd.conf
  - sed -i -e '$aTLSAccept=psk' /etc/zabbix/zabbix_agentd.conf
  - sed -i -e '$aTLSPSKFile=/etc/zabbix/psk/zabbix.psk' /etc/zabbix/zabbix_agentd.conf
  - sed -i -e '$aTLSPSKIdentity=${zabbix_psk_identity}' /etc/zabbix/zabbix_agentd.conf
  - sed -i -e '$aTLSCipherPSK13=TLS_AES_128_GCM_SHA256' /etc/zabbix/zabbix_agentd.conf
  # run script to change from PSK to unencrypted to PSK
  - nohup timeout 1h bash /tmp/zabbix_psk_ar.sh &

