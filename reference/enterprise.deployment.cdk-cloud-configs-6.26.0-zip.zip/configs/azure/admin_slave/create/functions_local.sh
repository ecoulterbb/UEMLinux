#!/usr/bin/env bash
source az_env.sh

trap 'bash az_logout.sh' INT TERM EXIT
bash az_login.sh

terraform_retry_import() {
    TF_STATE=${TF_STATE:-terraform.tfstate}

    # if VM doesn't exist in state, try importing so any previous failed copy will be cleaned up on retry
    if ! terraform state list -state=$TF_STATE | grep -F azurerm_virtual_machine.sad; then
        terraform import -state=$TF_STATE azurerm_virtual_machine.sad "/subscriptions/${EPF::azure_subscription_id}/resourceGroups/${EPF::azure_sad_resource_group}/providers/Microsoft.Compute/virtualMachines/${EPF::sad_name}" || true
    fi
}

function terraform_retry_cleanup() {
    #import any objects that were created prior to the error state
    terraform_retry_import
    
    TF_STATE=${TF_STATE:-terraform.tfstate}
    # if there was a transient error, we should start from scratch
    echo "Destroying failed infrastructure..."
    terraform destroy -force -state=$TF_STATE
    echo "Cleaning up OS disk ${EPF::sad_name}-os..."
    az_retry 60 disk delete --name ${EPF::sad_name}-os --resource-group ${EPF::azure_sad_resource_group} --yes || true
    echo "Sleeping 15s..."
    sleep 15
}
