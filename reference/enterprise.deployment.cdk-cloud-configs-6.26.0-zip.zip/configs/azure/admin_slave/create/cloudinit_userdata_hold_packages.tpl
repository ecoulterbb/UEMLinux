#cloud-config
bootcmd:
  # hold packages
  - apt-mark hold ${hold_packages}
