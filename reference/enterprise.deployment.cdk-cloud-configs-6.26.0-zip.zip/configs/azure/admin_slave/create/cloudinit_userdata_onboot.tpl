#cloud-config
write_files:
- path: /var/lib/cloud/scripts/per-boot/01_tempdisk.sh
  encoding: b64
  owner: root:root
  permissions: '0755'
  content: ${tempdisk}
- path: /var/lib/cloud/scripts/per-boot/02_dhcpclient.sh
  encoding: b64
  owner: root:root
  permissions: '0755'
  content: ${dhcpclient}
