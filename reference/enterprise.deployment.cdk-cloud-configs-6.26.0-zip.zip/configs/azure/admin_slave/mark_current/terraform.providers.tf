variable dns_tsig_fwd_key_name { default = "" }
variable dns_tsig_fwd_key_algo { default = "" }
variable dns_tsig_fwd_key_secret { default = "" }

provider "dns" {
    version = "~> ${EPF::terraform_provider_dns_package_version}"

    update {
        server = "${var.dns_update_server}"
        key_name = "${var.dns_tsig_fwd_key_name}"
        key_algorithm = "${var.dns_tsig_fwd_key_algo}"
        key_secret = "${var.dns_tsig_fwd_key_secret}"
    }
}
