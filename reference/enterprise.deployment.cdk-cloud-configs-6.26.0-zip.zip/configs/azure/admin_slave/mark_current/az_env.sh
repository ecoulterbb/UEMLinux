#!/usr/bin/env bash

# This is a special environment variable that az checks for
# Use a subfolder of the current working directory to support concurrency
export AZURE_CONFIG_DIR=$(pwd)/azureconfig
export AZURE_CORE_COLLECT_TELEMETRY=false

export AZURE_CLIENT_ID="${TF_VAR_azure_client_id}"
export AZURE_CLIENT_SECRET="${TF_VAR_azure_client_secret}"
export AZURE_ENVIRONMENT='${EPF::azure_environment}'
export AZURE_TENANT_ID='${EPF::azure_tenant_id}'
export AZURE_SAD_IP="$(terraform output -state=../create/terraform.tfstate dest_slaveadmin_ip)"
export AZURE_SAD_NAME='${EPF::sad_name}'
export AZURE_SAD_RESOURCE_GROUP='${EPF::azure_sad_resource_group}'
export AZURE_SHAREDDISK_NAME='${EPF::epf_region_name}-sad-shared'

# added for temporary DNS creation via SSH
export DNS_SAD_COMMON_RECORD='${EPF::epf_region_name}-sad.${EPF::machine_domain}'
export DNS_SAD_RECORD='${EPF::sad_name}.${EPF::machine_domain}'
export DNS_INTERNAL_ZONE='${EPF::dns_internal_zone}'
export DNS_TSIG_FWD='${EPF::dns_tsig_fwd}'
export DNS_UPDATE_SERVER='${EPF::dns_update_server}'

az_retry() {
    COUNT=0

    TIMEOUT=$1
    AZ_CMD="${2}_${3}_${4}"
    shift

    while true; do
        if timeout $TIMEOUT az "$@"; then
            return 0
        else
            e=$?
            if [ $e -eq 124 ]; then
                # if timeout is hit, it returns code 124
                >&2 echo -n "Azure CLI command timed out after $TIMEOUT seconds."
            elif [ $e -eq 3 ]; then
                # if resource does not exist for 'az ... show', it returns code 3
                >&2 echo -n "Azure CLI command returned an error 3.  Resource does not exist."
                return 1
            else
                >&2 echo -n "Azure CLI command returned an error (${e})."
            fi
            # verify if defined
            function_exists az_verify_${AZ_CMD} && az_verify_${AZ_CMD}
            if [ $? -eq 0 ]; then
                return 0
            fi
        fi

        if [[ $((COUNT++)) -ge ${EPF::azure_cli_retry_attempts} ]]; then
            >&2 echo " Failed after ${EPF::azure_cli_retry_attempts} retries."
            return 1
        fi

        >&2 echo " Retrying in 10 seconds (retry ${COUNT} of ${EPF::azure_cli_retry_attempts})..."
        sleep 10
    done
}
