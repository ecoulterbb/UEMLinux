#!/usr/bin/env bash
set -o errexit
source az_env.sh

echo "Creating common SAD DNS entry remotely via SSH..."

ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null $AZURE_SAD_IP << EOF
echo $DNS_TSIG_FWD > /tmp/TSIG_FWD.key

cat > /tmp/update_fwd.dns << _EOS_
server $DNS_UPDATE_SERVER
zone $DNS_INTERNAL_ZONE.
update delete $DNS_SAD_COMMON_RECORD. CNAME
update add $DNS_SAD_COMMON_RECORD. 61 CNAME $DNS_SAD_RECORD.
send
_EOS_

nsupdate -d -y \$(cat /tmp/TSIG_FWD.key) -v /tmp/update_fwd.dns 2> /tmp/dns_results.txt
rm -f /tmp/TSIG_FWD.key

grep NOERROR /tmp/dns_results.txt
if [[ \$? -eq 0 ]]; then
  echo "Successfully created common SAD DNS entry via SSH."
else
  echo "Failed to create common SAD DNS entry via SSH."
  exit 1
fi
EOF
