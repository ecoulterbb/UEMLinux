#!/usr/bin/env bash

az_verify_vm_disk_attach() {
    echo
    echo "Running error verification..."
    VM_INFO=$(az_retry 120 vm show --name $AZURE_SAD_NAME --resource-group $AZURE_SAD_RESOURCE_GROUP)
    if echo $VM_INFO | jq -ne --arg diskname "$AZURE_SHAREDDISK_NAME" 'inputs | .storageProfile.dataDisks[] | select(.name == $diskname)'; then
        echo "Shared disk ${AZURE_SHAREDDISK_NAME} attached.  No retry necessary."
        return 0
    else
        echo "Shared disk ${AZURE_SHAREDDISK_NAME} not attached."
        return 1
    fi
}

az_verify_vm_disk_detach() {
    echo
    echo "Running error verification..."
    VM_INFO=$(az_retry 120 vm show --name $AZURE_SAD_NAME --resource-group $AZURE_SAD_RESOURCE_GROUP)
    if echo $VM_INFO | jq -ne --arg diskname "$AZURE_SHAREDDISK_NAME" 'inputs | .storageProfile.dataDisks[] | select(.name == $diskname)'; then
        echo "Shared disk ${AZURE_SHAREDDISK_NAME} attached."
        return 1
    else
        echo "Shared disk ${AZURE_SHAREDDISK_NAME} not attached.  No retry necessary."
        return 0
    fi
}

if [[ "x${EPF::dns_tsig_fwd}" != "x" ]] ; then
    export TF_VAR_dns_tsig_fwd_key_secret=$(echo "${EPF::dns_tsig_fwd}" | rev | cut -d: -f 1 | rev)
    export TF_VAR_dns_tsig_fwd_key_name=$(echo "${EPF::dns_tsig_fwd}" | rev | cut -d: -f 2 | rev).
    export TF_VAR_dns_tsig_fwd_key_algo=$(echo "${EPF::dns_tsig_fwd}" | rev | cut -d: -f 3 | rev)
    if [[ "x${TF_VAR_dns_tsig_fwd_key_algo}" == "x" ]] ; then
        export TF_VAR_dns_tsig_fwd_key_algo="hmac-md5"
    fi
fi

