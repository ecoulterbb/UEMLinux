#!/usr/bin/env bash
set -o errexit

source functions_cdktools.sh

TF_STATE="../../../../azure-admin_slave-mark_current-terraform.tfstate"

echo "Marking SAD current..."
# In L001, a firewall currently prevents terraform on the MAD from creating a
# DNS entry in Azure.  Firewall change is underway to correct this.  Unclear
# whether this is the case in P001, but we have a fallback until this is
# confirmed working in both places.

terraform init -input=false -plugin-dir=../../../../../cdktools/terraform-plugins -upgrade
if terraform apply -input=false -auto-approve=true -state=$TF_STATE; then
    echo "Successfully created common SAD DNS entry with terraform."
else
    bash az_create_dns.sh
fi

trap 'bash az_logout.sh' INT TERM EXIT
bash az_login.sh
bash az_shareddisk_attach.sh
