#!/usr/bin/env bash
set -o errexit
source functions_cdktools.sh
source az_env.sh

echo "Attaching shared disk ${AZURE_SHAREDDISK_NAME} to ${AZURE_SAD_NAME}..."

az_retry 300 vm disk attach --name ${AZURE_SHAREDDISK_NAME} --vm-name $AZURE_SAD_NAME --resource-group $AZURE_SAD_RESOURCE_GROUP --caching ReadOnly

cat > shareddisk_attach.sh << 'EOF'
# check if /dev/sdc exists
if [[ ! -b /dev/sdc ]] ; then
    echo "/dev/sdc does not exist -- check if shared disk is attached"
    exit 1
fi

# partition and format disk if needed
if ! fdisk -l /dev/sdc | grep sdc1; then
    echo "Partitioning and formatting new shared disk..."
    echo "n
    p
    1


    w
    "| fdisk /dev/sdc
    mkfs -t ext4 /dev/sdc1
fi

echo "Mounting shared disk..."
mkdir -p /opt/uemcloud/deploy
chown -R uemcloud:uemcloud /opt/uemcloud/deploy

echo "UUID=$(sudo blkid -s UUID -o value /dev/sdc1) /opt/uemcloud/deploy ext4 defaults,nofail 0 2" | sudo tee -a /etc/fstab
mount /opt/uemcloud/deploy

# copy baked-in terraform plugins to cache in shared disk (so older plugins are preserved during upgrades)
mkdir -p /opt/uemcloud/deploy/cdktools/terraform-plugins
cp /usr/lib/terraform-plugins/* /opt/uemcloud/deploy/cdktools/terraform-plugins

chown -R uemcloud:uemcloud /opt/uemcloud/deploy
EOF

scp -q -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null shareddisk_attach.sh $AZURE_SAD_IP:
ssh -qn -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null $AZURE_SAD_IP 'sudo bash /opt/uemcloud/shareddisk_attach.sh'
ssh -qn -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null $AZURE_SAD_IP 'grep /opt/uemcloud/deploy /etc/mtab'
if [[ $? -eq 1 ]]; then
    echo "/opt/uemcloud/deploy is not mounted on ${AZURE_SAD_NAME}"
    exit 1
fi
