#!/usr/bin/env bash
set -o errexit
source functions_cdktools.sh
source az_env.sh

VM_INFO=$(az_retry 300 vm show --name $AZURE_SAD_NAME --resource-group $AZURE_SAD_RESOURCE_GROUP)

if echo $VM_INFO | jq -ne --arg diskname "$AZURE_SHAREDDISK_NAME" 'inputs | .storageProfile.dataDisks[] | select(.name == $diskname)'; then
    echo "Removing shared disk ${AZURE_SHAREDDISK_NAME} from ${AZURE_SAD_NAME}..."

    ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null $AZURE_SAD_IP << 'EOF'
    # only unmount if it is currently mounted
    if mountpoint -q ~/deploy; then
        echo "Unmounting shared disk..."
        COUNT=0
        until sudo umount ~/deploy; do
            if [[ $((COUNT++)) -ge 5 ]]; then
                echo "Failed after 5 attempts."
                exit 1
            fi
            echo "Attempting to kill processes using ~/deploy directory..."
            fuser -v -m ~/deploy -k
            echo "Retrying in 5 seconds (attempt ${COUNT} of 5)..."
            sleep 5
        done
        echo "Shared disk was unmounted."
    fi
EOF

    echo "Detaching shared disk..."
    az_retry 300 vm disk detach --name $AZURE_SHAREDDISK_NAME --vm-name $AZURE_SAD_NAME --resource-group $AZURE_SAD_RESOURCE_GROUP
fi
