#!/usr/bin/env bash
set -o errexit

source functions_cdktools.sh

# clear DNS node records while instances still exist in the scale sets
clear_backend_node_dns_records

terraform init -input=false -plugin-dir=/opt/uemcloud/deploy/cdktools/terraform-plugins -upgrade

pushd ../access_asset_vault
source ./do.sh
popd
export TF_VAR_azure_asset_keyvault_client_secret_encrypted=${KEY_VAULT_CLIENT_SECRET}

# generate PowerShell context script
bash generate_contextualize_ps1.sh

terraform_retry apply -input=false -auto-approve=true -var azure_bemsdocswafl_vmss_capacity=0 -var azure_bemsdocsuos_vmss_capacity=0

pushd ../access_asset_vault
source ./undo.sh
popd

# ensure that DNS pools are cleared for this version
clear_backend_bemsdocs_dns_pool
