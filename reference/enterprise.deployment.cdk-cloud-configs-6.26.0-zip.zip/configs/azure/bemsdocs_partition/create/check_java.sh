#!/bin/bash

CURRENT_VERSION=$(echo "${EPF::adoptopenjdk_package_version}" | sed -e 's/[0-9]*u\([0-9]*\)b[0-9]*/\1/')
curl -X GET "https://api.adoptopenjdk.net/v3/assets/version/%5B8.0.${CURRENT_VERSION}%2C9.0%29?architecture=x64&heap_size=normal&image_type=jdk&jvm_impl=hotspot&lts=true&os=windows&page=0&page_size=20&release_type=ga&vendor=adoptopenjdk" -H "accept: application/json" > jdk.json

NEWEST_VERSION=$(jq '[.[] | {version: .release_name, url: .binaries[0].installer.link}] | del(.[] | select (.url==null)) | sort_by(.version) | .[-1].version' jdk.json | tr -d "\"-")
echo $NEWEST_VERSION

if [ "jdk${EPF::adoptopenjdk_package_version}" != "$NEWEST_VERSION" ]
then
    # generate an SSH key
    if [ ! -f ~/.ssh/uos_sshkey ]
    then
        ssh-keygen -q -N '' -f ~/.ssh/uos_sshkey
    fi

    # download newest
    URL=$(jq '[.[] | {version: .release_name, url: .binaries[0].installer.link}] | del(.[] | select (.url==null)) | sort_by(.version) | .[-1].url' jdk.json | tr -d "\"")
    wget $URL -P ~
    export msi_filename="$(basename $URL)"
    echo command=\"scp -v -f $msi_filename\",no-pty,no-port-forwarding,no-agent-forwarding,no-X11-forwarding $(cat /opt/uemcloud/.ssh/uos_sshkey.pub) >> ~/.ssh/authorized_keys
fi
