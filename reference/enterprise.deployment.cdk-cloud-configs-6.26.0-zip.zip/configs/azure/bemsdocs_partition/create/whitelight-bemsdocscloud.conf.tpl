#The connections below will inject bypass rules into "ip xfrm policy"
#to ensure that all inbound BEMSDocs Cloud traffic is not encrypted with IPSEC

conn whitelist-incoming-bemsdocsuos-service
    left=%defaultroute
    leftprotoport=tcp/${bemsdocsuos_service_pool_port}
    right=0.0.0.0
    rightsubnet=0.0.0.0/0
    rightprotoport=tcp/%any
    auto=route
    type=passthrough
    priority=1000

conn whitelist-incoming-bemsdocsuos-config
    left=%defaultroute
    leftprotoport=tcp/${bemsdocsuos_config_port}
    right=0.0.0.0
    rightsubnet=0.0.0.0/0
    rightprotoport=tcp/%any
    auto=route
    type=passthrough
    priority=1000

conn whitelist-incoming-wafl-hc-bemsdocs
    left=%defaultroute
    leftprotoport=tcp/${bemsdocswafl_hc_port}
    right=0.0.0.0
    rightsubnet=0.0.0.0/0
    rightprotoport=tcp/%any
    auto=route
    type=passthrough
    priority=1000
