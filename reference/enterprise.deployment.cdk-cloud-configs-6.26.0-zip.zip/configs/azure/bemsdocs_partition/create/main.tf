variable "apt_server" {}

variable "azure_asset_keyvault_client_secret_encrypted" {}

variable "azure_bemsdocsuos_availability_zones" { type = "list" }
variable "azure_bemsdocsuos_bootdiag_enabled" {}
variable "azure_bemsdocsuos_bootdiag_storage_account_uri" {}
variable "azure_bemsdocsuos_resource_group" {}
variable "azure_bemsdocsuos_subnet_id" {}
variable "azure_bemsdocsuos_vm_size" {}
variable "azure_bemsdocsuos_vmss_capacity" {}
variable "azure_bemsdocsuos_vmss_nsg_id" {}

variable "azure_bemsdocswafl_availability_zones" { type = "list" }
variable "azure_bemsdocswafl_bootdiag_enabled" {}
variable "azure_bemsdocswafl_bootdiag_storage_account_uri" {}
variable "azure_bemsdocswafl_resource_group" {}
variable "azure_bemsdocswafl_subnet_id" {}
variable "azure_bemsdocswafl_vm_size" {}
variable "azure_bemsdocswafl_vmss_capacity" {}
variable "azure_bemsdocswafl_vmss_nsg_id" {}

variable "azure_client_id" {}
variable "azure_client_secret" {}
variable "azure_deploy_keyvault_encryption_cert_thumbprint" {}
variable "azure_deploy_keyvault_encryption_cert_url" {}
variable "azure_deploy_keyvault_wafl_cert_chain_pem" {}
variable "azure_deploy_keyvault_wafl_cert_thumbprint" {}
variable "azure_deploy_keyvault_wafl_cert_url" {}
variable "azure_deploy_keyvault_id" {}
variable "azure_environment" {}
variable "azure_location" {}
variable "azure_managed_disk_type" {}
variable "azure_subscription_id" {}
variable "azure_tags" { type = "map" }
variable "azure_tenant_id" {}

variable "bemsdocsuos_config_port" {}
variable "bemsdocsuos_healthcheck_port" {}
variable "bemsdocsuos_service_pool_port" {}

variable "env_type" {}

variable "fluent_bit_enabled" {}
variable "fluent_bit_cert_path" {}
variable "fluent_bit_key_path" {}
variable "fluent_bit_custom_include" {}
variable "fluent_bit_custom_include_path" {}
variable "fluent_bit_syslog_to_kafka" {}

variable "hold_packages" {}

variable "kafka_dr" {}

variable "partition_name" {}
variable "partition_version" {}

variable "rapid7_cfg_file" {}

variable "ssh_allowed_groups" { type = "list" }

variable "uos_machinename_construct" {}
variable "uos_admin_username" {}
variable "uos_admin_password" {}

variable "wafl_naxsi_rules_config" {}
variable "wafl_naxsi_rules_service" {}

variable "windows_dsc_joindomain" {}
variable "windows_dsc_registrationurl" {}
variable "windows_dsc_registrationkey" {}
variable "windows_dsc_nodeconfigurationname" {}

variable "whitelight_enabled" {}

variable "zabbix_psk" {}
variable "zabbix_psk_identity" {}

locals {
  wafl_rsyslog_file = "${var.kafka_dr != "true" ? "90-bemsdocscloud-wafl.conf" : "90-bemsdocscloud-wafl-dr.conf" }"
}

#### COMMON ####

data "terraform_remote_state" "image_info" {
    backend = "local"

    config {
        path = "${path.module}/../bake/image_info/terraform.tfstate"
    }
}

data "terraform_remote_state" "bemsdocspartition_prepare" {
    backend = "local"

    config {
        path = "${path.module}/../../../../azure-bemsdocs_partition-prepare-terraform.tfstate"
    }
}

data "template_file" "cloudinit_userdata_zabbix_psk" {
    template = "${var.zabbix_psk == "" ? "" : file("${path.module}/cloudinit_userdata_zabbix_psk.tpl")}"
    vars = {
        zabbix_psk = "${base64encode(var.zabbix_psk)}"
        zabbix_psk_identity = "${var.zabbix_psk_identity}"
        zabbix_psk_ar_script = "${base64encode(file("${path.module}/zabbix_psk_ar.sh"))}"
    }
}

data "template_file" "cloudinit_userdata_server_info" {
    template = "${file("${path.module}/cloudinit_userdata_bb-server-info.tpl")}"
    vars = {
        server_info = "${base64encode(file("${path.module}/bb-server-info.txt"))}"
    }
}

data "template_file" "cloudinit_userdata_hold_packages" {
    template = "${var.hold_packages == "" ? "" : file("${path.module}/cloudinit_userdata_hold_packages.tpl")}"
    vars = {
        hold_packages = "${var.hold_packages}"
    }
}

#### WAFL ####

data "template_file" "bemsdocswafl_cloudinit_userdata" {
    template = "${file("${path.module}/cloudinit_userdata_bemsdocswafl_azure.tpl")}"

    vars {
        apt_server = "${var.apt_server}"
        cert_chain_pem = "${base64encode(file("${var.azure_deploy_keyvault_wafl_cert_chain_pem}"))}"
        cert_path_prefix = "/var/lib/waagent/${var.azure_deploy_keyvault_wafl_cert_thumbprint}"
        encoded_fluentbit_env = "${base64encode(file("${path.module}/fluent-bit.wafl.env"))}"
        encoded_fluentbit_yaml = "${base64encode(file("${path.module}/fluent-bit.wafl.yaml"))}"
        encoded_fluentbit_cert = "${base64encode(file("${var.fluent_bit_cert_path}"))}"
        encoded_fluentbit_key = "${base64encode(file("${var.fluent_bit_key_path}"))}"
        encoded_fluentbit_include = "${var.fluent_bit_custom_include == "true" ? base64encode(file("${var.fluent_bit_custom_include_path}")) : var.fluent_bit_syslog_to_kafka == "true" ? base64encode(file("${path.module}/fluent-bit-include.syslog.yaml")) : base64encode(file("${path.module}/fluent-bit-include.null.yaml"))}"
        encoded_rsyslog_conf = "${var.fluent_bit_enabled == "true" ? base64encode(file("${path.module}/90-bemsdocscloud-wafl.fluent-bit.conf")) : base64encode(file("${path.module}/90-bemsdocscloud-wafl.conf")) }"
        encoded_userparameter_uos_ssl_check_conf = "${base64encode(file("${path.module}/userparameter_uos-ssl-check.conf"))}"
        encoded_wafl_clean_dns_sh = "${base64encode(file("${path.module}/wafl_clean_dns.sh"))}"
        encoded_wafl_health_sh = "${base64encode(file("${path.module}/wafl_health_bemsdocscloud.sh"))}"
        encoded_wafl_init_worker = "${base64encode(file("${path.module}/wafl_init_worker_bemsdocscloud.lua"))}"
        naxsi_bemsdocscloud_config_rules = "${base64encode(file("${var.wafl_naxsi_rules_config}"))}"
        naxsi_bemsdocscloud_service_rules = "${base64encode(file("${var.wafl_naxsi_rules_service}"))}"
        nginx_conf = "${base64encode(file("${path.module}/nginx.conf"))}"
        ssh_groups = "${base64encode(join("\n", var.ssh_allowed_groups))}"
        sudo_rules = "${base64encode(join("\n", formatlist("%%%s ALL=(ALL) ALL", var.ssh_allowed_groups)))}"
        whitelight_conf = "${base64encode(data.template_file.bemsdocswafl_whitelight_conf.rendered)}"
    }
}

data "template_cloudinit_config" "bemsdocswafl_cloudinit_userdata" {
    gzip = true
    base64_encode = true

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.bemsdocswafl_cloudinit_userdata.rendered}"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_zabbix_psk.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_server_info.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_hold_packages.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${var.whitelight_enabled ? "" : file("${path.module}/cloudinit_userdata_whitelight_disable.tpl")}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }
}

data "template_file" "bemsdocswafl_whitelight_conf" {
    template = "${file("${path.module}/whitelight-bemsdocscloud.conf.tpl")}"

    vars {
        bemsdocsuos_config_port = "${var.bemsdocsuos_config_port}"
        bemsdocsuos_service_pool_port = "${var.bemsdocsuos_service_pool_port}"
        bemsdocswafl_hc_port = "1${var.bemsdocsuos_healthcheck_port}"
    }
}

resource "azurerm_virtual_machine_scale_set" "bemsdocswafl" {
    name = "${var.partition_name}-wafl-${var.partition_version}"
    location = "${var.azure_location}"
    overprovision = false
    resource_group_name = "${var.azure_bemsdocswafl_resource_group}"
    upgrade_policy_mode = "Manual"
    zones = "${var.azure_bemsdocswafl_availability_zones}"

    sku {
        name = "${var.azure_bemsdocswafl_vm_size}"
        tier = "Standard"
        capacity = "${var.azure_bemsdocswafl_vmss_capacity}"
    }

    os_profile {
        computer_name_prefix = "${var.partition_name}-wafl-${var.partition_version}-"
        custom_data = "${data.template_cloudinit_config.bemsdocswafl_cloudinit_userdata.rendered}"
        admin_username = "disabledbygts"
        admin_password = "DisabledByGTS1!"
    }

    os_profile_linux_config {
        disable_password_authentication = false
    }

    os_profile_secrets {
        source_vault_id = "${var.azure_deploy_keyvault_id}"
        vault_certificates {
            certificate_url = "${var.azure_deploy_keyvault_wafl_cert_url}"
        }
    }

    network_profile {
        name = "${var.partition_name}-wafl-nic"
        network_security_group_id = "${var.azure_bemsdocswafl_vmss_nsg_id}"
        primary = true

        ip_configuration {
            name = "${var.partition_name}-wafl-ipcf"
            primary = true
            subnet_id = "${var.azure_bemsdocswafl_subnet_id}"
            load_balancer_backend_address_pool_ids = [
                "${data.terraform_remote_state.bemsdocspartition_prepare.lb_internal_wafl_bap_id}",
                "${data.terraform_remote_state.bemsdocspartition_prepare.lb_public_wafl_bap_id}"
            ]
        }
    }

    storage_profile_image_reference {
        id = "${data.terraform_remote_state.image_info.baked_wafl_id}"
    }

    storage_profile_os_disk {
        caching = "ReadWrite"
        create_option = "FromImage"
        managed_disk_type = "${var.azure_managed_disk_type}"
    }

    boot_diagnostics {
        enabled = "${var.azure_bemsdocswafl_bootdiag_enabled}"
        storage_uri = "${var.azure_bemsdocswafl_bootdiag_storage_account_uri}"
    }

    tags = "${merge(
                var.azure_tags,
                map("bb:component", "wafl"),
                map("bemsdocscloud.owner_hostname", trimspace(file("/etc/hostname")))
            )}"

}

#### UOS ####
resource "azurerm_virtual_machine_scale_set" "bemsdocsuos" {
    count = "${var.windows_dsc_joindomain ? 0 : 1}"
    name = "${var.partition_name}-uos-${var.partition_version}"
    location = "${var.azure_location}"
    overprovision = false
    resource_group_name = "${var.azure_bemsdocsuos_resource_group}"
    upgrade_policy_mode = "Manual"
    zones = "${var.azure_bemsdocsuos_availability_zones}"
    license_type = "Windows_Server"

    sku {
        name = "${var.azure_bemsdocsuos_vm_size}"
        tier = "Standard"
        capacity = "${var.azure_bemsdocsuos_vmss_capacity}"
    }

    os_profile {
        computer_name_prefix = "${var.uos_machinename_construct}"
        custom_data = "${file("./contextualize.ps1")}"
        admin_username = "LocalAdminAccount"
        admin_password = "DisabledByGTS1!"
    }

    os_profile_windows_config {
        provision_vm_agent = true
    }

    os_profile_secrets {
        source_vault_id = "${var.azure_deploy_keyvault_id}"
        vault_certificates {
            certificate_url = "${var.azure_deploy_keyvault_encryption_cert_url}"
            certificate_store = "BEMSDocsStore"
        }
    }

    network_profile {
        name = "bemsdocsuos-vmss-nic"
        network_security_group_id = "${var.azure_bemsdocsuos_vmss_nsg_id}"
        primary = true

        ip_configuration {
            name = "bemsdocsuos-vmss-ipcf"
            primary = true
            subnet_id = "${var.azure_bemsdocsuos_subnet_id}"
        }
    }

    storage_profile_image_reference {
        id = "${data.terraform_remote_state.image_info.baked_uos_id}"
    }

    storage_profile_os_disk {
        caching = "ReadWrite"
        create_option = "FromImage"
        managed_disk_type = "${var.azure_managed_disk_type}"
    }

    boot_diagnostics {
        enabled = "${var.azure_bemsdocsuos_bootdiag_enabled}"
        storage_uri = "${var.azure_bemsdocsuos_bootdiag_storage_account_uri}"
    }

    tags = "${merge(
                var.azure_tags,
                map("bb:component", "uos"),
                map("bemsdocscloud.owner_hostname", trimspace(file("/etc/hostname")))
            )}"

    extension {
        name = "Microsoft.Compute.CustomScriptExtension"
        publisher = "Microsoft.Compute"
        type = "CustomScriptExtension"
        type_handler_version = "1.9"
        settings = <<SETTINGS
        {
            "commandToExecute": "powershell.exe -command \"New-Item -Path C:\\ -Name temp -ItemType directory -Force; Copy-Item C:\\AzureData\\CustomData.bin C:\\temp\\context.ps1\" -Force ; powershell.exe -ExecutionPolicy Unrestricted -sta -File \"C:\\temp\\context.ps1\""
        }
        SETTINGS
    }
}

#### UOS -- duplicate of above to handle DSC extension ####
resource "azurerm_virtual_machine_scale_set" "bemsdocsuos_joindomain" {
    count = "${var.windows_dsc_joindomain ? 1 : 0}"
    name = "${var.partition_name}-uos-${var.partition_version}"
    location = "${var.azure_location}"
    overprovision = false
    resource_group_name = "${var.azure_bemsdocsuos_resource_group}"
    upgrade_policy_mode = "Manual"
    zones = "${var.azure_bemsdocsuos_availability_zones}"
    license_type = "Windows_Server"

    sku {
        name = "${var.azure_bemsdocsuos_vm_size}"
        tier = "Standard"
        capacity = "${var.azure_bemsdocsuos_vmss_capacity}"
    }

    os_profile {
        computer_name_prefix = "${var.uos_machinename_construct}"
        custom_data = "${file("./contextualize.ps1")}"
        admin_username = "LocalAdminAccount"
        admin_password = "DisabledByGTS1!"
    }

    os_profile_windows_config {
        provision_vm_agent = true
    }

    os_profile_secrets {
        source_vault_id = "${var.azure_deploy_keyvault_id}"
        vault_certificates {
            certificate_url = "${var.azure_deploy_keyvault_encryption_cert_url}"
            certificate_store = "BEMSDocsStore"
        }
    }

    network_profile {
        name = "bemsdocsuos-vmss-nic"
        network_security_group_id = "${var.azure_bemsdocsuos_vmss_nsg_id}"
        primary = true

        ip_configuration {
            name = "bemsdocsuos-vmss-ipcf"
            primary = true
            subnet_id = "${var.azure_bemsdocsuos_subnet_id}"
        }
    }

    storage_profile_image_reference {
        id = "${data.terraform_remote_state.image_info.baked_uos_id}"
    }

    storage_profile_os_disk {
        caching = "ReadWrite"
        create_option = "FromImage"
        managed_disk_type = "${var.azure_managed_disk_type}"
    }

    boot_diagnostics {
        enabled = "${var.azure_bemsdocsuos_bootdiag_enabled}"
        storage_uri = "${var.azure_bemsdocsuos_bootdiag_storage_account_uri}"
    }

    tags = "${merge(
                var.azure_tags,
                map("bb:component", "uos"),
                map("bemsdocscloud.owner_hostname", trimspace(file("/etc/hostname")))
            )}"

    extension {
        name = "Microsoft.Compute.CustomScriptExtension"
        publisher = "Microsoft.Compute"
        type = "CustomScriptExtension"
        type_handler_version = "1.9"
        settings = <<SETTINGS
        {
            "commandToExecute": "powershell.exe -command \"New-Item -Path C:\\ -Name temp -ItemType directory -Force; Copy-Item C:\\AzureData\\CustomData.bin C:\\temp\\context.ps1\" -Force ; powershell.exe -ExecutionPolicy Unrestricted -sta -File \"C:\\temp\\context.ps1\""
        }
        SETTINGS
    }

    extension {
        name = "Microsoft.Powershell.DSC"
        publisher = "Microsoft.Powershell"
        type = "DSC"
        type_handler_version = "2.77"
        settings = <<SETTINGS
        {
            "WmfVersion": "latest",
            "Privacy": {
                "DataCollection": ""
            },
            "Properties": {
                "RegistrationKey": {
                  "UserName": "PLACEHOLDER_DONOTUSE",
                  "Password": "PrivateSettingsRef:registrationKeyPrivate"
                },
                "RegistrationURL": "${var.windows_dsc_registrationurl}",
                "NodeConfigurationName": "${var.windows_dsc_nodeconfigurationname}",
                "ConfigurationMode": "ApplyAndMonitor",
                "ConfigurationModeFrequencyMins": 15,
                "RefreshFrequencyMins": 30,
                "RebootNodeIfNeeded": true,
                "ActionAfterReboot": "continueConfiguration",
                "AllowModuleOverwrite": true
            }
        }
        SETTINGS

        protected_settings = <<PROTECTED_SETTINGS
        {
            "Items": {
                "registrationKeyPrivate" : "${var.windows_dsc_registrationkey}"
            }
        }
        PROTECTED_SETTINGS
    }
}

