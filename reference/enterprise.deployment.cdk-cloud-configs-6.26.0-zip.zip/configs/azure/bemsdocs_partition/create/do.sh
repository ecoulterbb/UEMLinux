#!/usr/bin/env bash
set -o errexit

source functions_cdktools.sh

terraform init -input=false -plugin-dir=/opt/uemcloud/deploy/cdktools/terraform-plugins -upgrade

pushd ../access_asset_vault
source ./do.sh
popd
export TF_VAR_azure_asset_keyvault_client_secret_encrypted=${KEY_VAULT_CLIENT_SECRET}
update_client_secret_monitoring

# rsyslog to kafka toggle
if [ "${EPF::fluent_bit_syslog_to_kafka}" != "true" ]
then
    # add stop if not sending to kafka to prevent rsyslog becoming unresponsive
    sed -i '/# stop anchor/astop' 90-*.fluent-bit.conf
fi

# check for new Java
if [ "${EPF::java_upgrade_on_deploy}" == "true" ]
then
    source check_java.sh
fi

# generate PowerShell context script
bash generate_contextualize_ps1.sh

terraform_retry apply -input=false -auto-approve=true

pushd ../access_asset_vault
source ./undo.sh
popd
