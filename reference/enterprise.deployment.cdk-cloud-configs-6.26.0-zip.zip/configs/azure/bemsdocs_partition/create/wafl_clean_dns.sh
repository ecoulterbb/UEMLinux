#!/usr/bin/env bash
function remove_from_backend () {
    IP_TO_REMOVE=$1
    shift
    BACKEND_VERSIONED="$@"

    if [ -f /etc/default/bbddns ]; then
        . /etc/default/bbddns
    fi

    [ -n "${TSIG_FWD}" ] && FWD_TSIG="-y ${TSIG_FWD}"
    [ -n "${DDNS_ANYCAST}" ] && DDNS_ANYCONF="server ${DDNS_ANYCAST}"

    for BACKEND in ${BACKEND_VERSIONED}
    do
        /usr/bin/nsupdate -d ${FWD_TSIG} <<EOF
${DDNS_ANYCONF}
zone ${DDNS_ZONE}.
update delete ${BACKEND} A ${IP_TO_REMOVE}
send
EOF
    done
}

echo "$0 script starting"
BACKEND_UOS_VERSIONED='${EPF::uos_backend_bemsdocs_versioned}'
BACKEND_UOS_PREFIX='${EPF::epf_partition_name}-uos-${EPF::bundle_version}d${EPF::deployment_version}'
BACKEND_UOS_CURRENT_LOOKUP=$(dig +short ${BACKEND_UOS_VERSIONED} | sort | uniq)
    
if [ $( cat /proc/uptime | cut -d. -f 1 ) -lt 4200 ]
then
    echo "Skipping as uptime lower than 70m"
    exit 0
fi

echo "Backend IPs: ${BACKEND_UOS_CURRENT_LOOKUP}"

for IP_ADDRESS in ${BACKEND_UOS_CURRENT_LOOKUP}
do
    # skip if we've already removed the IP
    if [[ -e /tmp/${IP_ADDRESS}.removed ]]
    then
        echo "Skipping ${IP_ADDRESS} as already cleaned."
        continue
    fi

    # lookup rDNS record and verify the prefix matches
    REVERSE_DNS_LOOKUP=$(dig +short -x ${IP_ADDRESS})

    if [[ $? -ne 0 ]]; then
        echo "Error resolving reverse record for ${IP_ADDRESS}, skipping"
        continue
    fi

    if [[ -z "${REVERSE_DNS_LOOKUP}" ]]; then
        echo "No reverse record for IPs found for ${IP_ADDRESS}, skipping."
        continue
    fi

    echo "${REVERSE_DNS_LOOKUP}" | egrep "^${BACKEND_UOS_PREFIX}" > /dev/null
    if [[ $? -ne 0 ]]
    then
        # otherwise cleanup the record
        echo "RDNS record ${IP_ADDRESS} does not match prefix.  Removing IP from DNS pool(s): ${BACKEND_UOS_VERSIONED}"
        remove_from_backend ${IP_ADDRESS} ${BACKEND_UOS_VERSIONED}
        touch /tmp/${IP_ADDRESS}.removed
        continue
    fi
done

for REMOVED in $(find /tmp -type f -name '*.removed')
do
    if [[ $(( $(date +%s) - $(date +%s -r ${REMOVED}) )) -gt 300 ]]
    then
        rm ${REMOVED}
    fi
done

echo "$0 script finished"
