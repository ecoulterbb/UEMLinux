#!/usr/bin/env bash

terraform_retry_cleanup() {
    TF_STATE=${TF_STATE:-terraform.tfstate}

    # if VM doesn't exist in state, try importing so any previous failed copy will be cleaned up on retry
    if [ "x${EPF::windows_dsc_joindomain}" == "x1" ]; then
        if ! terraform state list -state=$TF_STATE | grep -F azurerm_virtual_machine_scale_set.bemsdocsuos_joindomin; then
            terraform import -state=$TF_STATE azurerm_virtual_machine_scale_set.bemsdocsuos_joindomain "/subscriptions/${EPF::azure_subscription_id}/resourceGroups/${EPF::azure_bemsuos_resource_group}/providers/Microsoft.Compute/virtualMachineScaleSets/${EPF::epf_partition_name}-uos-${EPF::bundle_version}d${EPF::deployment_version}" || true
        fi
    else
        if ! terraform state list -state=$TF_STATE | grep -F azurerm_virtual_machine_scale_set.bemsdocsuos; then
            terraform import -state=$TF_STATE azurerm_virtual_machine_scale_set.bemsdocsuos "/subscriptions/${EPF::azure_subscription_id}/resourceGroups/${EPF::azure_bemsuos_resource_group}/providers/Microsoft.Compute/virtualMachineScaleSets/${EPF::epf_partition_name}-uos-${EPF::bundle_version}d${EPF::deployment_version}" || true
        fi
    fi

    if ! terraform state list -state=$TF_STATE | grep -F azurerm_virtual_machine_scale_set.bemsdocswafl; then
        terraform import -state=$TF_STATE azurerm_virtual_machine_scale_set.bemsdocswafl "/subscriptions/${EPF::azure_subscription_id}/resourceGroups/${EPF::azure_bemswafl_resource_group}/providers/Microsoft.Compute/virtualMachineScaleSets/${EPF::epf_partition_name}-wafl-${EPF::bundle_version}d${EPF::deployment_version}" || true
    fi

    # if there was a transient error, we should start from scratch
    echo "Destroying failed infrastructure..."
    terraform destroy -force -state=$TF_STATE
}

function clear_dns_pool () {
    BACKEND_VERSIONED=$1
    [ "${BACKEND_VERSIONED}" == "." ] && return 0

    if [ -f /etc/default/bbddns ]; then
        export $(sudo cat /etc/default/bbddns | grep -v "#" | xargs)
    fi

    [ -n "${TSIG_FWD}" ] && FWD_TSIG="-y ${TSIG_FWD}"
    [ -n "${DDNS_ANYCAST}" ] && DDNS_ANYCONF="server ${DDNS_ANYCAST}"

    echo "Clearing DNS A record ${BACKEND_VERSIONED}"
            /usr/bin/nsupdate -d ${FWD_TSIG} <<EOF
${DDNS_ANYCONF}
zone $DDNS_ZONE.
update delete ${BACKEND_VERSIONED} A
send
EOF
}

function clear_backend_bemsdocs_dns_pool () {
    echo "DNS Pool Clear script starting"

    # DNS pool to clear
    clear_dns_pool "${EPF::uos_backend_bemsdocs_versioned}."

    echo "DNS Pool Clear script finished"
}

# construct a 9 character long machine prefix for 15 character long Windows VM name (6 characters for VMSS)
UOS_MACHINE_PREFIX='${EPF::epf_partition_name}-${EPF::bundle_version}d${EPF::deployment_version}.${EPF::machine_domain}'
export TF_VAR_uos_machinename_construct=${UOS_MACHINE_PREFIX:0:6}`echo -n ${UOS_MACHINE_PREFIX:3} | openssl dgst -binary -sha256 | base32 | cut -c1-3`

function clear_backend_node_dns_records () {
    set +o errexit
    TF_STATE=${TF_STATE:-terraform.tfstate}
    terraform state list -state=$TF_STATE | grep azurerm_virtual_machine_scale_set >/dev/null
    if [[ $? -ne 0 ]] ; then
        echo "DNS Computer Names Clear script skipped"
        return 0
    fi
    set -o errexit

    echo "DNS Computer Names Clear script starting"
    source az_get_computer_names.sh

    # DNS nodes to clear
    set +o errexit
    for NODE in ${BACKEND_COMPUTER_NAMES}; do
      clear_dns_pool "${NODE}.${DNS_INTERNAL_ZONE}."
    done
    set -o errexit

    echo "DNS Computer Names Clear script finished"
}

function update_client_secret_monitoring () {
    echo "Updating client secret monitoring records"
    mkdir -p /opt/uemcloud/.cs_monitoring
    echo $TF_VAR_azure_client_secret_key_id > /opt/uemcloud/.cs_monitoring/${EPF::epf_partition_name}.key_id.txt
    echo $TF_VAR_azure_client_secret_end_date > /opt/uemcloud/.cs_monitoring/${EPF::epf_partition_name}.end_date.txt
    chmod -R 755 /opt/uemcloud/.cs_monitoring
}
