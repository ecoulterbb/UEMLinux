#cloud-config
domain: ${EPF::machine_domain}
auth_domain: ${EPF::auth_domain}
auth_adbinduser: ${EPF::auth_adbinduser}
auth_adbindpass: ${EPF::auth_adbindpass}
auth_adsearchbase: ${EPF::auth_adsearchbase}
${ apt_server != "" ? "
apt_preserve_sources_list: true
apt_sources:
  - source: deb ${EPF::apt_server} $RELEASE main restricted universe
  - source: deb ${EPF::apt_server} $RELEASE-security main restricted universe
  - source: deb ${EPF::apt_server} $RELEASE-updates main restricted universe
" : "apt_preserve_sources_list: true\n"}
write_files:
- path: /etc/sudoers.d/my-sudo-rules
  content: ${sudo_rules}
  encoding: b64
  owner: root:root
  permissions: '0600'
- path: /etc/ssh/groups.allow
  content: ${ssh_groups}
  encoding: b64
  owner: root:root
  permissions: '0600'
- path: /etc/default/bbddns
  content: |
    DDNS_ZONE="${EPF::dns_internal_zone}"
    TSIG_FWD="${EPF::dns_tsig_fwd}"
    TSIG_PTR="${EPF::dns_tsig_ptr}"
    DDNS_TTL=300
  owner: root:root
  permissions: '600'
- path: /usr/local/openresty/nginx/conf/naxsi_bemsdocscloud_config.rules
  content: ${naxsi_bemsdocscloud_config_rules}
  encoding: b64
  owner: root:root
- path: /usr/local/openresty/nginx/conf/naxsi_bemsdocscloud_service.rules
  content: ${naxsi_bemsdocscloud_service_rules}
  encoding: b64
  owner: root:root
- path: /usr/local/openresty/nginx/conf/nginx.conf
  content: ${nginx_conf}
  encoding: b64
  owner: root:root
- path: /etc/default/fluent-bit
  content: ${encoded_fluentbit_env}
  encoding: b64
  owner: root:root
  permissions: '0644'
- path: /etc/fluent-bit/fluent-bit.yaml
  content: ${encoded_fluentbit_yaml}
  encoding: b64
  owner: root:root
  permissions: '0644'
- path: /etc/fluent-bit/fluent-bit-include.yaml
  content: ${encoded_fluentbit_include}
  encoding: b64
  owner: root:root
  permissions: '0644'
- path: /etc/fluent-bit/observability.uem.crt
  content: ${encoded_fluentbit_cert}
  encoding: b64
  owner: root:root
  permissions: '0644'
- path: /etc/fluent-bit/observability.uem.key
  content: ${encoded_fluentbit_key}
  encoding: b64
  owner: root:root
  permissions: '0644'
- path: /etc/rsyslog.d/90-bemsdocscloud-wafl.conf
  content: ${encoded_rsyslog_conf}
  encoding: b64
- path: /usr/local/openresty/nginx/conf/wafl_init_worker.lua
  content: ${encoded_wafl_init_worker}
  encoding: b64
  owner: root:root
- path: /root/wafl_health.sh
  content: ${encoded_wafl_health_sh}
  encoding: b64
  owner: root:root
  permissions: '0755'
- path: /root/wafl_clean_dns.sh
  content: ${encoded_wafl_clean_dns_sh}
  encoding: b64
  owner: root:root
  permissions: '0755'
- path: /etc/zabbix/zabbix_agentd.d/userparameter_uos-ssl-check.conf
  content: ${encoded_userparameter_uos_ssl_check_conf}
  encoding: b64
  owner: root:root
  permissions: '0644'
- path: /etc/ipsec.d/whitelist-bemsdocscloud.conf
  content: ${whitelight_conf}
  encoding: b64
  owner: root:root
- path: /tmp/cert_chain.pem
  content: ${cert_chain_pem}
  encoding: b64
  owner: root:root
runcmd:
- sed -i "s/key=\"{{REPLACE_ME}}\"/key=\"$$(hostname -f)\"/g" /etc/rsyslog.d/90-bemsdocscloud-wafl.conf
- sed -i "s/LocalHostName {{REPLACE_ME}}/LocalHostName $$(hostname -f)/" /etc/rsyslog.d/90-bemsdocscloud-wafl.conf
- service rsyslog restart
# setup fluent-bit
- 'if [ "${EPF::fluent_bit_enabled}" = "true" ] ; then'
- sed -i "s/{{REPLACE_ME}}/$$(hostname -f)/g" /etc/default/fluent-bit
- systemctl enable fluent-bit
- systemctl start fluent-bit
- 'fi'
# configure and restart zabbix agent
- sed -i "s/Server=.*/Server=${EPF::zabbix_servers}/" /etc/zabbix/zabbix_agentd.conf
- sed -i "s/ServerActive=.*/ServerActive=${EPF::zabbix_servers}/" /etc/zabbix/zabbix_agentd.conf
- sed -i "s/HostMetadata=.*/HostMetadata=${EPF::zabbix_serviceteam}-WAFL/" /etc/zabbix/zabbix_agentd.conf
- sed -i "s/Hostname=.*/Hostname=$$(hostname -f)/" /etc/zabbix/zabbix_agentd.conf
- sed -i "s/ListenIP=.*/ListenIP=$$(ip -f inet -o addr | grep -wv '127.0.0.1' | tail -1 | awk '{print $4}' | cut -d/ -f 1)/" /etc/zabbix/zabbix_agentd.conf
- sed -i "s/UserParameter=system.serviceteam, echo.*/UserParameter=system.serviceteam, echo ${EPF::zabbix_serviceteam}/" /etc/zabbix/zabbix_agentd.conf
- sed -i "s/StartAgents=.*/StartAgents=${EPF::zabbix_startagents_bemsdocswafl}/" /etc/zabbix/zabbix_agentd.conf
- service zabbix-agent restart
# combine cert with chain, remove extra copies of secrets
- rm -rf /var/lib/waagent/Certificates.*
- mv ${cert_path_prefix}.prv /usr/local/openresty/nginx/conf/cert.prv
# verify that cert is signed by intermediate chain and copy
- openssl verify -no-CAfile -no-CApath -partial_chain -trusted /tmp/cert_chain.pem ${cert_path_prefix}.crt && cat ${cert_path_prefix}.crt /tmp/cert_chain.pem > /usr/local/openresty/nginx/conf/cert.crt
# start openresty/nginx
- systemctl enable openresty
- service openresty start
# configure wafl health script
- echo "PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin:\$PATH\n* * * * * root /root/wafl_health.sh\n*/2 * * * * root /root/wafl_clean_dns.sh" > /etc/cron.d/wafl_health
- chmod 400 /etc/cron.d/wafl_health
