#!/bin/bash

# Azure - generate AES key/IV, encrypt the RSA private key, encrypt the AES key with RSA public key
dd if=/dev/random of=/dev/shm/aes-kiv bs=48 count=1
KIV=`xxd -p -u -c 64 /dev/shm/aes-kiv`
K=${KIV:0:64}
IV=${KIV:64:32}
B64_DECRYPTION_KEY=`cat /opt/uemcloud/decryption.key | openssl aes-256-cbc -e -K $K -iv $IV -nosalt | base64 -w0`
B64_AES_KIV=`cat /dev/shm/aes-kiv | openssl rsautl -encrypt -pubin -inkey /opt/uemcloud/encryption.key | base64 -w0`

# Common
CONTEXTUALIZE_PATH=/opt/uemcloud/cloud-deploy-configs/common/powershell/bemsdocs_uos_contextualize
JINJA_BIN=/usr/local/bin/jinja2

B64_LOGSTASH=`${JINJA_BIN} ${CONTEXTUALIZE_PATH}/logstash.conf.j2 jinja2_vars.yml | base64 -w0`
B64_LOGSTASH_OUTPUT_KAFKA=`${JINJA_BIN} ${CONTEXTUALIZE_PATH}/logstash-output-kafka.conf.j2 jinja2_vars.yml | base64 -w0`
B64_LOGSTASH_OUTPUT_SYSLOG=`${JINJA_BIN} ${CONTEXTUALIZE_PATH}/logstash-output-syslog.conf.j2 jinja2_vars.yml | base64 -w0`

if [[ "xtrue" == "x${EPF::kafka_disable}" ]]
then
    B64_LOGSTASH_PIPELINES=`${JINJA_BIN} ${CONTEXTUALIZE_PATH}/pipelines.yml.j2 jinja2_vars.yml | sed -e '/kafka/s/^/#/' | base64 -w0`
    B64_LOGSTASH_INPUT=`${JINJA_BIN} ${CONTEXTUALIZE_PATH}/logstash-input.conf.j2 jinja2_vars.yml | sed -e 's/kafka_output, //' | base64 -w0`
else
    # Dual logstash
    if [[ "xtrue" == "x${EPF::kafka_dr}" ]]
    then
        B64_LOGSTASH_PIPELINES=`${JINJA_BIN} ${CONTEXTUALIZE_PATH}/pipelines_dr.yml.j2 jinja2_vars.yml | base64 -w0`
        B64_LOGSTASH_INPUT=`${JINJA_BIN} ${CONTEXTUALIZE_PATH}/logstash-input_dr.conf.j2 jinja2_vars.yml | base64 -w0`
        B64_LOGSTASH_OUTPUT_KAFKA_DR=`${JINJA_BIN} ${CONTEXTUALIZE_PATH}/logstash-output-kafka-dr.conf.j2 jinja2_vars.yml | base64 -w0`
    else
        B64_LOGSTASH_PIPELINES=`${JINJA_BIN} ${CONTEXTUALIZE_PATH}/pipelines.yml.j2 jinja2_vars.yml | base64 -w0`
        B64_LOGSTASH_INPUT=`${JINJA_BIN} ${CONTEXTUALIZE_PATH}/logstash-input.conf.j2 jinja2_vars.yml | base64 -w0`
    fi
fi

B64_DCI=`${JINJA_BIN} ${CONTEXTUALIZE_PATH}/com.good.gcs.broker.DynamicClusterInfo.cfg.j2 jinja2_vars.yml | base64 -w0`
B64_RDNS=`${JINJA_BIN} ${CONTEXTUALIZE_PATH}/rdnsupdate.txt.j2 jinja2_vars.yml | base64 -w0`
B64_DNS=`${JINJA_BIN} ${CONTEXTUALIZE_PATH}/dnsupdate_azure.txt.j2 jinja2_vars.yml | base64 -w0`
B64_WSUS=`${JINJA_BIN} ${CONTEXTUALIZE_PATH}/wsus.reg.j2 jinja2_vars.yml | base64 -w0`

# PSK
if [[ "x" == "x${EPF::zabbix_psk}" ]]
then
    B64_ZABBIX=`${JINJA_BIN} ${CONTEXTUALIZE_PATH}/zabbix_agentd.conf.j2 jinja2_vars.yml | base64 -w0`
else
    B64_ZABBIX=`${JINJA_BIN} ${CONTEXTUALIZE_PATH}/zabbix_agentd_psk.conf.j2 jinja2_vars.yml | base64 -w0`
fi

# Temp until change committed into bemsdocs-bundle
sed -i 's|/opt/uemcloud/decryption.key|${EPF::azure_deploy_keyvault_encryption_privatekey_windows}|' /opt/uemcloud/deploy/${EPF::epf_partition_name}/${EPF::bundle_version}d${EPF::deployment_version}/machine.properties

(
echo "Start-Transcript -Path C:\\Temp\\contextualize.log -Append"
echo "## configuration files"
echo "# logstash.conf"
echo "\$logstashconf_b64=\"${B64_LOGSTASH}\""
echo "\$logstash_pipelines_b64=\"${B64_LOGSTASH_PIPELINES}\""
echo "\$logstash_inputconf_b64=\"${B64_LOGSTASH_INPUT}\""
echo "\$logstash_outputkafkaconf_b64=\"${B64_LOGSTASH_OUTPUT_KAFKA}\""
if [[ "xtrue" == "x${EPF::kafka_dr}" ]]
then
    echo "\$logstash_outputkafkadrconf_b64=\"${B64_LOGSTASH_OUTPUT_KAFKA_DR}\""
fi
echo "\$logstash_outputsyslogconf_b64=\"${B64_LOGSTASH_OUTPUT_SYSLOG}\""
echo "# machine.properties"
echo "\$machineprop_b64=\"`base64 -w0 /opt/uemcloud/deploy/${EPF::epf_partition_name}/${EPF::bundle_version}d${EPF::deployment_version}/machine.properties`\""
echo "# root.crt"
echo "\$rootcrt_b64=\"`base64 -w0 /opt/uemcloud/.postgresql/root.crt`\""
echo "# com.good.gcs.broker.DynamicClusterInfo.cfg"
echo "\$dci_b64=\"${B64_DCI}\""
echo "## DNS updates"
echo "\$rdnsupdate_b64=\"${B64_RDNS}\""
echo "\$dnsupdate_b64=\"${B64_DNS}\""
echo "\$addm_b64=\"`base64 -w0 /opt/uemcloud/deploy/${EPF::epf_partition_name}/${EPF::bundle_version}d${EPF::deployment_version}/azure/bemsdocs_partition/create/bb-server-info.txt`\""
echo "## SCCM variables"
echo "\$sccm_install=${EPF::windows_sccm_install}"
echo "\$sccm_mp=\"${EPF::windows_sccm_mp}\""
echo "\$sccm_smssitecode=\"${EPF::windows_sccm_smssitecode}\""
echo "\$sccm_fsp=\"${EPF::windows_sccm_fsp}\""
echo "\$sccm_dnssuffix=\"${EPF::windows_sccm_dnssuffix}\""
echo "\$sccm_smsslp=\"${EPF::windows_sccm_smsslp}\""
echo "## Zabbix variables"
echo "\$zabbix_b64=\"${B64_ZABBIX}\""
echo "\$zabbix_install=${EPF::zabbix_install}"
if [[ "x" != "x${EPF::zabbix_psk}" ]]
then
  echo "\$zabbix_psk=\"${EPF::zabbix_psk}\""
fi

# only if defined
if [[ "x" != "x${EPF::wsus_server}" ]]
then
  echo "## WSUS variable"
  echo "\$wsus_b64=\"${B64_WSUS}\""
fi

if [[ "x" != "x${EPF::uos_addmdisc_password}" ]]
then
  echo "\$addmdisc_password=\"${EPF::uos_addmdisc_password}\""
fi

if [[ "x" != "x${EPF::nexpose_account}" ]]
then
  echo "\$nexpose_account=\"${EPF::nexpose_account}\""
fi

if [[ "x" != "x${EPF::nexpose_password}" ]]
then
  echo "\$nexpose_password=\"${EPF::nexpose_password}\""
fi

echo "## Azure variables"
echo "# decryption key"
echo "\$decryption_key_b64=\"${B64_DECRYPTION_KEY}\""
echo "\$decryption_key_path=\"${EPF::azure_deploy_keyvault_encryption_privatekey_windows}\""
echo "\$cert_thumbprint=\"${EPF::azure_deploy_keyvault_encryption_cert_thumbprint}\""
echo "\$aes_kiv_enc_b64=\"${B64_AES_KIV}\""
echo "# KeyVault environment variable"
echo "\$keyvault_secret=\"${TF_VAR_azure_asset_keyvault_client_secret_encrypted}\""
echo "# dns tsigs"
echo "\$dns_tsig_fwd=\"${EPF::dns_tsig_fwd}\""
echo "\$dns_tsig_ptr=\"${EPF::dns_tsig_ptr}\""

if [ -f /opt/uemcloud/.ssh/uos_sshkey ]
then
    echo "## Java update"
    echo "\$sshkey_b64=\"`base64 -w0 /opt/uemcloud/.ssh/uos_sshkey`\""
    echo "\$sad_ip=\"`hostname -i`\""
    echo "\$msi_filename=\"$msi_filename\""
    echo "\$admin_user=\"${EPF::uos_admin_username}\""
fi

echo ""

if [[ "${EPF::fips_mode}" == "true" ]]
then
    echo 'Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\FIPSAlgorithmPolicy" -Name Enabled -Value 1'
    echo 'Start-Sleep -s 10'
fi

echo '$upload_dir="D:\bems\data\upload"'
echo ""

${JINJA_BIN} ${CONTEXTUALIZE_PATH}/contextualize.ps1.j2 jinja2_vars.yml
echo "Stop-Transcript"
) > contextualize.ps1
