local hc = require "resty.upstream.healthcheck"

local function setup_healthcheck(upstream, port)
  local ok, err = hc.spawn_checker{
    upstream = upstream, -- defined by "upstream"
    port = port,
    type = "http",

    http_req = "GET /health HTTP/1.0\r\n\r\n",
            -- raw HTTP request for checking

    interval = ${EPF::wafl_healthcheck_interval},  -- how often to run the checks, in ms
    timeout = ${EPF::wafl_healthcheck_timeout},   -- timeout for network operations, in ms
    fall = ${EPF::wafl_healthcheck_fall},  -- # of successive failures before turning a peer down
    rise = ${EPF::wafl_healthcheck_rise},  -- # of successive successes before turning a peer up
    valid_statuses = {200},  -- a list of valid HTTP status codes
    concurrency = 10,  -- concurrency level for test requests
  }
  if not ok then
      ngx.log(ngx.ERR, "failed to spawn health checker: ", err)
      return
  end
end

setup_healthcheck("uos_service_backend", ${EPF::bemsdocsuos_healthcheck_port})
setup_healthcheck("uos_config_backend", ${EPF::bemsdocsuos_healthcheck_port})
