#!/usr/bin/env bash
source bash_env.sh

function wait_for_uos_quorum() {
    SERVICE=$1
    BACKEND_VERSIONED=$2

    if [ -z "${UOS_QUORUM}" ]; then
        echo "No quorum set for UoS ${SERVICE^^}, moving on."
        return 0
    fi

    if [ -z "${UOS_COUNT}" ]; then
        echo "No uos count set for UoS ${SERVICE^^}, moving on."
        return 0
    fi

    if [ "${UOS_QUORUM}" -gt "${UOS_COUNT}" ]; then
        echo "[ERROR] UoS ${SERVICE^^} quorum ${UOS_QUORUM} cannot be greater than ${UOS_COUNT} total nodes."
        exit 1
    fi

    echo "Waiting for a quorum of ${UOS_QUORUM} out of ${UOS_COUNT} for UoS ${SERVICE^^}"
    while true; do
        BACKEND_VERSIONED_COUNT=$(dig +short -t A ${BACKEND_VERSIONED} | wc -w)
        if [ "$BACKEND_VERSIONED_COUNT" -ge "$UOS_QUORUM" ]; then
            echo "UoS quorum met, moving on."
            break
        else
            echo "UoS IP addresses detected for ${BACKEND_VERSIONED}: $(dig +short -t A ${BACKEND_VERSIONED})"
            sleep 30
        fi
    done
}

wait_for_uos_quorum 'bemsdocs' "${BACKEND_BEMSDOCS_VERSIONED}."
