#!/usr/bin/env bash

if [ "${EPF::pg_prepare_db}" == "true" ]; then
    [[ -e postgresql.tf ]] || ln -s postgresql.tf.optional postgresql.tf
fi
