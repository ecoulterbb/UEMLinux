variable "azure_atm_enabled" {}
variable "azure_bemsdocsuos_resource_group" {}
variable "azure_bemsdocswafl_public_bems_configs" {}
variable "azure_bemsdocswafl_publicip_resource_group" {}
variable "azure_bemsdocswafl_resource_group" {}
variable "azure_bemsdocswafl_subnet_id" {}
variable "azure_client_id" {}
variable "azure_client_secret" {}
variable "azure_disable_internal_dns_record" {}
variable "azure_dns_resource_group" {}
variable "azure_dns_ttl" {}
variable "azure_dns_zone" {}
variable "azure_enable_internal_dns_record_internal_zone" {}
variable "azure_environment" {}
variable "azure_location" {}
variable "azure_subscription_id" {}
variable "azure_tags" { type = "map" }
variable "azure_tenant_id" {}

variable "bemsdocsuos_config_port" {}
variable "bemsdocsuos_healthcheck_port" {}
variable "bemsdocsuos_service_pool_port" {}

variable "dns_internal_zone" {}
variable "dns_tsig_fwd" {}
variable "dns_tsig_ptr" {}
variable "dns_update_server" {}

variable "offline_deployment" {}

variable "partition_name" {}

variable "pg_admin_username" {}
variable "pg_admin_password" {}
variable "pg_collation" {}
variable "pg_dbrole_name" {}
variable "pg_dbrole_password" {}
variable "pg_host" {}
variable "pg_prepare_db" {}
variable "pg_sslmode" {}

resource "azurerm_lb" "internal" {
    name = "${var.partition_name}-internal"
    location = "${var.azure_location}"
    resource_group_name = "${var.azure_bemsdocswafl_resource_group}"
    sku = "Standard"

    frontend_ip_configuration {
        name = "${var.partition_name}-internal-ipcf"
        subnet_id = "${var.azure_bemsdocswafl_subnet_id}"
    }

    tags = "${merge(
                var.azure_tags,
                map("bemsdocscloud.owner_hostname", trimspace(file("/etc/hostname")))
            )}"
}

output "lb_internal_ip" {
    value = "${azurerm_lb.internal.private_ip_address}"
}

resource "azurerm_lb_backend_address_pool" "internal_wafl" {
    name = "${var.partition_name}-internal-wafl"
    resource_group_name = "${var.azure_bemsdocswafl_resource_group}"
    loadbalancer_id = "${azurerm_lb.internal.id}"
}

output "lb_internal_wafl_bap_id" {
    value = "${azurerm_lb_backend_address_pool.internal_wafl.id}"
}

resource "azurerm_lb_probe" "wafl_to_healthy_bemsdocs" {
    name = "bemsdocswafl_probe_hc"
    resource_group_name = "${var.azure_bemsdocswafl_resource_group}"
    loadbalancer_id = "${azurerm_lb.internal.id}"

    interval_in_seconds = "5"
    port = "1${var.bemsdocsuos_healthcheck_port}"
    protocol = "http"
    request_path = "/health/wafl_bemsdocs.html"
}

resource "azurerm_lb_rule" "wafl_to_healthy_bemsdocs" {
    name = "wafl_to_healthy_bemsdocs"
    resource_group_name = "${var.azure_bemsdocswafl_resource_group}"
    loadbalancer_id = "${azurerm_lb.internal.id}"
    frontend_ip_configuration_name = "${azurerm_lb.internal.name}-ipcf"
    backend_address_pool_id = "${azurerm_lb_backend_address_pool.internal_wafl.id}"

    frontend_port = "1${var.bemsdocsuos_healthcheck_port}"
    backend_port = "1${var.bemsdocsuos_healthcheck_port}"
    probe_id = "${azurerm_lb_probe.wafl_to_healthy_bemsdocs.id}"
    protocol = "tcp"
}

resource "azurerm_lb_probe" "internal_bemsdocs" {
    name = "bemsdocs"
    resource_group_name = "${var.azure_bemsdocswafl_resource_group}"
    loadbalancer_id = "${azurerm_lb.internal.id}"

    interval_in_seconds = "5"
    port = "1${var.bemsdocsuos_healthcheck_port}"
    protocol = "http"
    request_path = "/health/service_bemsdocs.html"
}

resource "azurerm_lb_rule" "internal_bemsdocs_config" {
    name = "bemsdocs_config"
    resource_group_name = "${var.azure_bemsdocswafl_resource_group}"
    loadbalancer_id = "${azurerm_lb.internal.id}"
    frontend_ip_configuration_name = "${azurerm_lb.internal.name}-ipcf"
    backend_address_pool_id = "${azurerm_lb_backend_address_pool.internal_wafl.id}"

    frontend_port = "${var.bemsdocsuos_config_port}"
    backend_port = "${var.bemsdocsuos_config_port}"
    probe_id = "${azurerm_lb_probe.internal_bemsdocs.id}"
    protocol = "tcp"
}

resource "azurerm_public_ip" "partition" {
    name = "${var.partition_name}-public"
    location = "${var.azure_location}"
    resource_group_name = "${var.azure_bemsdocswafl_publicip_resource_group}"
    allocation_method = "Static"
    sku = "Standard"
    domain_name_label = "${var.partition_name}-docs-public"

    tags = "${merge(
                var.azure_tags,
                map("bemsdocscloud.owner_hostname", trimspace(file("/etc/hostname")))
            )}"
}

resource "azurerm_lb" "public" {
    name = "${var.partition_name}-public"
    location = "${var.azure_location}"
    resource_group_name = "${var.azure_bemsdocswafl_resource_group}"
    sku = "Standard"

    frontend_ip_configuration {
        name = "${var.partition_name}-public-ipcf"
        public_ip_address_id = "${azurerm_public_ip.partition.id}"
    }

    tags = "${merge(
                var.azure_tags,
                map("bemsdocscloud.owner_hostname", trimspace(file("/etc/hostname")))
            )}"
}

resource "azurerm_lb_backend_address_pool" "public_wafl" {
    name = "${var.partition_name}-public-wafl"
    resource_group_name = "${var.azure_bemsdocswafl_resource_group}"
    loadbalancer_id = "${azurerm_lb.public.id}"
}

output "lb_public_wafl_bap_id" {
    value = "${azurerm_lb_backend_address_pool.public_wafl.id}"
}

resource "azurerm_lb_probe" "public_bemsdocs" {
    name = "bemsdocs"
    resource_group_name = "${var.azure_bemsdocswafl_resource_group}"
    loadbalancer_id = "${azurerm_lb.public.id}"

    interval_in_seconds = "5"
    port = "1${var.bemsdocsuos_healthcheck_port}"
    protocol = "http"
    request_path = "/health/service_bemsdocs.html"
}

resource "azurerm_lb_rule" "public_bemsdocs_service" {
    name = "bemsdocs_service"
    resource_group_name = "${var.azure_bemsdocswafl_resource_group}"
    loadbalancer_id = "${azurerm_lb.public.id}"
    frontend_ip_configuration_name = "${azurerm_lb.public.name}-ipcf"
    backend_address_pool_id = "${azurerm_lb_backend_address_pool.public_wafl.id}"

    frontend_port = "${var.bemsdocsuos_service_pool_port}"
    backend_port = "${var.bemsdocsuos_service_pool_port}"
    probe_id = "${azurerm_lb_probe.public_bemsdocs.id}"
    protocol = "tcp"
    load_distribution = "SourceIP"
}

resource "azurerm_lb_probe" "public_bemsdocs_config" {
    # fedramp or togglable
    count = "${lower(var.azure_environment) == "usgovernment" || lower(var.azure_bemsdocswafl_public_bems_configs) == "true" ? 1 : 0}"
    name = "bemsdocs_config"
    resource_group_name = "${var.azure_bemsdocswafl_resource_group}"
    loadbalancer_id = "${azurerm_lb.public.id}"

    interval_in_seconds = "5"
    port = "1${var.bemsdocsuos_healthcheck_port}"
    protocol = "http"
    request_path = "/health/service_bemsdocs.html"
}

resource "azurerm_lb_rule" "public_bems_config" {
    # fedramp or togglable
    count = "${lower(var.azure_environment) == "usgovernment" || lower(var.azure_bemsdocswafl_public_bems_configs) == "true" ? 1 : 0}"
    name = "bemsdocs_config"
    resource_group_name = "${var.azure_bemsdocswafl_resource_group}"
    loadbalancer_id = "${azurerm_lb.public.id}"
    frontend_ip_configuration_name = "${azurerm_lb.public.name}-ipcf"
    backend_address_pool_id = "${azurerm_lb_backend_address_pool.public_wafl.id}"

    frontend_port = "${var.bemsdocsuos_config_port}"
    backend_port = "${var.bemsdocsuos_config_port}"
    probe_id = "${azurerm_lb_probe.public_bemsdocs_config.id}"
    protocol = "tcp"
}

resource "azurerm_dns_a_record" "pool_internal" {
    count = "${lower(var.azure_environment) == "usgovernment" || lower(var.azure_disable_internal_dns_record) == "true" || var.offline_deployment ? 0 : 1}"
    name = "${var.partition_name}-internal"
    zone_name = "${var.azure_dns_zone}"
    resource_group_name = "${var.azure_dns_resource_group}"
    records = ["${azurerm_lb.internal.private_ip_address}"]
    ttl = "${var.azure_dns_ttl}"

    tags = "${merge(
                var.azure_tags,
                map("bemsdocscloud.owner_hostname", trimspace(file("/etc/hostname")))
            )}"
}

resource "azurerm_dns_a_record" "bemsdocswafl_pool_public" {
    count = "${lower(var.azure_environment) == "usgovernment" || lower(var.azure_atm_enabled) == "true" || var.offline_deployment ? 0 : 1}"
    name = "${var.partition_name}"
    zone_name = "${var.azure_dns_zone}"
    resource_group_name = "${var.azure_dns_resource_group}"
    records = ["${azurerm_public_ip.partition.ip_address}"]
    ttl = "${var.azure_dns_ttl}"

    tags = "${merge(
                var.azure_tags,
                map("bemsdocscloud.owner_hostname", trimspace(file("/etc/hostname")))
            )}"
}

resource "dns_a_record_set" "pool_internal_usgov" {
     # fedramp only
     count = "${lower(var.azure_environment) == "usgovernment" ? 1 : 0}"
     zone = "${var.dns_internal_zone}."
     # use replace to allow names not directly under the dns_internal_zone, and ensure it doesn't end with a dot
     # e.g. if machine_domain is bemscloud.sw.rim.net and dns_internal_zone is sw.rim.net
     name = "${var.partition_name}-internal"
     addresses = ["${azurerm_lb.internal.private_ip_address}"]
     ttl = 61
}

resource "dns_a_record_set" "pool_internal_idns" {
     # for partitions using non-Azure DNS zones
     count = "${lower(var.azure_enable_internal_dns_record_internal_zone) == "true" && ! var.offline_deployment ? 1 : 0}"
     zone = "${var.dns_internal_zone}."
     # use replace to allow names not directly under the dns_internal_zone, and ensure it doesn't end with a dot
     # e.g. if machine_domain is bemscloud.sw.rim.net and dns_internal_zone is sw.rim.net
     name = "${var.partition_name}-internal"
     addresses = ["${azurerm_lb.internal.private_ip_address}"]
     ttl = 61
}
