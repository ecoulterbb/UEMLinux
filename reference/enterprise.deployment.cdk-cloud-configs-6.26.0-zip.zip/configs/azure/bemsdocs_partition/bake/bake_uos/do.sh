#!/usr/bin/env bash
set -o errexit

source functions_cdktools.sh

trap 'bash az_logout.sh' INT TERM EXIT
bash az_login.sh

while true; do
    if bash az_bakedimage_tagged.sh; then
        echo "Using pre-baked image."
        exit 0
    fi

    if bash az_bakedimage_lock_acquire.sh; then
        # cleanup failed/interrupted baking attempt and always release lock.
        # Disable the EXIT trap as we're already removing the lock
        trap 'echo "Baking attempt failed, removing lock and bake VM ..."; trap - EXIT; bash az_bakedimage_lock_release.sh; bash undo.sh' INT TERM ERR
        # make sure to release the lock when terminated
        trap 'bash az_bakedimage_lock_release.sh' EXIT
        break
    fi
    echo "Couldn't acquire baking lock -- another process is baking the image.  Checking again in 30 seconds..."

    sleep 30
done

if bash az_baking_enabled.sh; then
    echo "Baked image does not exist, baking image..."
    terraform init -input=false -plugin-dir=/opt/uemcloud/deploy/cdktools/terraform-plugins -upgrade
    terraform_retry apply -input=false -auto-approve=true

    bash prepare_bemsdocs.sh
    LC_BAKERIP=`terraform output baker_ip`
    LC_MYIP=`ip -4 -o addr show | grep -v ' lo ' | awk '{print $4}' | cut -d/ -f 1`

    echo "Sleeping 60 seconds to complete configuration."
    sleep 60

    # wait until WinRM port available
    COUNT=0
    until nc -zv -w 5 $LC_BAKERIP 5985
    do
        if [[ $((COUNT++)) -ge 5 ]]; then
            echo "Failed after 5 attempts."
            exit 1
        fi
        echo "Retrying in 60 seconds (attempt ${COUNT} of 5)..."
        sleep 60
    done

    # reboot system, as workaround to not being able to to WinRM commands
    echo "Rebooting VM."
    bash az_reboot_vm.sh

    # wait until WinRM port available
    COUNT=0
    until nc -zv -w 5 $LC_BAKERIP 5985
    do
        if [[ $((COUNT++)) -ge 5 ]]; then
            echo "Failed after 5 attempts."
            exit 1
        fi
        echo "Retrying in 60 seconds (attempt ${COUNT} of 5)..."
        sleep 60
    done

    # wait 60 seconds
    echo "Sleeping 60 seconds for Windows to be ready for WinRM."
    sleep 60

    # run Ansible to install software
    ansible_retry -e baker_host_ip=$LC_BAKERIP -e sad_ip=$LC_MYIP -e @ansible_vars.yml -i inventory.yml /opt/uemcloud/cloud-deploy-configs/common/ansible/bemsdocs_uos_bake.yml

    # remote the extension from terraform state manually while VM is powering off
    terraform_retry state rm azurerm_virtual_machine_extension.baker_extension

    # wait until VM is powered off
    bash az_wait_for_shutdown.sh

    # destroy the VM
    terraform_retry destroy -force

    # copy the disk into the blob
    bash az_bakedimage_addtag.sh
else
    echo "ERROR: Baked image does not exist and baking is not enabled."
    exit 1
fi
