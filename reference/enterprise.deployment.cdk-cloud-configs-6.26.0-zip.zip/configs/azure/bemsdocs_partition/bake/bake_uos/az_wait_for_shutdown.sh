#!/usr/bin/env bash
set -o errexit
source az_env.sh

echo "Waiting for VM ${AZURE_BAKEDIMAGE_NAME} to be shutdown"
az vm wait --name $AZURE_BAKEDIMAGE_NAME --resource-group $AZURE_BAKEDIMAGE_RESOURCE_GROUP --custom "instanceView.statuses[?code=='PowerState/stopped']"
