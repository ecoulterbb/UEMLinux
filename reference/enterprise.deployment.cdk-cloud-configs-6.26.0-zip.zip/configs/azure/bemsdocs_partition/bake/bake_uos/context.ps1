Move-Item C:\Windows\System32\GroupPolicy\Machine\registry.pol C:\Temp
gpupdate /force

winrm quickconfig -q
Set-Item -Path WSMan:\localhost\Service\Auth\Basic -Value $true
Set-Item -Path WSMan:\localhost\Service\AllowUnencrypted -Value $true

reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server" /v fDenyTSConnections /t REG_DWORD /d 0 /f
netsh advfirewall firewall set rule name="Windows Remote Management (HTTP-In)" profile=public new remoteip=10.212.32.0/24
netsh advfirewall firewall set rule name="Windows Remote Management (HTTP-In)" profile=public new remoteip=10.212.64.0/24

$Cred=ConvertTo-SecureString -String "${EPF::uos_admin_password}" -AsPlainText -Force
New-LocalUser -Name "${EPF::uos_admin_username}" -Description "Local Admin Account" -Password $Cred -PasswordNeverExpires
Add-LocalGroupMember -Group "Administrators" -Member "${EPF::uos_admin_username}"
Add-LocalGroupMember -Group "Remote Management Users" -Member "${EPF::uos_admin_username}"

Restart-Service winrm
