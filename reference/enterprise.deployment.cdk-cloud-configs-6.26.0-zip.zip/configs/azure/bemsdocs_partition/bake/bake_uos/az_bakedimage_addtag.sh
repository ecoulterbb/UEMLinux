#!/usr/bin/env bash
set -o errexit
source az_env.sh

TAGS=("cdktools_baked_successfully=true" "cdktools_baker_hostname=$(hostname)" "cdktools_base_image=${AZURE_MANAGED_IMAGE_NAME}" "cdktools_image_last_used=$(date '+%Y-%m-%d@%H:%M:%S%z')")
GOLD_TAGS=( $(az_retry 60  image show --name ${AZURE_MANAGED_IMAGE_NAME} --resource-group ${AZURE_MANAGED_IMAGE_RG} --query 'tags' --output yaml | grep -v expirydate | sed -e 's/: /=/') )

echo "TAGS set to:"
printf '        %s\n' "${TAGS[@]}"

echo "GOLD_TAGS set to:"
printf '        %s\n' "${GOLD_TAGS[@]}"

# get sas token to access image
sas=$(az_retry 60 disk grant-access --resource-group $AZURE_BAKEDIMAGE_RESOURCE_GROUP --name $AZURE_BAKEDIMAGE_NAME --duration-in-seconds $AZURE_BAKEDIMAGE_SAS_TOKEN_TIMEOUT -o json | jq -r '.accessSas, .accessSAS | select( . != null )')

# wait a few seconds before using the sas token because Azure
sleep 5

# copy managed disk image into blob storage
az_retry 60 storage blob copy start --destination-blob $AZURE_BAKEDIMAGE_NAME.vhd --destination-container $AZURE_BAKEDIMAGE_STORAGE_CONTAINER --account-name $AZURE_BAKEDIMAGE_STORAGE_ACCOUNT --account-key $AZURE_BAKEDIMAGE_STORAGE_ACCOUNT_KEY --source-uri $sas

# the copy process takes time, set an arbritrary sleep period. 
echo "Waiting up to $AZURE_BAKEDIMAGE_SAS_TOKEN_TIMEOUT seconds for the image copy process to complete in the background...."

copy_progress="running"
while [ $copy_progress=="running" ]; do
  copy_status=$(az_retry 60 storage blob show --name $AZURE_BAKEDIMAGE_NAME.vhd --container-name  $AZURE_BAKEDIMAGE_STORAGE_CONTAINER --account-name $AZURE_BAKEDIMAGE_STORAGE_ACCOUNT --query "[properties.copy.status]" --output tsv)
  case $copy_status in
   'pending')
     echo "Copy in progress..."
   ;;
   'failed')
     echo "Copy process failed or SAS token expired"
     az_retry 60 storage blob show --name $AZURE_BAKEDIMAGE_NAME.vhd --container-name  $AZURE_BAKEDIMAGE_STORAGE_CONTAINER --account-name $AZURE_BAKEDIMAGE_STORAGE_ACCOUNT |grep status
     copy_progress="failed"
     break
   ;;
   'success')
     echo "Copy completed."
     echo "Removing read access (sas token) from managed disk image"
     az_retry 60  disk revoke-access --resource-group $AZURE_BAKEDIMAGE_RESOURCE_GROUP --name $AZURE_BAKEDIMAGE_NAME --query [accessSas] -o tsv
     echo "Deleting the managed disk image"
     az_retry 60  disk delete --resource-group $AZURE_BAKEDIMAGE_RESOURCE_GROUP --name $AZURE_BAKEDIMAGE_NAME --yes
     copy_progress="complete"
     break
   ;;
  esac
  sleep 15
done

echo "Adding valid tag to blob ${AZURE_BAKEDIMAGE_NAME}.vhd..."
EXPIRY_DATE_STRING=$(date -d "$AZURE_IMAGE_EXPIRATION_LENGTH" '+%Y/%m/%d')
az_retry 60 storage blob metadata update --name $AZURE_BAKEDIMAGE_NAME.vhd --container-name $AZURE_BAKEDIMAGE_STORAGE_CONTAINER --account-name $AZURE_BAKEDIMAGE_STORAGE_ACCOUNT --metadata "${TAGS[@]}" "${GOLD_TAGS[@]}" "cdktools_image_last_used=$(date '+%Y-%m-%d@%H:%M:%S%z')" "expirydate=${EXPIRY_DATE_STRING}"

# for some reason, "az storage blob url" puts quotes around the URL, so remove them with tr
BLOB_URL=$(az_retry 60 storage blob url --name $AZURE_BAKEDIMAGE_NAME.vhd --container-name $AZURE_BAKEDIMAGE_STORAGE_CONTAINER --account-name $AZURE_BAKEDIMAGE_STORAGE_ACCOUNT  | tr -d '"')
echo "Creating managed image for ${AZURE_BAKEDIMAGE_NAME} from ${BLOB_URL} ..."
az_retry 120 image create --name $AZURE_BAKEDIMAGE_NAME --resource-group $AZURE_BAKEDIMAGE_RESOURCE_GROUP --source $BLOB_URL --os-type Windows --tags "${TAGS[@]}" "${GOLD_TAGS[@]}"
