#!/usr/bin/env bash
set -o errexit
source az_env.sh

az vm restart --name $AZURE_BAKEDIMAGE_NAME --resource-group $AZURE_BAKEDIMAGE_RESOURCE_GROUP
