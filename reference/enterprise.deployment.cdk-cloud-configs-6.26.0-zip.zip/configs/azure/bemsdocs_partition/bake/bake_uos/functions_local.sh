#!/usr/bin/env bash

terraform_retry_cleanup() {
    TF_STATE=${TF_STATE:-terraform.tfstate}

    # if VM doesn't exist in state, try importing so any previous failed copy will be cleaned up on retry
    if ! terraform state list -state=$TF_STATE | grep -F azurerm_virtual_machine.baker; then
        terraform import -state=$TF_STATE azurerm_virtual_machine.baker "/subscriptions/${EPF::azure_subscription_id}/resourceGroups/${EPF::azure_bakedimage_resource_group}/providers/Microsoft.Compute/virtualMachines/${EPF::azure_bakedimage_prefix}-${EPF::product_name}cloud-uos-baked-${EPF::bundle_version}d${EPF::deployment_version}" || true
    fi

    # if there was a transient error, we should start from scratch
    echo "Destroying failed infrastructure..."
    terraform destroy -force -state=$TF_STATE
    echo "Cleaning up baking disk ${EPF::azure_bakedimage_prefix}-${EPF::product_name}cloud-uos-baked-${EPF::bundle_version}d${EPF::deployment_version}..."
    az_retry 60 disk delete --name ${EPF::azure_bakedimage_prefix}-${EPF::product_name}cloud-uos-baked-${EPF::bundle_version}d${EPF::deployment_version} --resource-group ${EPF::azure_bakedimage_resource_group} --yes || true
    echo "Sleeping 15s..."
    sleep 15
}

export TF_VAR_uos_machinename_suffix=`echo -n '${EPF::bundle_version}d${EPF::deployment_version}' | openssl dgst -binary -sha256 | base32 | cut -c1-3`

ansible_retry() {
    COUNT=0
    until ansible-playbook "$@"; do
        if [[ $((COUNT++)) -ge 5 ]]; then
            echo "Failed after 5 attempts."
            exit 1
        fi
        echo "Retrying in 10 seconds (attempt ${COUNT} of 5)..."
        sleep 10
    done
}
