variable "apt_server" {}

variable "azure_client_id" {}
variable "azure_client_secret" {}

variable "azure_bakedimage_resource_group" {}
variable "azure_bakedimage_storage_account" {}
variable "azure_bakedimage_storage_container" {}

variable "azure_baking_bootdiag_enabled" {}
variable "azure_baking_nsg_id" {}
variable "azure_baking_subnet_id" {}
variable "azure_baking_vm_size" {}
variable "azure_baking_vnet_id" {}

variable "azure_bemsuos_osdisk_size" {}

variable "azure_environment" {}

variable "azure_managed_disk_type" {}
variable "azure_managed_image_name" {}
variable "azure_managed_image_rg" {}

variable "azure_location" {}
variable "azure_subscription_id" {}
variable "azure_tags" { type = "map" }
variable "azure_tenant_id" {}

variable "baked_image_name" {}

variable "product_name" {}

variable "uos_machinename_prefix" {}
variable "uos_machinename_suffix" {}
variable "uos_admin_username" {}
variable "uos_admin_password" {}
variable "uos_time_zone" {}

data "azurerm_image" "image" {
    name = "${var.azure_managed_image_name}"
    resource_group_name = "${var.azure_managed_image_rg}"
}

data "azurerm_storage_account" "bakedimage" {
    name = "${var.azure_bakedimage_storage_account}"
    resource_group_name = "${var.azure_bakedimage_resource_group}"
}

resource "azurerm_network_interface" "baker" {
    name = "${var.baked_image_name}-ni"
    location = "${var.azure_location}"
    resource_group_name = "${var.azure_bakedimage_resource_group}"
    network_security_group_id = "${var.azure_baking_nsg_id}"

    ip_configuration {
        name = "${var.baked_image_name}-ipcf"
        subnet_id = "${var.azure_baking_subnet_id}"
        private_ip_address_allocation = "dynamic"
    }

    tags = "${merge(
                var.azure_tags,
                map("${var.product_name}cloud.owner_hostname", trimspace(file("/etc/hostname")))
            )}"
}

resource "azurerm_virtual_machine" "baker" {
    name = "${var.baked_image_name}"
    # keep OS disk as baked image
    delete_os_disk_on_termination = "false"
    location = "${var.azure_location}"
    resource_group_name = "${var.azure_bakedimage_resource_group}"
    network_interface_ids = ["${azurerm_network_interface.baker.id}"]
    vm_size = "${var.azure_baking_vm_size}"
    license_type = "Windows_Server"

    tags = "${merge(
                var.azure_tags,
                map("${var.product_name}cloud.owner_hostname", trimspace(file("/etc/hostname")))
            )}"

    boot_diagnostics {
        enabled = "${var.azure_baking_bootdiag_enabled}"
        storage_uri = "${data.azurerm_storage_account.bakedimage.primary_blob_endpoint}"
    }

    storage_image_reference {
        id="${data.azurerm_image.image.id}"
    }

    storage_os_disk {
        name = "${var.baked_image_name}"
        caching = "ReadWrite"
        create_option = "FromImage"
        disk_size_gb = "${var.azure_bemsuos_osdisk_size}"
        managed_disk_type = "${var.azure_managed_disk_type}"
        os_type = "Windows"
    }

    os_profile {
        computer_name = "${var.uos_machinename_prefix}${var.uos_machinename_suffix}"
        custom_data = "${file("./context.ps1")}"
        admin_username = "LocalAdminAccount"
        admin_password = "DisabledByGTS1!!"
    }

    os_profile_windows_config {
        provision_vm_agent = true
    }
}

resource "azurerm_virtual_machine_extension" "baker_extension" {
    name = "context"
    location = "${var.azure_location}"
    resource_group_name = "${var.azure_bakedimage_resource_group}"
    virtual_machine_name = "${azurerm_virtual_machine.baker.name}"
    publisher = "Microsoft.Compute"
    type = "CustomScriptExtension"
    type_handler_version = "1.9"

    settings = <<SETTINGS
    {
        "commandToExecute": "powershell.exe -command \"New-Item -Path C:\\ -Name temp -ItemType directory -Force; Copy-Item C:\\AzureData\\CustomData.bin C:\\temp\\context.ps1\" ; powershell.exe -ExecutionPolicy Unrestricted -sta -File \"C:\\temp\\context.ps1\""
    }
    SETTINGS
}

output "baker_ip" {
    value = "${azurerm_network_interface.baker.private_ip_address}"
}
