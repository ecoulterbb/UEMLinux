#!/usr/bin/env bash
set -o errexit

pushd bake_wafl
echo "Processing WAFL image..."
bash ./undo.sh
popd
