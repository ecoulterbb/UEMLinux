variable "apt_server" {}

variable "azure_client_id" {}
variable "azure_client_secret" {}

variable "azure_bakedimage_resource_group" {}
variable "azure_bakedimage_storage_account" {}
variable "azure_bakedimage_storage_container" {}

variable "azure_baking_bootdiag_enabled" {}
variable "azure_baking_subnet_id" {}
variable "azure_baking_vm_size" {}
variable "azure_baking_vnet_id" {}

variable "azure_bemswafl_osdisk_size" {}

variable "azure_environment" {}

variable "azure_gold_vhd_container" {}
variable "azure_gold_vhd_name" {}

variable "azure_managed_disk_type" {}
variable "azure_managed_image_name" {}
variable "azure_managed_image_rg" {}

variable "azure_location" {}
variable "azure_subscription_id" {}
variable "azure_tags" { type = "map" }
variable "azure_tenant_id" {}

variable "baked_image_name" {}

variable "product_name" {}

data "azurerm_image" "image" {
    name = "${var.azure_managed_image_name}"
    resource_group_name = "${var.azure_managed_image_rg}"
}

data "azurerm_storage_account" "bakedimage" {
    name = "${var.azure_bakedimage_storage_account}"
    resource_group_name = "${var.azure_bakedimage_resource_group}"
}

resource "azurerm_network_interface" "baker" {
    name = "${var.baked_image_name}-ni"
    location = "${var.azure_location}"
    resource_group_name = "${var.azure_bakedimage_resource_group}"

    ip_configuration {
        name = "${var.baked_image_name}-ipcf"
        subnet_id = "${var.azure_baking_subnet_id}"
        private_ip_address_allocation = "dynamic"
    }

    tags = "${merge(
                var.azure_tags,
                map("${var.product_name}cloud.owner_hostname", trimspace(file("/etc/hostname")))
            )}"
}

resource "azurerm_virtual_machine" "baker" {
    name = "${var.baked_image_name}"
    # keep OS disk as baked image
    delete_os_disk_on_termination = "false"
    location = "${var.azure_location}"
    resource_group_name = "${var.azure_bakedimage_resource_group}"
    network_interface_ids = ["${azurerm_network_interface.baker.id}"]
    vm_size = "${var.azure_baking_vm_size}"

    tags = "${merge(
                var.azure_tags,
                map("${var.product_name}cloud.owner_hostname", trimspace(file("/etc/hostname")))
            )}"

    boot_diagnostics {
        enabled = "${var.azure_baking_bootdiag_enabled}"
        storage_uri = "${data.azurerm_storage_account.bakedimage.primary_blob_endpoint}"
    }

    storage_image_reference {
        id="${data.azurerm_image.image.id}"
    }

    storage_os_disk {
        name = "${var.baked_image_name}"
        caching = "ReadWrite"
        create_option = "FromImage"
        disk_size_gb = "${var.azure_bemswafl_osdisk_size}"
        managed_disk_type = "${var.azure_managed_disk_type}"
        os_type = "linux"
    }

    os_profile {
        computer_name = "${var.baked_image_name}"
        # even though GTS blocks this, same username is created for baking so that generalize command will clean it up
        # set a long password in case this actually gets used
        admin_username = "cdktools-baker"
        admin_password = "V5nMWScV5ywuEhQNOg9aHx1TEDsdFfrOsEJeeN1I"
        custom_data = "${base64encode(data.template_file.baker_cloudinit_userdata.rendered)}"
    }

    os_profile_linux_config {
        disable_password_authentication = false
    }
}

data "template_file" "baker_cloudinit_userdata" {
    template = "${file("${path.module}/cloudinit_userdata_bake.tpl")}"

    vars = {
        apt_server = "${var.apt_server}"
        ssh_authorized_key = "${file("/opt/uemcloud/.ssh/id_rsa.pub")}"
    }
}

output "baker_ip" {
    value = "${azurerm_network_interface.baker.private_ip_address}"
}
