variable "azure_bakedimage_name_uos" {}
variable "azure_bakedimage_name_wafl" {}
variable "azure_bakedimage_resource_group" {}
variable "azure_client_id" {}
variable "azure_client_secret" {}
variable "azure_environment" {}
variable "azure_subscription_id" {}
variable "azure_tenant_id" {}

#### WAFL ####

data "azurerm_image" "baked_wafl" {
    name = "${var.azure_bakedimage_name_wafl}"
    resource_group_name = "${var.azure_bakedimage_resource_group}"
}

output "baked_wafl_id" {
    value = "${data.azurerm_image.baked_wafl.id}"
}

#### UOS ####

data "azurerm_image" "baked_uos" {
    name = "${var.azure_bakedimage_name_uos}"
    resource_group_name = "${var.azure_bakedimage_resource_group}"
}

output "baked_uos_id" {
    value = "${data.azurerm_image.baked_uos.id}"
}

