#!/usr/bin/env bash
set -o errexit

source functions_cdktools.sh

# clear DNS node records while instances still exist in the scale sets
clear_backend_node_dns_records

TF_STATE="terraform.tfstate"

if [ -f "$TF_STATE" ]; then
    export TF_VAR_azure_asset_keyvault_client_secret_encrypted=""
    terraform init -input=false -plugin-dir=/opt/uemcloud/deploy/cdktools/terraform-plugins -upgrade
    terraform_retry destroy -force -state=$TF_STATE
else
    echo "Skipping as state file $TF_STATE was not found."
fi

# ensure that DNS pools are cleared for this version
clear_backend_bems_dns_pool
