variable "apt_server" {}

variable "azure_asset_keyvault_client_secret_encrypted" {}

variable "azure_bemsuos_availability_zones" { type = "list" }
variable "azure_bemsuos_bootdiag_enabled" {}
variable "azure_bemsuos_bootdiag_storage_account_uri" {}
variable "azure_bemsuos_resource_group" {}
variable "azure_bemsuos_subnet_id" {}
variable "azure_bemsuos_vm_size" {}
variable "azure_bemsuos_vmss_capacity" {}
variable "azure_bemsuos_vmss_nsg_id" {}

variable "azure_bemswafl_availability_zones" { type = "list" }
variable "azure_bemswafl_bootdiag_enabled" {}
variable "azure_bemswafl_bootdiag_storage_account_uri" {}
variable "azure_bemswafl_resource_group" {}
variable "azure_bemswafl_subnet_id" {}
variable "azure_bemswafl_vm_size" {}
variable "azure_bemswafl_vmss_capacity" {}
variable "azure_bemswafl_vmss_nsg_id" {}

variable "azure_client_id" {}
variable "azure_client_secret" {}
variable "azure_deploy_keyvault_encryption_cert_thumbprint" {}
variable "azure_deploy_keyvault_encryption_cert_url" {}
variable "azure_deploy_keyvault_wafl_cert_chain_pem" {}
variable "azure_deploy_keyvault_wafl_cert_thumbprint" {}
variable "azure_deploy_keyvault_wafl_cert_url" {}
variable "azure_deploy_keyvault_id" {}
variable "azure_environment" {}
variable "azure_location" {}
variable "azure_managed_disk_type" {}
variable "azure_subscription_id" {}
variable "azure_tags" { type = "map" }
variable "azure_tenant_id" {}

variable "bemsuos_config_port" {}
variable "bemsuos_healthcheck_port" {}
variable "bemsuos_service_pool_port" {}

variable "egress_lb" {}
variable "env_type" {}

variable "fluent_bit_enabled" {}
variable "fluent_bit_cert_path" {}
variable "fluent_bit_key_path" {}
variable "fluent_bit_custom_include" {}
variable "fluent_bit_custom_include_path" {}
variable "fluent_bit_syslog_to_kafka" {}

variable "hold_packages" {}

variable "nexpose_alt_account" {}

variable "kafka_dr" {}

variable "partition_name" {}
variable "partition_version" {}

variable "rapid7_cfg_file" {}

variable "ssh_allowed_groups" { type = "list" }
variable "systemd_service" {}

variable "ua_token" {}

variable "uos_jmxcollector_bemscloud_defaults" {}
variable "uos_jmxcollector_bemscloud_properties" {}
variable "uos_jmx_exporter_bemscloud_defaults" {}
variable "uos_jmx_exporter_bemscloud_yaml" {}
variable "uos_password" {}

variable "wafl_naxsi_rules_config" {}
variable "wafl_naxsi_rules_service" {}

variable "whitelight_enabled" {}

variable "zabbix_psk" {}
variable "zabbix_psk_identity" {}

locals {
  uos_rsyslog_file = "${var.kafka_dr != "true" ? "90-bemscloud-uos.conf" : "90-bemscloud-uos-dr.conf" }"
  wafl_rsyslog_file = "${var.kafka_dr != "true" ? "90-bemscloud-wafl.conf" : "90-bemscloud-wafl-dr.conf" }"
}

#### COMMON ####

data "terraform_remote_state" "image_info" {
    backend = "local"

    config {
        path = "${path.module}/../bake/image_info/terraform.tfstate"
    }
}

data "terraform_remote_state" "bemspartition_prepare" {
    backend = "local"

    config {
        path = "${path.module}/../../../../azure-bems_partition-prepare-terraform.tfstate"
    }
}

data "template_file" "cloudinit_userdata_zabbix_psk" {
    template = "${var.zabbix_psk == "" ? "" : file("${path.module}/cloudinit_userdata_zabbix_psk.tpl")}"
    vars = {
        zabbix_psk = "${base64encode(var.zabbix_psk)}"
        zabbix_psk_identity = "${var.zabbix_psk_identity}"
        zabbix_psk_ar_script = "${base64encode(file("${path.module}/zabbix_psk_ar.sh"))}"
    }
}

data "template_file" "cloudinit_userdata_server_info" {
    template = "${file("${path.module}/cloudinit_userdata_bb-server-info.tpl")}"
    vars = {
        server_info = "${base64encode(file("${path.module}/bb-server-info.txt"))}"
    }
}

data "template_file" "cloudinit_userdata_hold_packages" {
    template = "${var.hold_packages == "" ? "" : file("${path.module}/cloudinit_userdata_hold_packages.tpl")}"
    vars = {
        hold_packages = "${var.hold_packages}"
    }
}

data "template_file" "cloudinit_userdata_ubuntu_advantage" {
    template = "${var.ua_token == "" ? "" : file("${path.module}/cloudinit_userdata_ubuntu_advantage.tpl")}"
    vars = {
        ua_token = "${var.ua_token}"
    }
}

data "template_file" "cloudinit_userdata_nexpose" {
    template = "${var.nexpose_alt_account == "" ? "" : file("${path.module}/cloudinit_userdata_nexpose.tpl")}"
    vars = {
        nexpose_alt_account = "${var.nexpose_alt_account}"
    }
}

data "template_file" "cloudinit_userdata_rapid7_cfg" {
    template = "${var.rapid7_cfg_file == "/dev/null" ? "" : file("${path.module}/cloudinit_userdata_rapid7_cfg.tpl")}"
    vars = {
        rapid7_cfg = "${var.rapid7_cfg_file == "/dev/null" ? "" : base64encode(file("${var.rapid7_cfg_file}"))}"
    }
}

#### WAFL ####

data "template_file" "bemswafl_cloudinit_userdata" {
    template = "${file("${path.module}/cloudinit_userdata_bemswafl_azure.tpl")}"

    vars {
        apt_server = "${var.apt_server}"
        cert_chain_pem = "${base64encode(file("${var.azure_deploy_keyvault_wafl_cert_chain_pem}"))}"
        cert_path_prefix = "/var/lib/waagent/${var.azure_deploy_keyvault_wafl_cert_thumbprint}"
        encoded_fluentbit_env = "${base64encode(file("${path.module}/fluent-bit.wafl.env"))}"
        encoded_fluentbit_yaml = "${base64encode(file("${path.module}/fluent-bit.wafl.yaml"))}"
        encoded_fluentbit_cert = "${base64encode(file("${var.fluent_bit_cert_path}"))}"
        encoded_fluentbit_key = "${base64encode(file("${var.fluent_bit_key_path}"))}"
        encoded_fluentbit_include = "${var.fluent_bit_custom_include == "true" ? base64encode(file("${var.fluent_bit_custom_include_path}")) : var.fluent_bit_syslog_to_kafka == "true" ? base64encode(file("${path.module}/fluent-bit-include.syslog.yaml")) : base64encode(file("${path.module}/fluent-bit-include.null.yaml"))}"
        encoded_rsyslog_conf = "${var.fluent_bit_enabled == "true" ? base64encode(file("${path.module}/90-bemscloud-wafl.fluent-bit.conf")) : base64encode(file("${path.module}/${local.wafl_rsyslog_file}")) }"
        encoded_userparameter_uos_ssl_check_conf = "${base64encode(file("${path.module}/userparameter_uos-ssl-check.conf"))}"
        encoded_wafl_clean_dns_sh = "${base64encode(file("${path.module}/wafl_clean_dns.sh"))}"
        encoded_wafl_health_sh = "${base64encode(file("${path.module}/wafl_health_bemscloud.sh"))}"
        encoded_wafl_init_worker = "${base64encode(file("${path.module}/wafl_init_worker_bemscloud.lua"))}"
        naxsi_bemscloud_config_rules = "${base64encode(file("${var.wafl_naxsi_rules_config}"))}"
        naxsi_bemscloud_service_rules = "${base64encode(file("${var.wafl_naxsi_rules_service}"))}"
        nginx_conf = "${base64encode(file("${path.module}/nginx.conf"))}"
        ssh_groups = "${base64encode(join("\n", var.ssh_allowed_groups))}"
        sudo_rules = "${base64encode(join("\n", formatlist("%%%s ALL=(ALL) ALL", var.ssh_allowed_groups)))}"
        whitelight_conf = "${base64encode(data.template_file.bemswafl_whitelight_conf.rendered)}"
    }
}

data "template_cloudinit_config" "bemswafl_cloudinit_userdata" {
    gzip = true
    base64_encode = true

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.bemswafl_cloudinit_userdata.rendered}"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_zabbix_psk.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_server_info.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_hold_packages.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_ubuntu_advantage.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_nexpose.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_rapid7_cfg.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${var.whitelight_enabled ? "" : file("${path.module}/cloudinit_userdata_whitelight_disable.tpl")}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }
}

data "template_file" "bemswafl_whitelight_conf" {
    template = "${file("${path.module}/whitelight-bemscloud.conf.tpl")}"

    vars {
        bemsuos_config_port = "${var.bemsuos_config_port}"
        bemsuos_service_pool_port = "${var.bemsuos_service_pool_port}"
        bemswafl_hc_bems_port = "1${var.bemsuos_healthcheck_port}"
    }
}

resource "azurerm_virtual_machine_scale_set" "bemswafl" {
    name = "${var.partition_name}-wafl-${var.partition_version}"
    location = "${var.azure_location}"
    overprovision = false
    resource_group_name = "${var.azure_bemswafl_resource_group}"
    upgrade_policy_mode = "Manual"
    zones = "${var.azure_bemswafl_availability_zones}"

    sku {
        name = "${var.azure_bemswafl_vm_size}"
        tier = "Standard"
        capacity = "${var.azure_bemswafl_vmss_capacity}"
    }

    os_profile {
        computer_name_prefix = "${var.partition_name}-wafl-${var.partition_version}-"
        custom_data = "${data.template_cloudinit_config.bemswafl_cloudinit_userdata.rendered}"
        admin_username = "disabledbygts"
        admin_password = "DisabledByGTS1!"
    }

    os_profile_linux_config {
        disable_password_authentication = false
    }

    os_profile_secrets {
        source_vault_id = "${var.azure_deploy_keyvault_id}"
        vault_certificates {
            certificate_url = "${var.azure_deploy_keyvault_wafl_cert_url}"
        }
    }

    network_profile {
        name = "${var.partition_name}-wafl-nic"
        network_security_group_id = "${var.azure_bemswafl_vmss_nsg_id}"
        primary = true

        ip_configuration {
            name = "${var.partition_name}-wafl-ipcf"
            primary = true
            subnet_id = "${var.azure_bemswafl_subnet_id}"
            load_balancer_backend_address_pool_ids = [
                "${data.terraform_remote_state.bemspartition_prepare.lb_internal_wafl_bap_id}",
                "${data.terraform_remote_state.bemspartition_prepare.lb_public_wafl_bap_id}"
            ]
        }
    }

    storage_profile_image_reference {
        id = "${data.terraform_remote_state.image_info.baked_wafl_id}"
    }

    storage_profile_os_disk {
        caching = "ReadWrite"
        create_option = "FromImage"
        managed_disk_type = "${var.azure_managed_disk_type}"
    }

    boot_diagnostics {
        enabled = "${var.azure_bemswafl_bootdiag_enabled}"
        storage_uri = "${var.azure_bemswafl_bootdiag_storage_account_uri}"
    }

    tags = "${merge(
                var.azure_tags,
                map("bb:component", "wafl"),
                map("bemscloud.owner_hostname", trimspace(file("/etc/hostname")))
            )}"

}

#### UOS ####

data "template_file" "bemsuos_cloudinit_userdata" {
    template = "${file("${path.module}/cloudinit_userdata_bemsuos_azure.tpl")}"

    vars {
        apt_server = "${var.apt_server}"
        cert_thumbprint = "${var.azure_deploy_keyvault_encryption_cert_thumbprint}"
        client_secret_encrypted = "${var.azure_asset_keyvault_client_secret_encrypted}"
        encoded_dns_pool_member_add = "${base64encode(file("${path.module}/dns_pool_member_add.sh"))}"
        encoded_fluentbit_env = "${base64encode(file("${path.module}/fluent-bit.uos.env"))}"
        encoded_fluentbit_yaml = "${base64encode(file("${path.module}/fluent-bit.uos.yaml"))}"
        encoded_fluentbit_cert = "${base64encode(file("${var.fluent_bit_cert_path}"))}"
        encoded_fluentbit_key = "${base64encode(file("${var.fluent_bit_key_path}"))}"
        encoded_fluentbit_include = "${var.fluent_bit_custom_include == "true" ? base64encode(file("${var.fluent_bit_custom_include_path}")) : var.fluent_bit_syslog_to_kafka == "true" ? base64encode(file("${path.module}/fluent-bit-include.syslog.yaml")) : base64encode(file("${path.module}/fluent-bit-include.null.yaml"))}"
        encoded_rsyslog_conf = "${var.fluent_bit_enabled == "true" ? base64encode(file("${path.module}/90-bemscloud-uos.fluent-bit.conf")) : base64encode(file("${path.module}/${local.uos_rsyslog_file}")) }"
        jmxcollector_bemscloud_defaults = "${base64encode(file("${var.uos_jmxcollector_bemscloud_defaults}"))}"
        jmxcollector_bemscloud_properties = "${base64encode(file("${var.uos_jmxcollector_bemscloud_properties}"))}"
        jmx_exporter_bemscloud_defaults = "${base64encode(file("${var.uos_jmx_exporter_bemscloud_defaults}"))}"
        jmx_exporter_bemscloud_yaml = "${base64encode(file("${var.uos_jmx_exporter_bemscloud_yaml}"))}"
        machine_properties = "${base64encode(file("/opt/uemcloud/deploy/${var.partition_name}/${var.partition_version}/machine.properties"))}"
        postgres_root_cert = "${base64encode(file("/opt/uemcloud/.postgresql/root.crt"))}"
        ssh_authorized_key = "${file("/opt/uemcloud/.ssh/id_rsa.pub")}"
        ssh_users = "${base64encode("uemcloud")}"
        ssh_groups = "${base64encode(join("\n", var.ssh_allowed_groups))}"
        systemd_service = "${var.systemd_service}"
        sudo_rules = "${base64encode("uemcloud ALL=(ALL) ALL\n${join("\n", formatlist("%%%s ALL=(ALL) ALL", var.ssh_allowed_groups))}")}"
        user_lock_passwd = "${var.env_type == "lab" ? false : true}"
        user_passwd = "${var.env_type == "lab" ? var.uos_password : ""}"
    }
}

data "template_cloudinit_config" "bemsuos_cloudinit_userdata" {
    gzip = true
    base64_encode = true

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.bemsuos_cloudinit_userdata.rendered}"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_zabbix_psk.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_server_info.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_hold_packages.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_ubuntu_advantage.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_nexpose.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${data.template_file.cloudinit_userdata_rapid7_cfg.rendered}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }

    part {
        content_type = "text/cloud-config"
        content = "${var.whitelight_enabled ? "" : file("${path.module}/cloudinit_userdata_whitelight_disable.tpl")}"
        merge_type = "list(prepend)+dict(recurse_array)+str()"
    }
}

resource "azurerm_virtual_machine_scale_set" "bemsuos" {
    count = "${lower(var.egress_lb) == "true" ? 0 : 1}"
    name = "${var.partition_name}-uos-${var.partition_version}"
    location = "${var.azure_location}"
    overprovision = false
    resource_group_name = "${var.azure_bemsuos_resource_group}"
    upgrade_policy_mode = "Manual"
    zones = "${var.azure_bemsuos_availability_zones}"

    sku {
        name = "${var.azure_bemsuos_vm_size}"
        tier = "Standard"
        capacity = "${var.azure_bemsuos_vmss_capacity}"
    }

    os_profile {
        computer_name_prefix = "${var.partition_name}-uos-${var.partition_version}-"
        custom_data = "${data.template_cloudinit_config.bemsuos_cloudinit_userdata.rendered}"
        admin_username = "disabledbygts"
        admin_password = "DisabledByGTS1!"
    }

    os_profile_linux_config {
        disable_password_authentication = false
    }

    os_profile_secrets {
        source_vault_id = "${var.azure_deploy_keyvault_id}"
        vault_certificates {
            certificate_url = "${var.azure_deploy_keyvault_encryption_cert_url}"
        }
    }

    network_profile {
        name = "bemsuos-vmss-nic"
        network_security_group_id = "${var.azure_bemsuos_vmss_nsg_id}"
        primary = true

        ip_configuration {
            name = "bemsuos-vmss-ipcf"
            primary = true
            subnet_id = "${var.azure_bemsuos_subnet_id}"
        }
    }

    storage_profile_image_reference {
        id = "${data.terraform_remote_state.image_info.baked_uos_id}"
    }

    storage_profile_os_disk {
        caching = "ReadWrite"
        create_option = "FromImage"
        managed_disk_type = "${var.azure_managed_disk_type}"
    }

    boot_diagnostics {
        enabled = "${var.azure_bemsuos_bootdiag_enabled}"
        storage_uri = "${var.azure_bemsuos_bootdiag_storage_account_uri}"
    }

    tags = "${merge(
                var.azure_tags,
                map("bb:component", "uos"),
                map("bemscloud.owner_hostname", trimspace(file("/etc/hostname")))
            )}"

}

resource "azurerm_virtual_machine_scale_set" "bemsuosegress" {
    count = "${lower(var.egress_lb) == "true" ? 1 : 0}"
    name = "${var.partition_name}-uos-${var.partition_version}"
    location = "${var.azure_location}"
    overprovision = false
    resource_group_name = "${var.azure_bemsuos_resource_group}"
    upgrade_policy_mode = "Manual"
    zones = "${var.azure_bemsuos_availability_zones}"

    sku {
        name = "${var.azure_bemsuos_vm_size}"
        tier = "Standard"
        capacity = "${var.azure_bemsuos_vmss_capacity}"
    }

    os_profile {
        computer_name_prefix = "${var.partition_name}-uos-${var.partition_version}-"
        custom_data = "${data.template_cloudinit_config.bemsuos_cloudinit_userdata.rendered}"
        admin_username = "disabledbygts"
        admin_password = "DisabledByGTS1!"
    }

    os_profile_linux_config {
        disable_password_authentication = false
    }

    os_profile_secrets {
        source_vault_id = "${var.azure_deploy_keyvault_id}"
        vault_certificates {
            certificate_url = "${var.azure_deploy_keyvault_encryption_cert_url}"
        }
    }

    network_profile {
        name = "bemsuos-vmss-nic"
        network_security_group_id = "${var.azure_bemsuos_vmss_nsg_id}"
        primary = true

        ip_configuration {
            name = "bemsuos-vmss-ipcf"
            primary = true
            subnet_id = "${var.azure_bemsuos_subnet_id}"
            load_balancer_backend_address_pool_ids = [
                "${data.terraform_remote_state.bemspartition_prepare.lb_public_egress_bap_id}"
            ]
        }
    }

    storage_profile_image_reference {
        id = "${data.terraform_remote_state.image_info.baked_uos_id}"
    }

    storage_profile_os_disk {
        caching = "ReadWrite"
        create_option = "FromImage"
        managed_disk_type = "${var.azure_managed_disk_type}"
    }

    boot_diagnostics {
        enabled = "${var.azure_bemsuos_bootdiag_enabled}"
        storage_uri = "${var.azure_bemsuos_bootdiag_storage_account_uri}"
    }

    tags = "${merge(
                var.azure_tags,
                map("bb:component", "uos"),
                map("bemscloud.owner_hostname", trimspace(file("/etc/hostname")))
            )}"

}

