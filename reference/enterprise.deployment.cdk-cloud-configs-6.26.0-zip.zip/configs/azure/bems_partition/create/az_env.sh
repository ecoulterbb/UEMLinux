#!/usr/bin/env bash

# This is a special environment variable that az checks for
# Use a subfolder of the current working directory to support concurrency
export AZURE_CONFIG_DIR=$(pwd)/azureconfig
export AZURE_CORE_COLLECT_TELEMETRY=false

export AZURE_ENVIRONMENT='${EPF::azure_environment}'
export AZURE_SUBSCRIPTION_ID='${EPF::azure_subscription_id}'
export AZURE_UOS_RESOURCE_GROUP='${EPF::azure_bemsuos_resource_group}'
export AZURE_WAFL_RESOURCE_GROUP='${EPF::azure_bemswafl_resource_group}'
export PARTITION_NAME='${EPF::epf_partition_name}'
export PARTITION_VERSION='${EPF::bundle_version}d${EPF::deployment_version}'
export AZURE_CLIENT_ID="${TF_VAR_azure_client_id}"
export AZURE_CLIENT_SECRET="${TF_VAR_azure_client_secret}"
export AZURE_TENANT_ID='${EPF::azure_tenant_id}'
export DNS_INTERNAL_ZONE='${EPF::dns_internal_zone}'

az_retry() {
    COUNT=0
    TIMEOUT=$1
    shift
    while true; do
        out="$(timeout $TIMEOUT az "$@" 2>&1)"
        rc=$?
        if [ $rc -eq 0 ]; then
            printf "$out\n"
            return 0
        elif [ $rc -eq 124 ]; then
            # if timeout is hit, it returns 124
            >&2 echo -n "Azure CLI command timed out after $TIMEOUT seconds."
        elif [ $rc -eq 2 ]; then
            # if az cannot login, it returns 2
            >&2 printf "Azure CLI cannot login:\n$out\n"
            return $rc
        elif [ $rc -eq 1 ] && (printf "$out"| grep "There are no active accounts" 2>&1 >/dev/null); then
            # if there is no login, it errors at logout
            >&2 printf "Aure CLI cannot logout: $out\n"
            return $rc
        elif [ $rc -eq 1 ] && (printf "$out"| grep "Subscription.*not found" 2>&1 >/dev/null); then
            # invalid subscription
            >&2 printf "Invalid Azure subscription: $out\n"
            return $rc
        elif [ $rc -eq 1 ] && (printf "$out"| grep "The client.*with object id.*does not have authorization" 2>&1 >/dev/null); then
            # invalid resource group
            >&2 printf "Invalid Azure resource group: $out\n"
            return $rc
        elif [ $rc -eq 1 ] && (printf "$out"| grep "Parent resource.*not found" 2>&1 >/dev/null); then
            # invalid resource
            >&2 printf "Azure resource not found: $out\n"
            return $rc
        else
            >&2 printf "Azure CLI command returned error code (${rc}):\n$out\n"
        fi

        if [[ $((COUNT++)) -ge ${EPF::azure_cli_retry_attempts} ]]; then
            >&2 echo " Failed after ${EPF::azure_cli_retry_attempts} retries."
            return 1
        fi

        >&2 echo " Retrying in 10 seconds (retry ${COUNT} of ${EPF::azure_cli_retry_attempts})..."
        sleep 10
    done
}
