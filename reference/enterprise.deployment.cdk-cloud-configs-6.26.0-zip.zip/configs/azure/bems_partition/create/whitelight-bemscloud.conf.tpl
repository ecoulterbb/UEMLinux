#The connections below will inject bypass rules into "ip xfrm policy"
#to ensure that all inbound BEMS Cloud traffic is not encrypted with IPSEC

conn whitelist-incoming-bemsuos-service
    left=%defaultroute
    leftprotoport=tcp/${bemsuos_service_pool_port}
    right=0.0.0.0
    rightsubnet=0.0.0.0/0
    rightprotoport=tcp/%any
    auto=route
    type=passthrough
    priority=1000

conn whitelist-incoming-bemsuos-config
    left=%defaultroute
    leftprotoport=tcp/${bemsuos_config_port}
    right=0.0.0.0
    rightsubnet=0.0.0.0/0
    rightprotoport=tcp/%any
    auto=route
    type=passthrough
    priority=1000

conn whitelist-incoming-wafl-hc-bems
    left=%defaultroute
    leftprotoport=tcp/${bemswafl_hc_bems_port}
    right=0.0.0.0
    rightsubnet=0.0.0.0/0
    rightprotoport=tcp/%any
    auto=route
    type=passthrough
    priority=1000
