#!/usr/bin/env bash
set -o errexit

unset KEY_VAULT_CLIENT_SECRET
