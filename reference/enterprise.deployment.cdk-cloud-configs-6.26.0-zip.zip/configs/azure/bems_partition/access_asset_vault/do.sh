#!/usr/bin/env bash
set -o errexit
source bash_env.sh

export KEY_VAULT_CLIENT_SECRET=$( \
    echo -n ${AZURE_ASSET_KEYVAULT_CLIENT_SECRET} | \
    openssl rsautl -encrypt -pubin -inkey /opt/uemcloud/encryption.key | \
    openssl enc -a -A | tr -d '=' | tr '/+' '_-' \
)

unset AZURE_ASSET_KEYVAULT_CLIENT_SECRET
