#!/usr/bin/env bash

# use deployment SP key for access to asset keyvault too
export AZURE_ASSET_KEYVAULT_CLIENT_SECRET="${TF_VAR_azure_client_secret}"
