#!/usr/bin/env bash
source bash_env.sh

function wait_for_wafl() {
    SERVICE=$1
    POOL_SERVICE_URL=$2
    BACKEND_VERSIONED=$3

    echo "Waiting for an active WAFL node connected to current version of ${SERVICE}"
    while true; do
        POOL_SERVICE_VERSION=$(curl -x "" -s -m 5 "${POOL_SERVICE_URL}")
        if [ "$POOL_SERVICE_VERSION" == "$BACKEND_VERSIONED" ]; then
            echo "done."
            break
        else
            echo -n '.'
            sleep 5
        fi
    done
}

wait_for_wafl 'bems' "http://${UOS_POOL_FQDN_INTERNAL}:1${BEMS_HEALTHCHECK_PORT}/health/service_bems.html" "${BACKEND_BEMS_VERSIONED}."
