#!/usr/bin/env bash

export BACKEND_BEMS_VERSIONED='${EPF::uos_backend_bems_versioned}'
export BEMS_HEALTHCHECK_PORT='${EPF::bemsuos_healthcheck_port}'
export UOS_POOL_FQDN_INTERNAL='${EPF::uos_pool_fqdn_internal_hc}'
export UOS_COUNT='${EPF::uos_count}'
export UOS_QUORUM='${EPF::uos_quorum}'
