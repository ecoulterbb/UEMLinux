#!/usr/bin/env bash

if [[ "x${EPF::dns_tsig_fwd}" != "x" ]] ; then
    export TF_VAR_dns_tsig_fwd_key_secret=$(echo "${EPF::dns_tsig_fwd}" | rev | cut -d: -f 1 | rev)
    export TF_VAR_dns_tsig_fwd_key_name=$(echo "${EPF::dns_tsig_fwd}" | rev | cut -d: -f 2 | rev).
    export TF_VAR_dns_tsig_fwd_key_algo=$(echo "${EPF::dns_tsig_fwd}" | rev | cut -d: -f 3 | rev)
    if [[ "x${TF_VAR_dns_tsig_fwd_key_algo}" == "x" ]] ; then
        export TF_VAR_dns_tsig_fwd_key_algo="hmac-md5"
    fi
fi

