variable "dns_internal_zone" {}
variable "dns_tsig_fwd" {}
variable "dns_tsig_ptr" {}
variable "dns_update_server" {}

variable "offline_deployment" {}

variable "uos_backend_bems_current" {}
variable "uos_backend_bems_versioned" {}

resource "dns_cname_record" "bemsuos_backend_bems" {
    count = "${var.offline_deployment ? 0 : 1}"
    zone = "${var.dns_internal_zone}."
    # use replace to allow names not directly under the dns_internal_zone, and ensure it doesn't end with a dot
    # e.g. if machine_domain is canadaeast.cp1.bems.blackberry and dns_internal_zone is bems.blackberry
    name = "${replace(replace(var.uos_backend_bems_current,var.dns_internal_zone,""), "/\\.$/","")}"
    cname = "${var.uos_backend_bems_versioned}."
    ttl = 61
}
