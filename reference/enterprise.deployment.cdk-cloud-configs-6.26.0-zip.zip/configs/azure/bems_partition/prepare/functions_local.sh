#!/usr/bin/env bash

if [ "${EPF::pg_prepare_db}" == "true" ]; then
    [[ -e postgresql.tf ]] || ln -s postgresql.tf.optional postgresql.tf
fi

if [ "${EPF::azure_public_ip_prefix_id}" == "" ]; then
    [[ -e publicip.tf ]] || ln -s publicip.tf.noprefix publicip.tf
else
    [[ -e publicip.tf ]] || ln -s publicip.tf.prefix publicip.tf
fi

