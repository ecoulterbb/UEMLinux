variable "azure_atm_enabled" {}
variable "azure_bemsuos_resource_group" {}
variable "azure_bemswafl_public_bems_configs" {}
variable "azure_bemswafl_publicip_resource_group" {}
variable "azure_bemswafl_resource_group" {}
variable "azure_bemswafl_subnet_id" {}
variable "azure_client_id" {}
variable "azure_client_secret" {}
variable "azure_disable_internal_dns_record" {}
variable "azure_dns_internal_zone" {}
variable "azure_dns_resource_group" {}
variable "azure_dns_ttl" {}
variable "azure_dns_zone" {}
variable "azure_enable_internal_dns_record_internal_zone" {}
variable "azure_environment" {}
variable "azure_location" {}
variable "azure_public_ip_prefix_id" {}
variable "azure_subscription_id" {}
variable "azure_tags" { type = "map" }
variable "azure_tenant_id" {}

variable "bemsuos_config_port" {}
variable "bemsuos_healthcheck_port" {}
variable "bemsuos_service_pool_port" {}

variable "dns_internal_zone" {}
variable "dns_tsig_fwd" {}
variable "dns_tsig_ptr" {}
variable "dns_update_server" {}

variable "egress_lb" {}
variable "egress_ports_per_host" {}
variable "offline_deployment" {}

variable "partition_name" {}

variable "pg_admin_username" {}
variable "pg_admin_password" {}
variable "pg_collation" {}
variable "pg_dbrole_name" {}
variable "pg_dbrole_password" {}
variable "pg_host" {}
variable "pg_prepare_db" {}
variable "pg_sslmode" {}

resource "azurerm_lb" "internal" {
    name = "${var.partition_name}-internal"
    location = "${var.azure_location}"
    resource_group_name = "${var.azure_bemswafl_resource_group}"
    sku = "Standard"

    frontend_ip_configuration {
        name = "${var.partition_name}-internal-ipcf"
        subnet_id = "${var.azure_bemswafl_subnet_id}"
    }

    tags = "${merge(
                var.azure_tags,
                map("bemscloud.owner_hostname", trimspace(file("/etc/hostname")))
            )}"
}

output "lb_internal_ip" {
    value = "${azurerm_lb.internal.private_ip_address}"
}

resource "azurerm_lb_backend_address_pool" "internal_wafl" {
    name = "${var.partition_name}-internal-wafl"
    resource_group_name = "${var.azure_bemswafl_resource_group}"
    loadbalancer_id = "${azurerm_lb.internal.id}"
}

output "lb_internal_wafl_bap_id" {
    value = "${azurerm_lb_backend_address_pool.internal_wafl.id}"
}

resource "azurerm_lb_probe" "wafl_to_healthy_bems" {
    name = "bemswafl_probe_hc_bems"
    resource_group_name = "${var.azure_bemswafl_resource_group}"
    loadbalancer_id = "${azurerm_lb.internal.id}"

    interval_in_seconds = "5"
    port = "1${var.bemsuos_healthcheck_port}"
    protocol = "http"
    request_path = "/health/wafl_bems.html"
}

resource "azurerm_lb_rule" "wafl_to_healthy_bems" {
    name = "wafl_to_healthy_bems"
    resource_group_name = "${var.azure_bemswafl_resource_group}"
    loadbalancer_id = "${azurerm_lb.internal.id}"
    frontend_ip_configuration_name = "${azurerm_lb.internal.name}-ipcf"
    backend_address_pool_id = "${azurerm_lb_backend_address_pool.internal_wafl.id}"

    frontend_port = "1${var.bemsuos_healthcheck_port}"
    backend_port = "1${var.bemsuos_healthcheck_port}"
    probe_id = "${azurerm_lb_probe.wafl_to_healthy_bems.id}"
    protocol = "tcp"
}

resource "azurerm_lb_probe" "internal_bems" {
    name = "bems"
    resource_group_name = "${var.azure_bemswafl_resource_group}"
    loadbalancer_id = "${azurerm_lb.internal.id}"

    interval_in_seconds = "5"
    port = "1${var.bemsuos_healthcheck_port}"
    protocol = "http"
    request_path = "/health/service_bems.html"
}

resource "azurerm_lb_rule" "internal_bems_config" {
    name = "bems_config"
    resource_group_name = "${var.azure_bemswafl_resource_group}"
    loadbalancer_id = "${azurerm_lb.internal.id}"
    frontend_ip_configuration_name = "${azurerm_lb.internal.name}-ipcf"
    backend_address_pool_id = "${azurerm_lb_backend_address_pool.internal_wafl.id}"

    frontend_port = "${var.bemsuos_config_port}"
    backend_port = "${var.bemsuos_config_port}"
    probe_id = "${azurerm_lb_probe.internal_bems.id}"
    protocol = "tcp"
}

resource "azurerm_lb" "public" {
    name = "${var.partition_name}-public"
    location = "${var.azure_location}"
    resource_group_name = "${var.azure_bemswafl_resource_group}"
    sku = "Standard"

    frontend_ip_configuration {
        name = "${var.partition_name}-public-ipcf"
        public_ip_address_id = "${azurerm_public_ip.partition.id}"
    }

    tags = "${merge(
                var.azure_tags,
                map("bemscloud.owner_hostname", trimspace(file("/etc/hostname")))
            )}"
}

resource "azurerm_lb_backend_address_pool" "public_wafl" {
    name = "${var.partition_name}-public-wafl"
    resource_group_name = "${var.azure_bemswafl_resource_group}"
    loadbalancer_id = "${azurerm_lb.public.id}"
}

output "lb_public_wafl_bap_id" {
    value = "${azurerm_lb_backend_address_pool.public_wafl.id}"
}

resource "azurerm_lb_probe" "public_bems" {
    name = "bems"
    resource_group_name = "${var.azure_bemswafl_resource_group}"
    loadbalancer_id = "${azurerm_lb.public.id}"

    interval_in_seconds = "5"
    port = "1${var.bemsuos_healthcheck_port}"
    protocol = "http"
    request_path = "/health/service_bems.html"
}

resource "azurerm_lb_rule" "public_bems_service" {
    name = "bems_service"
    resource_group_name = "${var.azure_bemswafl_resource_group}"
    loadbalancer_id = "${azurerm_lb.public.id}"
    frontend_ip_configuration_name = "${azurerm_lb.public.name}-ipcf"
    backend_address_pool_id = "${azurerm_lb_backend_address_pool.public_wafl.id}"

    frontend_port = "${var.bemsuos_service_pool_port}"
    backend_port = "${var.bemsuos_service_pool_port}"
    probe_id = "${azurerm_lb_probe.public_bems.id}"
    protocol = "tcp"
}

resource "azurerm_lb_probe" "public_bems_config" {
    # fedramp or togglable
    count = "${lower(var.azure_environment) == "usgovernment" || lower(var.azure_bemswafl_public_bems_configs) == "true" ? 1 : 0}"
    name = "bems_config"
    resource_group_name = "${var.azure_bemswafl_resource_group}"
    loadbalancer_id = "${azurerm_lb.public.id}"

    interval_in_seconds = "5"
    port = "1${var.bemsuos_healthcheck_port}"
    protocol = "http"
    request_path = "/health/service_bems.html"
}

resource "azurerm_lb_rule" "public_bems_config" {
    # fedramp or togglable
    count = "${lower(var.azure_environment) == "usgovernment" || lower(var.azure_bemswafl_public_bems_configs) == "true" ? 1 : 0}"
    name = "bems_config"
    resource_group_name = "${var.azure_bemswafl_resource_group}"
    loadbalancer_id = "${azurerm_lb.public.id}"
    frontend_ip_configuration_name = "${azurerm_lb.public.name}-ipcf"
    backend_address_pool_id = "${azurerm_lb_backend_address_pool.public_wafl.id}"

    frontend_port = "${var.bemsuos_config_port}"
    backend_port = "${var.bemsuos_config_port}"
    probe_id = "${azurerm_lb_probe.public_bems_config.id}"
    protocol = "tcp"
}

resource "azurerm_dns_a_record" "pool_internal" {
    count = "${lower(var.azure_environment) == "usgovernment" || lower(var.azure_disable_internal_dns_record) == "true" || var.offline_deployment ? 0 : 1}"
    name = "${var.partition_name}-internal"
    zone_name = "${var.azure_dns_zone}"
    resource_group_name = "${var.azure_dns_resource_group}"
    records = ["${azurerm_lb.internal.private_ip_address}"]
    ttl = "${var.azure_dns_ttl}"

    tags = "${merge(
                var.azure_tags,
                map("bemscloud.owner_hostname", trimspace(file("/etc/hostname")))
            )}"
}

resource "azurerm_dns_a_record" "bemswafl_pool_public" {
    count = "${lower(var.azure_environment) == "usgovernment" || lower(var.azure_atm_enabled) == "true" || var.offline_deployment ? 0 : 1}"
    name = "${var.partition_name}"
    zone_name = "${var.azure_dns_zone}"
    resource_group_name = "${var.azure_dns_resource_group}"
    records = ["${azurerm_public_ip.partition.ip_address}"]
    ttl = "${var.azure_dns_ttl}"

    tags = "${merge(
                var.azure_tags,
                map("bemscloud.owner_hostname", trimspace(file("/etc/hostname")))
            )}"
}

resource "dns_a_record_set" "pool_internal_usgov" {
     # fedramp only
     count = "${lower(var.azure_environment) == "usgovernment" ? 1 : 0}"
     zone = "${var.dns_internal_zone}."
     # use replace to allow names not directly under the dns_internal_zone, and ensure it doesn't end with a dot
     # e.g. if machine_domain is bemscloud.sw.rim.net and dns_internal_zone is sw.rim.net
     name = "${var.partition_name}-internal"
     addresses = ["${azurerm_lb.internal.private_ip_address}"]
     ttl = 61
}

resource "dns_a_record_set" "pool_internal_idns" {
     # for partitions using non-Azure DNS zones
     count = "${lower(var.azure_enable_internal_dns_record_internal_zone) == "true" && ! var.offline_deployment ? 1 : 0}"
     zone = "${var.dns_internal_zone}."
     # use replace to allow names not directly under the dns_internal_zone, and ensure it doesn't end with a dot
     # e.g. if machine_domain is bemscloud.sw.rim.net and dns_internal_zone is sw.rim.net
     name = "${var.partition_name}-internal"
     addresses = ["${azurerm_lb.internal.private_ip_address}"]
     ttl = 61
}

resource "azurerm_lb" "egress" {
    count = "${lower(var.egress_lb) == "true" ? 1 : 0}"
    name = "${var.partition_name}-egress"
    location = "${var.azure_location}"
    resource_group_name = "${var.azure_bemsuos_resource_group}"
    sku = "Standard"

    frontend_ip_configuration {
        name = "${var.partition_name}-egress-ipcf"
        public_ip_address_id = "${azurerm_public_ip.egress.id}"
    }

    tags = "${merge(
                var.azure_tags,
                map("uemcloud.owner_hostname", trimspace(file("/etc/hostname")))
            )}"
}

resource "azurerm_lb_backend_address_pool" "egress" {
    count = "${lower(var.egress_lb) == "true" ? 1 : 0}"
    name = "${var.partition_name}-egress"
    resource_group_name = "${var.azure_bemsuos_resource_group}"
    loadbalancer_id = "${azurerm_lb.egress.id}"
}

resource "azurerm_lb_outbound_rule" "egress" {
    count = "${lower(var.egress_lb) == "true" ? 1 : 0}"
    name = "${var.partition_name}-egress"
    resource_group_name = "${var.azure_bemsuos_resource_group}"

    loadbalancer_id = "${azurerm_lb.egress.id}"
    protocol = "All"
    enable_tcp_reset = "true"
    idle_timeout_in_minutes = "30"
    allocated_outbound_ports = "${var.egress_ports_per_host}"
    backend_address_pool_id = "${azurerm_lb_backend_address_pool.egress.id}"
    frontend_ip_configuration {
        name = "${var.partition_name}-egress-ipcf"
    }
}


output "lb_public_egress_bap_id" {
    value = "${ join ("",azurerm_lb_backend_address_pool.egress.*.id) }"
}
