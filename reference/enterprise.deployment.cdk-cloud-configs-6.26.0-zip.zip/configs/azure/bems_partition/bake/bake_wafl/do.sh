#!/usr/bin/env bash
set -o errexit

source functions_cdktools.sh

trap 'bash az_logout.sh' INT TERM EXIT
bash az_login.sh

while true; do
    if bash az_bakedimage_tagged.sh; then
        echo "Using pre-baked image."
        exit 0
    fi

    if bash az_bakedimage_lock_acquire.sh; then
        # cleanup failed/interrupted baking attempt and always release lock.
        # Disable the EXIT trap as we're already removing the lock
        trap 'echo "Baking attempt failed, removing lock and bake VM ..."; trap - EXIT; bash az_bakedimage_lock_release.sh; bash undo.sh' INT TERM ERR
        # make sure to release the lock when terminated
        trap 'bash az_bakedimage_lock_release.sh' EXIT
        break
    fi
    echo "Couldn't acquire baking lock -- another process is baking the image.  Checking again in 30 seconds..."

    sleep 30
done

if bash az_baking_enabled.sh; then
    echo "Baked image does not exist, baking image..."
    terraform init -input=false -plugin-dir=/opt/uemcloud/deploy/cdktools/terraform-plugins -upgrade
    terraform_retry apply -input=false -auto-approve=true
    packer build -color=false -var baker_host=`terraform output baker_ip` -var-file=variables.json wafl_azure.json
    terraform_retry destroy -force
    bash az_bakedimage_addtag.sh
else
    echo "ERROR: Baked image does not exist and baking is not enabled."
    exit 1
fi
