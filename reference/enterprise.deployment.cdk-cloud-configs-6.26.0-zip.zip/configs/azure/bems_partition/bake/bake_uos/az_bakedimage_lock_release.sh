#!/usr/bin/env bash
set -o errexit
source az_env.sh

bash az_login.sh

echo "Releasing baking lock $AZURE_BAKEDIMAGE_NAME..."
if az_retry 60 storage container delete --name "${AZURE_BAKEDIMAGE_NAME}-baking-lock" --account-name $AZURE_BAKEDIMAGE_STORAGE_ACCOUNT; then
    echo "Successfully released baking lock for $AZURE_BAKEDIMAGE_NAME"
    exit 0
else
    echo "ERROR: FAILED to release baking lock -- please clean up manually by removing the container ${AZURE_BAKEDIMAGE_STORAGE_ACCOUNT}/${AZURE_BAKEDIMAGE_NAME}-baking-lock"
    exit 1
fi
