#!/bin/bash

# EMM-149449 - apply log4j workaround if needed
WRAPPER=/opt/uemcloud/post_build/BEMSLinux/context/karaf-wrapper.conf
egrep -i -o 'wrapper.java.additional.*=-Dlog4j2.formatMsgNoLookups=True' ${WRAPPER}
if [[ $? -ne 0 ]]
then
    wrapper_last=$(egrep -o '^wrapper.java.additional.*' ${WRAPPER} | cut -f 1 -d '=' | cut -f 4 -d '.' | sort -rn | head -n 1)
    sed -i "/wrapper.java.additional.$(( wrapper_last ))/awrapper.java.additional.$(( wrapper_last + 1 ))=-Dlog4j2.formatMsgNoLookups=True" ${WRAPPER}
fi
