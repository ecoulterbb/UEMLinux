#!/usr/bin/env bash

# This is a special environment variable that az checks for
# Use a subfolder of the current working directory to support concurrency
export AZURE_CONFIG_DIR=$(pwd)/azureconfig
export AZURE_CORE_COLLECT_TELEMETRY=false

export AZURE_BAKEDIMAGE_NAME='${EPF::azure_bakedimage_prefix}-${EPF::product_name}cloud-uos-baked-${EPF::bundle_version}d${EPF::deployment_version}'
export AZURE_BAKEDIMAGE_STORAGE_ACCOUNT='${EPF::azure_bakedimage_storage_account}'
export AZURE_BAKEDIMAGE_STORAGE_CONTAINER='${EPF::product_name}cloud-uos'
export AZURE_BAKEDIMAGE_STORAGE_ACCOUNT_KEY='${EPF::azure_bakedimage_storage_account_key}'
export AZURE_BAKEDIMAGE_SAS_TOKEN_TIMEOUT='${EPF::azure_bakedimage_sas_token_timeout}'
export AZURE_BAKING_ENABLED='${EPF::azure_baking_enabled}'
export AZURE_BAKEDIMAGE_RESOURCE_GROUP='${EPF::azure_bakedimage_resource_group}'
export AZURE_ENVIRONMENT='${EPF::azure_environment}'
export AZURE_MANAGED_IMAGE_NAME='${EPF::azure_managed_image_name}'
export AZURE_MANAGED_IMAGE_RG='${EPF::azure_managed_image_rg}'
export AZURE_GOLD_VHD_NAME='${EPF::azure_gold_vhd_name}'
export AZURE_CLIENT_ID="${TF_VAR_azure_client_id}"
export AZURE_CLIENT_SECRET="${TF_VAR_azure_client_secret}"
export AZURE_TENANT_ID='${EPF::azure_tenant_id}'

if [[ $( echo ${EPF::bundle_version} | grep -o - | wc -l ) -eq 2 && $( echo ${EPF::deployment_version} | grep -o - | wc -l ) -eq 2 ]]
then
    export AZURE_IMAGE_EXPIRATION_LENGTH='${EPF::azure_image_expiration_length_release}'
else
    export AZURE_IMAGE_EXPIRATION_LENGTH='${EPF::azure_image_expiration_length_snapshot}'
fi

az_retry() {
    COUNT=0

    TIMEOUT=$1
    shift

    if [[ "$1" == "storage" ]]; then
        export AZURE_STORAGE_KEY=$(az storage account keys list --account-name $AZURE_BAKEDIMAGE_STORAGE_ACCOUNT -o tsv --query [0].value)
    fi

    while true; do
        if timeout $TIMEOUT az "$@"; then
            return 0
        else
            e=$?
            if [ $e -eq 124 ]; then
                # if timeout is hit, it returns code 124
                >&2 echo -n "Azure CLI command timed out after $TIMEOUT seconds."
            elif [ $e -eq 3 ]; then
                # if resource does not exist for 'az ... show', it returns code 3
                >&2 echo -n "Azure CLI command returned an error 3.  Resource does not exist."
                return 1
            elif [ $e -eq 1 ]; then
                # Generic error; server returned bad status code, CLI validation failed, etc
                cmd=$*
                if [[ "${cmd:0:17}" == "storage blob show" ]] ; then
                    # for storage blob show, pending copy has exit code 1 and an error message
                    # return to allow calling logic to handle checking
                    return 0
                else
                    >&2 echo -n "Azure CLI command returned an error (${e})."
                fi
            else
                >&2 echo -n "Azure CLI command returned an error (${e})."
            fi
        fi

        if [[ $((COUNT++)) -ge ${EPF::azure_cli_retry_attempts} ]]; then
            >&2 echo " Failed after ${EPF::azure_cli_retry_attempts} retries."
            return 1
        fi

        >&2 echo " Retrying in 10 seconds (retry ${COUNT} of ${EPF::azure_cli_retry_attempts})..."
        sleep 10
    done
}
