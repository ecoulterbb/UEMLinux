#!/usr/bin/env bash
set -o errexit
source az_env.sh

if az_retry 60 storage container create --name "${AZURE_BAKEDIMAGE_NAME}-baking-lock" --account-name $AZURE_BAKEDIMAGE_STORAGE_ACCOUNT --fail-on-exist &> /dev/null; then
    echo "Successfully acquired baking lock for $AZURE_BAKEDIMAGE_NAME"
    exit 0
else
    echo "Could not acquire baking lock for $AZURE_BAKEDIMAGE_NAME"
    exit 1
fi
