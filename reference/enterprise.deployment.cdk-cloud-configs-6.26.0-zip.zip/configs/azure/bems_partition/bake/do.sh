#!/usr/bin/env bash
set -o errexit

pushd bake_uos
echo "Processing UOS image..."
bash ./do.sh
popd

pushd bake_wafl
echo "Processing WAFL image..."
bash ./do.sh
popd

pushd image_info
echo "Gathering baked image information..."
bash ./do.sh
popd
