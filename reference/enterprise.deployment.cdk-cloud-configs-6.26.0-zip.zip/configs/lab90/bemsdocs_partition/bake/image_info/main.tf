variable "vsphere_allow_unverified_ssl" {}
variable "vsphere_datacenter" {}
variable "vsphere_password" {}
variable "vsphere_root_folder" {}
variable "vsphere_server" {}
variable "vsphere_uos_image_folder" {}
variable "vsphere_uos_image_name" {}
variable "vsphere_uos_source_image_name" {}
variable "vsphere_user" {}
variable "vsphere_wafl_image_folder" {}
variable "vsphere_wafl_image_name" {}
variable "vsphere_wafl_source_image_name" {}

data "vsphere_datacenter" "dc" {
    name = "${var.vsphere_datacenter}"
}

#### WAFL ####

data "vsphere_virtual_machine" "baked_wafl" {
    name          = "${var.vsphere_root_folder}/${var.vsphere_wafl_image_folder}/${var.vsphere_wafl_image_name}"
    datacenter_id = "${data.vsphere_datacenter.dc.id}"
}

output "baked_wafl_disk_size" {
    value = "${data.vsphere_virtual_machine.baked_wafl.disks.0.size}"
}

output "baked_wafl_guest_id" {
    value = "${data.vsphere_virtual_machine.baked_wafl.guest_id}"
}

output "baked_wafl_uuid" {
    value = "${data.vsphere_virtual_machine.baked_wafl.id}"
}

output "baked_wafl_network_interface_type" {
    value = "${data.vsphere_virtual_machine.baked_wafl.network_interface_types.0}"
}

output "baked_wafl_scsi_type" {
    value = "${data.vsphere_virtual_machine.baked_wafl.scsi_type}"
}

output "baked_wafl_source_image" {
    value = "${var.vsphere_wafl_source_image_name}"
}

#### UOS ####

data "vsphere_virtual_machine" "baked_uos" {
    name          = "${var.vsphere_root_folder}/${var.vsphere_uos_image_folder}/${var.vsphere_uos_image_name}"
    datacenter_id = "${data.vsphere_datacenter.dc.id}"
}

output "baked_uos_disk_size" {
    value = "${data.vsphere_virtual_machine.baked_uos.disks.0.size}"
}

output "baked_uos_guest_id" {
    value = "${data.vsphere_virtual_machine.baked_uos.guest_id}"
}

output "baked_uos_uuid" {
    value = "${data.vsphere_virtual_machine.baked_uos.id}"
}

output "baked_uos_network_interface_type" {
    value = "${data.vsphere_virtual_machine.baked_uos.network_interface_types.0}"
}

output "baked_uos_scsi_type" {
    value = "${data.vsphere_virtual_machine.baked_uos.scsi_type}"
}

output "baked_uos_source_image" {
    value = "${var.vsphere_uos_source_image_name}"
}
