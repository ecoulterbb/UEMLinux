#!/usr/bin/env bash
#set -o errexit
source govc_env.sh

WAFL_BAKEDIMAGE_PATH="/$GOVC_DATACENTER/$GOVC_WAFL_FOLDER/$GOVC_WAFL_BAKEDIMAGE_NAME"

IMAGE_EXISTS=$(govc_retry ls "$WAFL_BAKEDIMAGE_PATH")

if [ "$IMAGE_EXISTS" == "$WAFL_BAKEDIMAGE_PATH" ]; then
    export WAFL_BAKED_GOLD_IMAGE=$(govc_retry vm.info -json -e -vm.ipath="$WAFL_BAKEDIMAGE_PATH" | jq -r '.VirtualMachines[0].Config.ExtraConfig[] | select(.Key == "cdktools.gold_image_name") | .Value')
    echo "WAFL gold image detected as $WAFL_BAKED_GOLD_IMAGE"
    sed -i "s|WAFL_BAKED_GOLD_IMAGE|${WAFL_BAKED_GOLD_IMAGE}|" terraform.tfvars
else
    echo "Did not find baked image $GOVC_WAFL_BAKEDIMAGE_NAME"
    #exit 1
fi

UOS_BAKEDIMAGE_PATH="/$GOVC_DATACENTER/$GOVC_UOS_FOLDER/$GOVC_UOS_BAKEDIMAGE_NAME"

IMAGE_EXISTS=$(govc_retry ls "$UOS_BAKEDIMAGE_PATH")

if [ "$IMAGE_EXISTS" == "$UOS_BAKEDIMAGE_PATH" ]; then
    export UOS_BAKED_GOLD_IMAGE=$(govc_retry vm.info -json -e -vm.ipath="$UOS_BAKEDIMAGE_PATH" | jq -r '.VirtualMachines[0].Config.ExtraConfig[] | select(.Key == "cdktools.gold_image_name") | .Value')
    echo "UoS gold image detected as $UOS_BAKED_GOLD_IMAGE"
    sed -i "s|UOS_BAKED_GOLD_IMAGE|${UOS_BAKED_GOLD_IMAGE}|" terraform.tfvars
else
    echo "Did not find baked image $GOVC_UOS_BAKEDIMAGE_NAME"
    #exit 1
fi
