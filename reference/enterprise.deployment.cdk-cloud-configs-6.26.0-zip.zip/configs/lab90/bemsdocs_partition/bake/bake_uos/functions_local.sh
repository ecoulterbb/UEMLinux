#!/usr/bin/env bash

terraform_retry_cleanup() {
    TF_STATE=${TF_STATE:-terraform.tfstate}

    # if VM doesn't exist in state, try importing so any previous failed copy will be cleaned up on retry
    if ! terraform state list -state=$TF_STATE | grep -F vsphere_virtual_machine.baker; then
        terraform import -state=$TF_STATE vsphere_virtual_machine.baker "/${EPF::vsphere_datacenter}/vm/${EPF::vsphere_root_folder}/${EPF::vsphere_bakedimage_folder}/uos/${EPF::vsphere_bakedimage_prefix}bemsdocscloud-uos-baked-${EPF::bundle_version}d${EPF::deployment_version}" || true
    fi
}

export TF_VAR_uos_machinename_suffix=`echo -n '${EPF::bundle_version}d${EPF::deployment_version}' | openssl dgst -binary -sha256 | base32 | cut -c1-3`

ansible_retry() {
    COUNT=0
    until ansible-playbook "$@"; do
        if [[ $((COUNT++)) -ge 5 ]]; then
            echo "Failed after 5 attempts."
            exit 1
        fi
        echo "Retrying in 10 seconds (attempt ${COUNT} of 5)..."
        sleep 10
    done
}

