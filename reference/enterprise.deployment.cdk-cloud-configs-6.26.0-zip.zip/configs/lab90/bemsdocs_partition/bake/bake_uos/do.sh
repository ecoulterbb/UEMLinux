#!/usr/bin/env bash
set -o errexit

source functions_cdktools.sh

while true; do
    if bash govc_bakedimage_tagged.sh; then
        echo "Using pre-baked image."
        exit 0
    fi

    if bash govc_bakedimage_lock_acquire.sh; then
        # cleanup failed/interrupted baking attempt and always release lock.
        # Disable the EXIT trap as we're already removing the lock
        trap 'echo "Baking attempt failed, removing lock and bake VM ..."; trap - EXIT; bash govc_bakedimage_lock_release.sh; bash undo.sh' INT TERM ERR
        # make sure to release the lock when terminated
        trap 'bash govc_bakedimage_lock_release.sh' EXIT
        break
    fi

    echo "Couldn't acquire baking lock -- another process is baking the image.  Checking again in 30 seconds..."

    sleep 30
done

if bash govc_baking_enabled.sh; then
    echo "Baked image does not exist, baking image..."
    bash govc_sourceimage_check.sh
    terraform init -input=false -plugin-dir=/opt/uemcloud/deploy/cdktools/terraform-plugins -upgrade
    terraform_retry apply -input=false -auto-approve=true
    bash govc_waitforip.sh
    terraform_retry refresh

    bash prepare_bemsdocs.sh
    LC_BAKERIP=`terraform output baker_ip`
    LC_MYIP=`ip -4 -o addr show | grep -v ' lo ' | awk '{print $4}' | cut -d/ -f 1`

    echo "Sleeping 60 seconds to complete configuration."
    sleep 60

    # reboot system, as workaround to not being able to to WinRM commands
    echo "Rebooting VM."
    bash govc_reboot.sh

    # wait until WinRM port available
    COUNT=0
    until nc -zv -w 5 $LC_BAKERIP 5985
    do
        if [[ $((COUNT++)) -ge 5 ]]; then
            echo "Failed after 5 attempts."
            exit 1
        fi
        echo "Retrying in 60 seconds (attempt ${COUNT} of 5)..."
        sleep 60
    done

    # wait 60 seconds
    echo "Sleeping 60 seconds for Windows to be ready for WinRM."
    sleep 60

    # run Ansible to install software
    ansible_retry -e baker_host_ip=$LC_BAKERIP -e sad_ip=$LC_MYIP -e @ansible_vars.yml -i inventory.yml /opt/uemcloud/cloud-deploy-configs/common/ansible/bemsdocs_uos_bake.yml

    # wait for VM to shutdown from Sysprep via govc
    bash govc_shutdown.sh

    # tag the images
    bash govc_bakedimage_addtag.sh
    bash govc_sourceimage_tagged.sh
else
    echo "ERROR: Baked image does not exist and baking is not enabled."
    exit 1
fi
