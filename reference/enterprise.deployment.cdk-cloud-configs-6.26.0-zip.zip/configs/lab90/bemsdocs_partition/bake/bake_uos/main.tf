variable "apt_server" {}

variable "vsphere_allow_unverified_ssl" {}
variable "vsphere_baker_domain" {}
variable "vsphere_baker_folder" {}
variable "vsphere_baker_memory" { }
variable "vsphere_baker_name" {}
variable "vsphere_baker_vcpu" { }
variable "vsphere_datacenter" {}
variable "vsphere_datastore" {}
variable "vsphere_dns_servers" { type = "list" }
variable "vsphere_network" {}
variable "vsphere_password" {}
variable "vsphere_resource_pool" {}
variable "vsphere_server" {}
variable "vsphere_source_image_folder" {}
variable "vsphere_source_image_name" {}
variable "vsphere_timeout" {}
variable "vsphere_user" {}

variable "uos_machinename_prefix" {}
variable "uos_machinename_suffix" {}
variable "uos_admin_username" {}
variable "uos_admin_password" {}
variable "uos_time_zone" {}

data "vsphere_datacenter" "dc" {
    name = "${var.vsphere_datacenter}"
}

data "vsphere_datastore" "datastore" {
    name          = "${var.vsphere_datastore}"
    datacenter_id = "${data.vsphere_datacenter.dc.id}"
}

data "vsphere_resource_pool" "pool" {
    name          = "${var.vsphere_resource_pool}"
    datacenter_id = "${data.vsphere_datacenter.dc.id}"
}

data "vsphere_network" "network" {
    name          = "${var.vsphere_network}"
    datacenter_id = "${data.vsphere_datacenter.dc.id}"
}

data "vsphere_virtual_machine" "template" {
    name          = "${var.vsphere_source_image_folder}/${var.vsphere_source_image_name}"
    datacenter_id = "${data.vsphere_datacenter.dc.id}"
}

resource "vsphere_virtual_machine" "baker" {
    name             = "${var.vsphere_baker_name}"
    resource_pool_id = "${data.vsphere_resource_pool.pool.id}"
    datastore_id     = "${data.vsphere_datastore.datastore.id}"
    folder           = "${var.vsphere_baker_folder}"

    num_cpus = "${var.vsphere_baker_vcpu}"
    memory   = "${var.vsphere_baker_memory}"
    guest_id = "${data.vsphere_virtual_machine.template.guest_id}"

    scsi_type = "${data.vsphere_virtual_machine.template.scsi_type}"

    wait_for_guest_net_timeout = "${var.vsphere_timeout}"

    network_interface {
        network_id   = "${data.vsphere_network.network.id}"
        adapter_type = "${data.vsphere_virtual_machine.template.network_interface_types[0]}"
    }

    disk {
        label = "disk0"
        size = 40
    }

    clone {
        template_uuid = "${data.vsphere_virtual_machine.template.id}"

        customize {
            windows_options {
                computer_name = "${var.uos_machinename_prefix}-${var.uos_machinename_suffix}"
                admin_password = "${var.uos_admin_password}"
                time_zone = "${var.uos_time_zone}"
                auto_logon = true
                run_once_command_list = [
                    "c:\\windows\\system32\\windowspowershell\\v1.0\\powershell.exe -command \"echo a; Move-Item C:\\Windows\\System32\\GroupPolicy\\Machine\\registry.pol C:\\Windows\\Temp\\registry.pol; gpupdate /force\"",
                    "c:\\windows\\system32\\windowspowershell\\v1.0\\powershell.exe -command \"echo b; winrm quickconfig -q\"",
                    "c:\\windows\\system32\\windowspowershell\\v1.0\\powershell.exe -command \"echo c; Set-Item -Path WSMan:\\localhost\\Service\\Auth\\Basic -Value $true; Set-Item -Path WSMan:\\localhost\\Service\\AllowUnencrypted -Value $true\"",
                    "c:\\windows\\system32\\windowspowershell\\v1.0\\powershell.exe -command \"echo d; Restart-Service winrm\"",
                    "netsh advfirewall firewall set rule name=\"Windows Remote Management (HTTP-In)\" profile=public new remoteip=10.90.0.0/16",

                    "reg add 'HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Terminal Server' /v fDenyTSConnections /t REG_DWORD /d 0 /f\"",
                    "reg add HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control /v AutoStartDelay /t REG_DWORD /d 600000 /f\"",
                    "reg add HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control /v ServicePipeTimeout /t REG_DWORD /d 180000 /f\"",
                    "w32tm /config /update /manualpeerlist:\"bbsntp01.bbs.testnet.rim.net bbsntp02.bbs.testnet.rim.net\" /syncfromflags:manual",

                    "net user \"${var.uos_admin_username}\" ${var.uos_admin_password} /add /y",
                    "net localgroup \"Remote Management Users\" ${var.uos_admin_username} /add",
                    "net localgroup \"Administrators\" ${var.uos_admin_username} /add",
                    "wmic UserAccount where Name=\"${var.uos_admin_username}\" set PasswordExpires=False"
                ]
            }

            network_interface {}
            timeout = "${var.vsphere_timeout}"
        }
        timeout = "${var.vsphere_timeout}"
    }

    connection {
        type = "winrm"
        user = "${var.uos_admin_username}"
        password = "${var.uos_admin_password}"
        host = "${self.default_ip_address}"
    }

    # prevent issues if we need to make manual changes after deployment, or retry deployment
    lifecycle {
       ignore_changes = ["cpu_share_level", "extra_config", "ept_rvi_mode", "hv_mode"]
    }
}

output "baker_ip" {
  value = "${vsphere_virtual_machine.baker.default_ip_address}"
}
