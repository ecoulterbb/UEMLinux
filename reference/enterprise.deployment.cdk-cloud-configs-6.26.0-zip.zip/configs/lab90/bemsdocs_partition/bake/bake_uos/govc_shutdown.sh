#!/usr/bin/env bash
set -o errexit
source govc_env.sh

echo "Waiting for $GOVC_BAKEDIMAGE_NAME to power off..."
while ! govc vm.info -vm.ipath="/$GOVC_DATACENTER/$GOVC_FOLDER/$GOVC_BAKEDIMAGE_NAME" | grep 'Power state:  poweredOff'; do
  sleep 2
done

