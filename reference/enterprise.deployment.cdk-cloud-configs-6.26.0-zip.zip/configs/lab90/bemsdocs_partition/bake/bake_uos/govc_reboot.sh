#!/usr/bin/env bash
set -o errexit
source govc_env.sh

echo "Rebooting $GOVC_BAKEDIMAGE_NAME..."
govc_retry vm.power -r=true -vm.ipath="/$GOVC_DATACENTER/$GOVC_FOLDER/$GOVC_BAKEDIMAGE_NAME"
