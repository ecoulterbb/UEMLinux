#!/usr/bin/env bash

export GOVC_BAKING_ENABLED='${EPF::vsphere_baking_enabled}'
export GOVC_BAKEDIMAGE_NAME='${EPF::vsphere_bakedimage_prefix}bemsdocscloud-uos-baked-${EPF::bundle_version}d${EPF::deployment_version}'
export GOVC_DATACENTER='${EPF::vsphere_datacenter}'
export GOVC_DATASTORE='${EPF::vsphere_datastore}'
export GOVC_FOLDER='vm/${EPF::vsphere_root_folder}/${EPF::vsphere_bakedimage_folder}/bemsdocscloud-uos'
export GOVC_GOLD_IMAGE_NAME='${EPF::vsphere_windows_gold_image_name}'
export GOVC_INSECURE='${EPF::vsphere_allow_unverified_ssl}'
export GOVC_RESOURCE_POOL='${EPF::vsphere_resource_pool}'
export GOVC_USERNAME="${TF_VAR_vsphere_user}"
export GOVC_PASSWORD="${TF_VAR_vsphere_password}"
export GOVC_URL='${EPF::vsphere_server}'
export GOVC_GOLD_IMAGE_FOLDER='vm/${EPF::vsphere_gold_image_folder}'

govc_retry() {
    COUNT=0

    while true; do
        if govc "$@"; then
            return 0
        else
            e=$?
            >&2 echo -n "govc returned an error (${e})."
        fi

        if [[ $((COUNT++)) -ge ${EPF::vsphere_govc_retry_attempts} ]]; then
            >&2 echo " Failed after ${EPF::vsphere_govc_retry_attempts} retries."
            return 1
        fi

        >&2 echo " Retrying in 10 seconds (retry ${COUNT} of ${EPF::vsphere_govc_retry_attempts})..."
        sleep 10
    done
}
