#!/usr/bin/env bash

terraform_retry_cleanup() {
    TF_STATE=${TF_STATE:-terraform.tfstate}

    # if VM doesn't exist in state, try importing so any previous failed copy will be cleaned up on retry
    if ! terraform state list -state=$TF_STATE | grep -F vsphere_virtual_machine.baker; then
        terraform import -state=$TF_STATE vsphere_virtual_machine.baker "/${EPF::vsphere_datacenter}/vm/${EPF::vsphere_root_folder}/${EPF::vsphere_bakedimage_folder}/bemsdocscloud-wafl/${EPF::vsphere_bakedimage_prefix}bemsdocscloud-wafl-baked-${EPF::deployment_version}" || true
    fi
}
