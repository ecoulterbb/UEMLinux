variable "apt_server" {}

variable "vsphere_allow_unverified_ssl" {}
variable "vsphere_baker_domain" {}
variable "vsphere_baker_folder" {}
variable "vsphere_baker_memory" { }
variable "vsphere_baker_name" {}
variable "vsphere_baker_vcpu" { }
variable "vsphere_datacenter" {}
variable "vsphere_datastore" {}
variable "vsphere_dns_servers" { type = "list" }
variable "vsphere_network" {}
variable "vsphere_password" {}
variable "vsphere_resource_pool" {}
variable "vsphere_server" {}
variable "vsphere_source_image_folder" {}
variable "vsphere_source_image_name" {}
variable "vsphere_timeout" {}
variable "vsphere_user" {}

data "vsphere_datacenter" "dc" {
    name = "${var.vsphere_datacenter}"
}

data "vsphere_datastore" "datastore" {
    name          = "${var.vsphere_datastore}"
    datacenter_id = "${data.vsphere_datacenter.dc.id}"
}

data "vsphere_resource_pool" "pool" {
    name          = "${var.vsphere_resource_pool}"
    datacenter_id = "${data.vsphere_datacenter.dc.id}"
}

data "vsphere_network" "network" {
    name          = "${var.vsphere_network}"
    datacenter_id = "${data.vsphere_datacenter.dc.id}"
}

data "vsphere_virtual_machine" "template" {
    name          = "${var.vsphere_source_image_folder}/${var.vsphere_source_image_name}"
    datacenter_id = "${data.vsphere_datacenter.dc.id}"
}

resource "vsphere_virtual_machine" "baker" {
    name             = "${var.vsphere_baker_name}"
    resource_pool_id = "${data.vsphere_resource_pool.pool.id}"
    datastore_id     = "${data.vsphere_datastore.datastore.id}"
    folder           = "${var.vsphere_baker_folder}"

    num_cpus = "${var.vsphere_baker_vcpu}"
    memory   = "${var.vsphere_baker_memory}"
    guest_id = "${data.vsphere_virtual_machine.template.guest_id}"

    scsi_type = "${data.vsphere_virtual_machine.template.scsi_type}"

    wait_for_guest_net_timeout = "${var.vsphere_timeout}"

    network_interface {
        network_id   = "${data.vsphere_network.network.id}"
        adapter_type = "${data.vsphere_virtual_machine.template.network_interface_types[0]}"
    }

    disk {
        label = "disk0"
        size = 10
    }

    extra_config {
        guestinfo.cloudinit.metadata = "${data.template_file.baker_cloudinit_metadata.rendered}"
        guestinfo.metadata = "${data.template_file.baker_cloudinit_metadata.rendered}"
        guestinfo.cloudinit.userdata = "${data.template_file.baker_cloudinit_userdata.rendered}"
        guestinfo.userdata = "${data.template_file.baker_cloudinit_userdata.rendered}"
    }

    clone {
        template_uuid = "${data.vsphere_virtual_machine.template.id}"
        timeout = "${var.vsphere_timeout}"
    }

    # prevent issues if we need to make manual changes after deployment, or retry deployment
    lifecycle {
       ignore_changes = ["cpu_share_level", "extra_config", "ept_rvi_mode", "hv_mode"]
    }
}

data "template_file" "baker_cloudinit_metadata" {
    template = "${file("${path.module}/cloudinit_metadata.tpl")}"

    vars {
        instance_id = "${var.vsphere_baker_name}"
        dns_nameservers = "${join(" ", var.vsphere_dns_servers)}"
        dns_search = "${var.vsphere_baker_domain}"
    }
}

data "template_file" "baker_cloudinit_userdata" {
    template = "${file("${path.module}/cloudinit_userdata_bake.tpl")}"

    vars = {
        apt_server = "${var.apt_server}"
        ssh_authorized_key = "${file("/opt/uemcloud/.ssh/id_rsa.pub")}"
    }
}

output "baker_ip" {
  value = "${vsphere_virtual_machine.baker.default_ip_address}"
}
