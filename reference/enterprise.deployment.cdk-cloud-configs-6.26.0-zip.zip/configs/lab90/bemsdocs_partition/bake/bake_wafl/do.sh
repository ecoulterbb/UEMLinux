#!/usr/bin/env bash
set -o errexit

source functions_cdktools.sh

while true; do
    if bash govc_bakedimage_tagged.sh; then
        echo "Using pre-baked image."
        exit 0
    fi

    if bash govc_bakedimage_lock_acquire.sh; then
        # cleanup failed/interrupted baking attempt and always release lock.
        # Disable the EXIT trap as we're already removing the lock
        trap 'echo "Baking attempt failed, removing lock and bake VM ..."; trap - EXIT; bash govc_bakedimage_lock_release.sh; bash undo.sh' INT TERM ERR
        # make sure to release the lock when terminated
        trap 'bash govc_bakedimage_lock_release.sh' EXIT
        break
    fi

    echo "Couldn't acquire baking lock -- another process is baking the image.  Checking again in 30 seconds..."

    sleep 30
done

if bash govc_baking_enabled.sh; then
    echo "Baked image does not exist, baking image..."
    bash govc_sourceimage_check.sh
    terraform init -input=false -plugin-dir=/opt/uemcloud/deploy/cdktools/terraform-plugins -upgrade
    terraform_retry apply -input=false -auto-approve=true
    bash govc_waitforip.sh
    terraform_retry refresh
    packer build -color=false -var baker_host=`terraform output baker_ip` -var-file=variables.json wafl_vsphere.json
    bash govc_shutdown.sh
    bash govc_bakedimage_addtag.sh
else
    echo "ERROR: Baked image does not exist and baking is not enabled."
    exit 1
fi
