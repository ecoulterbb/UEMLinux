#!/usr/bin/env bash
set -o errexit

source functions_cdktools.sh

TF_STATE="../../../../lab90-admin_slave-prepare-terraform.tfstate"

terraform init -input=false -plugin-dir=/opt/uemcloud/deploy/cdktools/terraform-plugins -upgrade
terraform_retry apply -input=false -auto-approve=true -state=$TF_STATE
