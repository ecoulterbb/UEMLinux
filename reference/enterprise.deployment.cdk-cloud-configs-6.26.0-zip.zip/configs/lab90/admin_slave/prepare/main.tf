variable "region_name" {}

variable "vsphere_allow_unverified_ssl" {}
variable "vsphere_datacenter" {}
variable "vsphere_datastore" {}
variable "vsphere_password" {}
variable "vsphere_root_folder" {}
variable "vsphere_sad_shareddisk_folder" {}
variable "vsphere_sad_shareddisk_name" {}
variable "vsphere_server" {}
variable "vsphere_user" {}

data "vsphere_datacenter" "dc" {
    name = "${var.vsphere_datacenter}"
}

data "vsphere_datastore" "datastore" {
    name          = "${var.vsphere_datastore}"
    datacenter_id = "${data.vsphere_datacenter.dc.id}"
}

resource "vsphere_folder" "region" {
    path          = "${var.vsphere_root_folder}/${var.region_name}"
    type          = "vm"
    datacenter_id = "${data.vsphere_datacenter.dc.id}"
}

resource "vsphere_virtual_disk" "shared" {
    datacenter = "${data.vsphere_datacenter.dc.name}"
    datastore  = "${data.vsphere_datastore.datastore.name}"
    size       = 5
    type       = "thin"
    vmdk_path  = "${var.vsphere_sad_shareddisk_folder}/${var.vsphere_sad_shareddisk_name}"

    lifecycle {
        # bug in terraform doesn't properly read disk size
        # vmdk_path and datastore for upgrades where these are changing
        ignore_changes = ["vmdk_path","datastore"]
    }
}
