#!/usr/bin/env bash
set -o errexit
source govc_env.sh

echo "Attaching shared disk ${GOVC_SAD_SHAREDDISK_PATH} to ${GOVC_SAD_NAME}..."
govc_retry vm.disk.attach -vm.ipath="/${GOVC_DATACENTER}/${GOVC_FOLDER}/${GOVC_SAD_NAME}" -controller='pvscsi-1000' -disk="${GOVC_SAD_SHAREDDISK_PATH}" -ds="${GOVC_DATASTORE}" -link=false

cat > shareddisk_attach.sh << 'EOF'
# rescan disks to find the newly attached one
echo '- - -' | sudo tee /sys/class/scsi_host/host2/scan

# partition and format disk if needed
if ! fdisk -l /dev/sdb | grep sdb1; then
    echo "Partitioning and formatting new shared disk..."
    echo "n
    p
    1


    w
    "| fdisk /dev/sdb
    mkfs -t ext4 /dev/sdb1
fi

echo "Mounting shared disk..."
mkdir -p /opt/uemcloud/deploy
chown -R uemcloud:uemcloud /opt/uemcloud/deploy

echo "UUID=$(sudo blkid -s UUID -o value /dev/sdb1) /opt/uemcloud/deploy ext4 defaults,nofail 0 2" | tee -a /etc/fstab
mount /opt/uemcloud/deploy

# copy baked-in terraform plugins to cache in shared disk (so older plugins are preserved during upgrades)
mkdir -p /opt/uemcloud/deploy/cdktools/terraform-plugins
cp /usr/lib/terraform-plugins/* /opt/uemcloud/deploy/cdktools/terraform-plugins

chown -R uemcloud:uemcloud /opt/uemcloud/deploy
EOF

scp -q -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null shareddisk_attach.sh $GOVC_SAD_IP:
ssh -qn -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null $GOVC_SAD_IP 'sudo bash /opt/uemcloud/shareddisk_attach.sh'
