#!/usr/bin/env bash

# instead of contextualizing, pull data from prepare step state
# this allows upgrades from older configs, and leaves the disk in the old spot
PREPARE_TF_STATE='../../../../lab90-admin_slave-prepare-terraform.tfstate'
export GOVC_DATASTORE=$(terraform state show -state=${PREPARE_TF_STATE} vsphere_virtual_disk.shared | grep datastore | sed 's/datastore.*= //')
export GOVC_SAD_SHAREDDISK_PATH=$(terraform state show -state=${PREPARE_TF_STATE} vsphere_virtual_disk.shared | grep vmdk_path | sed 's/vmdk_path.*= //')

export GOVC_DATACENTER='${EPF::vsphere_datacenter}'
export GOVC_FOLDER='vm/${EPF::vsphere_root_folder}/${EPF::epf_region_name}'
export GOVC_INSECURE='${EPF::vsphere_allow_unverified_ssl}'
export GOVC_SAD_IP="$(terraform output -state=../create/terraform.tfstate dest_slaveadmin_ip)"
export GOVC_SAD_NAME='${EPF::product_name}.${EPF::sad_name}'
export GOVC_USERNAME="${TF_VAR_vsphere_user}"
export GOVC_PASSWORD="${TF_VAR_vsphere_password}"
export GOVC_URL='${EPF::vsphere_server}'

govc_retry() {
    COUNT=0

    while true; do
        if govc "$@"; then
            return 0
        else
            e=$?
            echo -n "govc returned an error (${e})."
        fi

        if [[ $((COUNT++)) -ge ${EPF::vsphere_govc_retry_attempts} ]]; then
            echo " Failed after ${EPF::vsphere_govc_retry_attempts} retries."
            return 1
        fi

        echo " Retrying in 10 seconds (retry ${COUNT} of ${EPF::vsphere_govc_retry_attempts})..."
        sleep 10
    done
}
