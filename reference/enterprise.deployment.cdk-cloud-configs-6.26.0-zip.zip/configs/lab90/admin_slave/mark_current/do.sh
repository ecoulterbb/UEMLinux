#!/usr/bin/env bash
set -o errexit

source functions_cdktools.sh

TF_STATE="../../../../lab90-admin_slave-mark_current-terraform.tfstate"

echo "Marking SAD current..."
terraform init -input=false -plugin-dir=../../../../../cdktools/terraform-plugins -upgrade
terraform_retry apply -input=false -auto-approve=true -state=$TF_STATE

./govc_shareddisk_attach.sh
