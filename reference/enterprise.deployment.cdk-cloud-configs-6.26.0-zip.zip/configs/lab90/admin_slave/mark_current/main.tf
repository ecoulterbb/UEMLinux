variable "dns_internal_zone" {}
variable "dns_update_server" {}

variable "machine_domain" {}

variable "region_name" {}

variable "sad_name" {}

resource "dns_cname_record" "sad_common" {
    zone = "${var.dns_internal_zone}."
    # use replace to allow names not directly under the dns_internal_zone, and ensure it doesn't end with a dot
    # e.g. if machine_domain is canadaeast.cp1.uem.blackberry and dns_internal_zone is uem.blackberry
    name = "${replace("${var.region_name}-sad.${replace(var.machine_domain,var.dns_internal_zone,"")}", "/\\.$/","")}"
    cname = "${var.sad_name}.${var.machine_domain}."
    ttl = 61
}
