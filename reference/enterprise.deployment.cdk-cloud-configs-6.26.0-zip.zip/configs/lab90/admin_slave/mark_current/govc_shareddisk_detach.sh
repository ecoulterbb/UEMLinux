#!/usr/bin/env bash
set -o errexit
source govc_env.sh

if govc device.info -vm.ipath="/${GOVC_DATACENTER}/${GOVC_FOLDER}/${GOVC_SAD_NAME}" disk-1000-1; then
    echo "Removing shared disk ${GOVC_SAD_SHAREDDISK_PATH} from ${GOVC_SAD_NAME}..."

    ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null $GOVC_SAD_IP << 'EOF'
    # only unmount if it is currently mounted
    if mountpoint -q ~/deploy; then
        echo "Unmounting shared disk..."
        COUNT=0
        until sudo umount ~/deploy; do
            if [[ $((COUNT++)) -ge 5 ]]; then
                echo "Failed after 5 attempts."
                exit 1
            fi
            echo "Attempting to kill processes using ~/deploy directory..."
            fuser -v -m ~/deploy -k
            echo "Retrying in 5 seconds (attempt ${COUNT} of 5)..."
            sleep 5
        done
        echo "Shared disk was unmounted."
    fi
EOF

    echo "Detaching shared disk..."
    govc_retry device.remove -keep=true -vm.ipath="/${GOVC_DATACENTER}/${GOVC_FOLDER}/${GOVC_SAD_NAME}" disk-1000-1
else
    # disk not mounted
    # EMM-150418 -- failed upgrade, disk is on other SAD
    cdk_region_dir=$(pwd | rev | cut -d/ -f 5- | rev)
    current_version_dir=$(pwd | rev | cut -d/ -f 4- | rev)

    # check if current
    if [[ $(readlink ${cdk_region_dir}/current) == ${current_version_dir} ]]; then
        # check for other versions
        for i in $(find $cdk_region_dir -mindepth 1 -maxdepth 1 -type d | grep -v ${current_version_dir});
        do
            # if they are contextualized
            if [[ -e $i/lab90/admin_slave/mark_current/govc_env.sh.contextualization.backup ]]; then
                # attempt to detached the disk
                pushd $i/lab90/admin_slave/mark_current
                source govc_env.sh
                ./govc_shareddisk_detach.sh
                popd
            fi
        done
    fi
fi
