#!/usr/bin/env bash
set -o errexit

source functions_cdktools.sh

TF_STATE="../../../../lab90-admin_slave-mark_current-terraform.tfstate"

if [ -f "terraform.tfvars.contextualization.backup" -a -f "$TF_STATE" ]; then
    terraform init -input=false -plugin-dir=../../../../../cdktools/terraform-plugins -upgrade
    # Only destroy if the record hasn't been modified by someone else.
    # With -detailed-exitcode, terraform plan will only return a 0 error code if
    # applying would make no changes
    if terraform plan -state=$TF_STATE -detailed-exitcode; then
        terraform_retry destroy -force -state=$TF_STATE
    else
        echo "Skipping terraform destroy as it has been updated by another SAD"
    fi
else
    echo "Skipping terraform destroy as contextualization was not completed or state file was not found."
fi

if [ -f "govc_env.sh.contextualization.backup" ]; then
    ./govc_shareddisk_detach.sh
else
    echo "Not detaching shared disk as contextualization was not completed."
fi
