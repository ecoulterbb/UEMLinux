provider "dns" {
    version = "~> ${EPF::terraform_provider_dns_package_version}"

    update {
        server = "${var.dns_update_server}"
    }
}
