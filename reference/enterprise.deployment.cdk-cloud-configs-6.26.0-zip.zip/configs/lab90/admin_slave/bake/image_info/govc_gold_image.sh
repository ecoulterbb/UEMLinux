#!/usr/bin/env bash
#set -o errexit
source govc_env.sh

SAD_BAKEDIMAGE_PATH="/$GOVC_DATACENTER/$GOVC_FOLDER/$GOVC_BAKEDIMAGE_NAME"

IMAGE_EXISTS=$(govc_retry ls "$SAD_BAKEDIMAGE_PATH")

if [ "$IMAGE_EXISTS" == "$SAD_BAKEDIMAGE_PATH" ]; then
    export SAD_BAKED_GOLD_IMAGE=$(govc_retry vm.info -json -e -vm.ipath="$SAD_BAKEDIMAGE_PATH" | jq -r '.VirtualMachines[0].Config.ExtraConfig[] | select(.Key == "cdktools.gold_image_name") | .Value')
    echo "SAD gold image detected as $SAD_BAKED_GOLD_IMAGE"
    sed -i "s|SAD_BAKED_GOLD_IMAGE|${SAD_BAKED_GOLD_IMAGE}|" terraform.tfvars
else
    echo "Did not find baked image $GOVC_WAFL_BAKEDIMAGE_NAME"
    #exit 1
fi
