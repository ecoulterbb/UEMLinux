variable "vsphere_allow_unverified_ssl" {}
variable "vsphere_datacenter" {}
variable "vsphere_password" {}
variable "vsphere_root_folder" {}
variable "vsphere_sad_image_folder" {}
variable "vsphere_sad_image_name" {}
variable "vsphere_server" {}
variable "vsphere_user" {}
variable "vsphere_sad_source_image_name" {}

data "vsphere_datacenter" "dc" {
    name = "${var.vsphere_datacenter}"
}

data "vsphere_virtual_machine" "baked_sad" {
    name          = "${var.vsphere_root_folder}/${var.vsphere_sad_image_folder}/${var.vsphere_sad_image_name}"
    datacenter_id = "${data.vsphere_datacenter.dc.id}"
}

output "baked_sad_disk_size" {
    value = "${data.vsphere_virtual_machine.baked_sad.disks.0.size}"
}

output "baked_sad_guest_id" {
    value = "${data.vsphere_virtual_machine.baked_sad.guest_id}"
}

output "baked_sad_uuid" {
    value = "${data.vsphere_virtual_machine.baked_sad.id}"
}

output "baked_sad_network_interface_type" {
    value = "${data.vsphere_virtual_machine.baked_sad.network_interface_types.0}"
}

output "baked_sad_scsi_type" {
    value = "${data.vsphere_virtual_machine.baked_sad.scsi_type}"
}

output "baked_sad_source_image" {
    value = "${var.vsphere_sad_source_image_name}"
}
