#!/usr/bin/env bash
set -o errexit
source govc_env.sh

if [ "$GOVC_BAKING_ENABLED" == "true" ]; then
    exit 0
fi

exit 1
