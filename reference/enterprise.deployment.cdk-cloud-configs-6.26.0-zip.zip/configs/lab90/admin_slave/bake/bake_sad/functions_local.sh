#!/usr/bin/env bash

terraform_retry_import() {
    TF_STATE=${TF_STATE:-terraform.tfstate}

    echo "Importing failed infrastructure..."
    # if VM doesn't exist in state, try importing so any previous failed copy will be cleaned up on retry
    if ! terraform state list -state=$TF_STATE | grep -F vsphere_virtual_machine.baker; then
        terraform import -state=$TF_STATE vsphere_virtual_machine.baker "/${EPF::vsphere_datacenter}/vm/${EPF::vsphere_root_folder}/${EPF::vsphere_bakedimage_folder}/admin-slave/${EPF::vsphere_bakedimage_prefix}${EPF::product_name}cloud-sad-baked-${EPF::bundle_version}d${EPF::deployment_version}" || true
    fi
}

function terraform_retry_cleanup() {
    TF_STATE=${TF_STATE:-terraform.tfstate}
    #Not importing terraform state for baking as we are using govc and removing state file
    rm $TF_STATE
    #terraform_retry_import

    #don't do destroy via terraform 0.11 as the output variable will not be set and cause failures. 0.12 adds conditional output variables
    bash govc_bakedimage_lock_release.sh
    bash govc_bakedimage_delete.sh
    #we could redo all the checking logic but this shortcut to immediately re-aquire the lock should generally work (particularly if only one lab baking)
    bash govc_bakedimage_lock_acquire.sh
}
