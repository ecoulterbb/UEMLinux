#!/usr/bin/env bash
source govc_env.sh

echo "Releasing baking lock $GOVC_BAKEDIMAGE_NAME..."
if govc_retry object.destroy "/$GOVC_DATACENTER/$GOVC_FOLDER/$GOVC_BAKEDIMAGE_NAME-baking-lock"; then
    echo "Successfully released baking lock for $GOVC_BAKEDIMAGE_NAME"
    exit 0
else
    echo "ERROR: FAILED to release baking lock -- please clean up manually by removing the folder /$GOVC_DATACENTER/$GOVC_FOLDER/$GOVC_BAKEDIMAGE_NAME-baking-lock"
    exit 1
fi
