#!/usr/bin/env bash
source govc_env.sh

BAKEDIMAGE_PATH="/$GOVC_DATACENTER/$GOVC_FOLDER/$GOVC_BAKEDIMAGE_NAME"

IMAGE_EXISTS=$(govc_retry ls "$BAKEDIMAGE_PATH")

if [ "$IMAGE_EXISTS" == "$BAKEDIMAGE_PATH" ]; then
    IMAGE_BAKED_SUCCESSFULLY=$(govc_retry vm.info -json -e -vm.ipath="$BAKEDIMAGE_PATH" | jq -r '.VirtualMachines[0].Config.ExtraConfig[] | select(.Key == "cdktools.baked_successfully") | .Value')

    if [ "${IMAGE_BAKED_SUCCESSFULLY,,}" == "true" ]; then
        echo "Valid tag found -- image was baked successfully."
        echo "Updating 'last used' tag..."
        govc_retry vm.change -vm.ipath="$BAKEDIMAGE_PATH" -e "cdktools.image_last_used=$(date '+%Y-%m-%d@%H:%M:%S%z')"
        exit 0
    else
      echo "Image $GOVC_BAKEDIMAGE_NAME exists, but it was not baked successfully (could be either in progress or failed)"
      if bash govc_baking_enabled.sh; then
          bash govc_bakedimage_delete.sh
      fi
      exit 1
    fi
else
    echo "Did not find baked image $GOVC_BAKEDIMAGE_NAME"
    exit 1
fi
