#!/usr/bin/env bash
source govc_env.sh

echo "Trying to acquire baking lock $GOVC_BAKEDIMAGE_NAME..."
if govc folder.info "/$GOVC_DATACENTER/$GOVC_FOLDER/$GOVC_BAKEDIMAGE_NAME-baking-lock"; then
    # check to see if it exists first to avoid errors in VMware logs if possible
    echo "Baking lock for $GOVC_BAKEDIMAGE_NAME is being held by another process"
    exit 1
else
    if govc folder.create "/$GOVC_DATACENTER/$GOVC_FOLDER/$GOVC_BAKEDIMAGE_NAME-baking-lock"; then
        echo "Successfully acquired baking lock for $GOVC_BAKEDIMAGE_NAME"
        exit 0
    else
        echo "Could not acquire baking lock for $GOVC_BAKEDIMAGE_NAME"
        exit 1
    fi
fi
