#!/usr/bin/env bash
set -o errexit
source govc_env.sh

BAKEDIMAGE_PATH="/$GOVC_DATACENTER/$GOVC_FOLDER/$GOVC_BAKEDIMAGE_NAME"

if govc folder.info "/$GOVC_DATACENTER/$GOVC_FOLDER/$GOVC_BAKEDIMAGE_NAME-baking-lock" >/dev/null 2>&1; then
  echo "Cannot delete image $GOVC_BAKEDIMAGE_NAME: another baking process has a lock for it"
else
  echo "Image $GOVC_BAKEDIMAGE_NAME is NOT locked: removing image so it can retry baking on the next attempt"
  govc_retry vm.destroy "$BAKEDIMAGE_PATH"
fi

exit 0
