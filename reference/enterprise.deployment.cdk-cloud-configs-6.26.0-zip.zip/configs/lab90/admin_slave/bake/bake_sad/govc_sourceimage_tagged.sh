#!/usr/bin/env bash
source govc_env.sh

GOLDIMAGE_PATH="/$GOVC_DATACENTER/$GOVC_GOLD_IMAGE_FOLDER/$GOVC_GOLD_IMAGE_NAME"

IMAGE_EXISTS=$(govc_retry ls "$GOLDIMAGE_PATH")

if [ "$IMAGE_EXISTS" == "$GOLDIMAGE_PATH" ]; then
    echo "Updating tags for $GOVC_GOLD_IMAGE_NAME ..."
    govc_retry vm.change -vm.ipath="$GOLDIMAGE_PATH" -e="cdktools.baker_hostname=$(hostname)" -e="cdktools.baked_image_name=${GOVC_BAKEDIMAGE_NAME}" -e "cdktools.image_last_used=$(date '+%Y-%m-%d@%H:%M:%S%z')"
    exit 0
else
    echo "Did not find gold image $GOVC_GOLD_IMAGE_NAME"
    exit 1
fi
