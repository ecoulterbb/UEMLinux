#!/usr/bin/env bash
set -o errexit
source govc_env.sh

echo "Adding valid tag to ${GOVC_BAKEDIMAGE_NAME}..."
govc_retry vm.change -vm.ipath="/$GOVC_DATACENTER/$GOVC_FOLDER/$GOVC_BAKEDIMAGE_NAME" -e="cdktools.baked_successfully=true" -e="cdktools.baker_hostname=$(hostname)" -e="cdktools.gold_image_name=${GOVC_GOLD_IMAGE_NAME}" -e "cdktools.image_last_used=$(date '+%Y-%m-%d@%H:%M:%S%z')"

echo "Moving ${GOVC_BAKEDIMAGE_NAME} to temp network..."
govc_retry vm.network.change -vm.ipath="/$GOVC_DATACENTER/$GOVC_FOLDER/$GOVC_BAKEDIMAGE_NAME" -net vDS1/IN999 ethernet-0
