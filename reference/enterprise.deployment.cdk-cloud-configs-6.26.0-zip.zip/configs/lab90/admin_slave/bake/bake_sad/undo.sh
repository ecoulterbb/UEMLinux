#!/usr/bin/env bash
set -o errexit

source functions_cdktools.sh

TF_STATE="terraform.tfstate"

if [ -f "$TF_STATE" ]; then
    if bash govc_bakedimage_tagged.sh; then
        echo "Valid baked image found, leaving as-is."
    else
        echo "Valid baked image was not found"
        #not removing terraform state as it might be invalid (e.g. gold image removed)
        #invalid baked image are removed in govc_bakedimage_tagged.sh script
        #terraform init -input=false -plugin-dir=/opt/uemcloud/deploy/cdktools/terraform-plugins -upgrade
        #terraform_retry destroy -force -state=$TF_STATE
    fi
else
    echo "Skipping baked image check as state file $TF_STATE was not found."
fi
