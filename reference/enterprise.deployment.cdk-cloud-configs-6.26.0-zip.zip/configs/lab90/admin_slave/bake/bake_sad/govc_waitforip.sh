#!/usr/bin/env bash
set -o errexit
source govc_env.sh

echo "Waiting for $GOVC_BAKEDIMAGE_NAME to have an IP address..."
govc_retry vm.info -waitip=true -vm.ipath="/$GOVC_DATACENTER/$GOVC_FOLDER/$GOVC_BAKEDIMAGE_NAME"
