#!/usr/bin/env bash
source govc_env.sh

GOLDIMAGE_PATH="/$GOVC_DATACENTER/$GOVC_GOLD_IMAGE_FOLDER/$GOVC_GOLD_IMAGE_NAME"

IMAGE_EXISTS=$(govc_retry ls "$GOLDIMAGE_PATH")

if [ "$IMAGE_EXISTS" == "$GOLDIMAGE_PATH" ]; then
    echo "Checking disk for $GOVC_GOLD_IMAGE_NAME ..."
    IMAGE_THIN_PROVISIONED=$(govc_retry device.info -json -vm.ipath="$GOLDIMAGE_PATH" disk-* | jq '.Devices[].Backing | .ThinProvisioned')
    echo "Disk thin provisioning status: $IMAGE_THIN_PROVISIONED "
    if [ "$IMAGE_THIN_PROVISIONED" == "true" ]; then
      exit 0
    fi
    echo "Disk thin provisioning must be true"
else
    echo "Did not find gold image $GOVC_GOLD_IMAGE_NAME"
fi
exit 1
