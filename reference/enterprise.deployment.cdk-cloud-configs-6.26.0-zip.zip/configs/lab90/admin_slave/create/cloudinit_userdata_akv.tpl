#cloud-config
write_files:
- path: /opt/uemcloud/encryption.key
  content: ${cert_encryption}
  encoding: b64
  owner: root:root
- path: /opt/uemcloud/decryption.key
  content: ${cert_decryption}
  encoding: b64
  owner: root:root
runcmd:
  # convert certificate and private key to needed format, remove extra copies on disk
- rm -rf /var/lib/waagent/Certificates.*
- chmod 400 /opt/uemcloud/encryption.key
- chown uemcloud:uemcloud /opt/uemcloud/encryption.key
- chmod 400 /opt/uemcloud/decryption.key
- chown uemcloud:uemcloud /opt/uemcloud/decryption.key
