#!/usr/bin/env bash
if [ "${EPF::lab90_akv_deployment}" == "true" ]; then
    [[ -e azurekeyvault.tf ]] || ln -s azurekeyvault.tf.optional azurekeyvault.tf
else
    [[ -e nokeyvault.tf ]] || ln -s nokeyvault.tf.optional nokeyvault.tf
fi

terraform_retry_import() {
    TF_STATE=${TF_STATE:-terraform.tfstate}

    # if VM doesn't exist in state, try importing so any previous failed copy will be cleaned up on retry
    if ! terraform state list -state=$TF_STATE | grep -F vsphere_virtual_machine.sad; then
        terraform import -state=$TF_STATE vsphere_virtual_machine.sad "/${EPF::vsphere_datacenter}/vm/${EPF::vsphere_root_folder}/${EPF::epf_region_name}/${EPF::product_name}.${EPF::sad_name}" || true
    fi
}

function terraform_retry_cleanup() {
    #import any objects that were created prior to the error state
    terraform_retry_import

    TF_STATE=${TF_STATE:-terraform.tfstate}
    # if there was a transient error, we should start from scratch
    echo "Destroying failed infrastructure..."
    terraform destroy -force -state=$TF_STATE
}
