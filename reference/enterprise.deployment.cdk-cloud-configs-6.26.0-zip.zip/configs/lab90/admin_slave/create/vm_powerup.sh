#!/usr/bin/env bash
set -o errexit
source govc_env.sh

if [ -n "`govc vm.info -vm.ipath="/$GOVC_DATACENTER/$GOVC_FOLDER/$GOVC_SAD_NAME" | grep 'Power state:' | grep 'poweredOn'`" ]; then
    echo "$GOVC_SAD_NAME is already powered on"
else
    echo "Powering up $GOVC_SAD_NAME"
    govc_retry vm.power -on -vm.ipath="/$GOVC_DATACENTER/$GOVC_FOLDER/$GOVC_SAD_NAME"

    echo "Waiting for $GOVC_SAD_NAME to power on..."
    while ! govc vm.info -vm.ipath="/$GOVC_DATACENTER/$GOVC_FOLDER/$GOVC_SAD_NAME" | grep 'Power state:' | grep 'poweredOn'; do
        sleep 2
    done

    sleep 60
fi
