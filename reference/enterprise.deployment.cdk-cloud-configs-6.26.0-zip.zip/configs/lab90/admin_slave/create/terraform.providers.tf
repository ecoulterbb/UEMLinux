provider "dns" {
    version = "~> ${EPF::terraform_provider_dns_package_version}"

    update {
        server = "${var.dns_update_server}"
    }
}

provider "vsphere" {
    version = "~> ${EPF::terraform_provider_vsphere_package_version}"

    user = "${var.vsphere_user}"
    password = "${var.vsphere_password}"
    vsphere_server = "${var.vsphere_server}"
    allow_unverified_ssl = "${var.vsphere_allow_unverified_ssl}"
    persist_session = true
}
