#cloud-config
domain: ${EPF::machine_domain}
auth_domain: ${EPF::auth_domain}
auth_adbinduser: ${EPF::auth_adbinduser}
auth_adbindpass: ${EPF::auth_adbindpass}
auth_adsearchbase: ${EPF::auth_adsearchbase}
users:
- name: uemcloud
  lock_passwd: ${user_lock_passwd}
  ssh-authorized-keys:
  - ${ssh_authorized_key}
- name: bbsadmin
  ssh-authorized-keys:
  - ${bbsadmin_authorized_key}
${ apt_server != "" ? "
apt_preserve_sources_list: true
apt_sources:
  - source: deb ${EPF::apt_server} $RELEASE main restricted universe
  - source: deb ${EPF::apt_server} $RELEASE-security main restricted universe
  - source: deb ${EPF::apt_server} $RELEASE-updates main restricted universe
" : "apt_preserve_sources_list: true\n"}
chpasswd:
  list: |
    uemcloud:${user_passwd}
  expire: false
write_files:
- path: /etc/default/bbddns
  content: |
    DDNS_ZONE="${EPF::dns_internal_zone}"
  owner: root:root
  permissions: '600'
- path: /etc/ssh/groups.allow
  encoding: b64
  owner: root:root
  permissions: '0600'
  content: ${ssh_groups}
- path: /etc/ssh/users.allow
  encoding: b64
  owner: root:root
  permissions: '0600'
  content: ${ssh_users}
- path: /etc/sudoers.d/uemcloud-sudo-rules
  encoding: b64
  owner: root:root
  permissions: '0600'
  content: ${sudo_rules}
- path: /etc/default/fluent-bit
  content: ${encoded_fluentbit_env}
  encoding: b64
  owner: root:root
  permissions: '0644'
- path: /etc/fluent-bit/fluent-bit.yaml
  content: ${encoded_fluentbit_yaml}
  encoding: b64
  owner: root:root
  permissions: '0644'
- path: /etc/fluent-bit/fluent-bit-include.yaml
  content: ${encoded_fluentbit_include}
  encoding: b64
  owner: root:root
  permissions: '0644'
- path: /etc/fluent-bit/observability.uem.crt
  content: ${encoded_fluentbit_cert}
  encoding: b64
  owner: root:root
  permissions: '0644'
- path: /etc/fluent-bit/observability.uem.key
  content: ${encoded_fluentbit_key}
  encoding: b64
  owner: root:root
  permissions: '0644'
runcmd:
  # setup fluent-bit
  - 'if [ "${EPF::fluent_bit_enabled}" = "true" ] ; then'
  - sed -i "s/{{REPLACE_ME}}/$$(hostname).${EPF::machine_domain}/g" /etc/default/fluent-bit
  - systemctl enable fluent-bit
  - systemctl start fluent-bit
  - 'fi'
  # configure chrony
  - sed -i "s/^server/#server/;/# Sync time/aserver ${EPF::ntpd_server}" /etc/chrony/chrony.conf
  - service chrony restart
  # configure and restart zabbix agent
  - sed -i "s/Server=.*/Server=${EPF::zabbix_servers}/" /etc/zabbix/zabbix_agentd.conf
  - sed -i "s/ServerActive=.*/ServerActive=${EPF::zabbix_servers}/" /etc/zabbix/zabbix_agentd.conf
  - sed -i "s/HostMetadata=.*/HostMetadata=${EPF::zabbix_serviceteam}-SAD/" /etc/zabbix/zabbix_agentd.conf
  - sed -i "s/Hostname=.*/Hostname=$$(hostname).${EPF::machine_domain}/" /etc/zabbix/zabbix_agentd.conf
  - sed -i "s/ListenIP=.*/ListenIP=$$(ip -f inet -o addr | grep -wv '127.0.0.1' | tail -1 | awk '{print $4}' | cut -d/ -f 1)/" /etc/zabbix/zabbix_agentd.conf
  - sed -i "s/UserParameter=system.serviceteam, echo.*/UserParameter=system.serviceteam, echo ${EPF::zabbix_serviceteam}/" /etc/zabbix/zabbix_agentd.conf
  - sed -i "s/StartAgents=.*/StartAgents=${EPF::zabbix_startagents_sad}/" /etc/zabbix/zabbix_agentd.conf
  - sed -i "s/EnableRemoteCommands=.*/EnableRemoteCommands=${EPF::zabbix_enableremotecommands}/" /etc/zabbix/zabbix_agentd.conf
  - service zabbix-agent restart
  - systemctl enable zabbix-agent
