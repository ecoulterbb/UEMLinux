#!/usr/bin/env bash
set -o errexit

source functions_cdktools.sh

TF_STATE="terraform.tfstate"

if [ -f "$TF_STATE" ]; then
    terraform init -input=false -plugin-dir=/opt/uemcloud/deploy/cdktools/terraform-plugins -upgrade
    # need to set "destroying" to true so that if baked image is deleted before the environment,
    # we don't get a "cannot locate virtual machine or template with UUID" error
    terraform_retry destroy -force -state=$TF_STATE -var destroying=true
else
    echo "Skipping as state file $TF_STATE was not found."
fi
