variable "apt_server" {}
variable "bbsadmin_ssh_authorized_key_path" {}
variable "destroying" { default = false }

variable "dns_internal_zone" {}
variable "dns_update_server" {}

variable "env_type_sad" {}

variable "fluent_bit_enabled" {}
variable "fluent_bit_cert_path" {}
variable "fluent_bit_key_path" {}
variable "fluent_bit_custom_include" {}
variable "fluent_bit_custom_include_path" {}
variable "fluent_bit_syslog_to_kafka" {}

variable "hold_packages" {}

variable "lab90_akv_deployment" {}
variable "lab90_encryption_key_path" {}
variable "lab90_decryption_key_path" {}
variable "lab90_vm_owner" {}

variable "machine_domain" {}

variable "product_name" {}

variable "region_name" {}

variable "sad_ansible_playbook" {}
variable "sad_name" {}
variable "sad_password" {}

variable "ssh_allowed_groups" { type = "list" }
variable "sudo_groups" { type = "list" }

variable "vsphere_allow_unverified_ssl" {}
variable "vsphere_datacenter" {}
variable "vsphere_datastore" {}
variable "vsphere_dns_servers" { type = "list" }
variable "vsphere_password" {}
variable "vsphere_resource_pool" {}
variable "vsphere_root_folder" {}
variable "vsphere_sad_memory" {}
variable "vsphere_sad_network" {}
variable "vsphere_sad_vcpu" {}
variable "vsphere_server" {}
variable "vsphere_timeout" {}
variable "vsphere_user" {}

variable "whitelight_enabled" {}

variable "zabbix_psk" {}
variable "zabbix_psk_identity" {}

data "terraform_remote_state" "image_info" {
    backend = "local"

    config {
        path = "${path.module}/../bake/image_info/terraform.tfstate"
    }
}

data "vsphere_datacenter" "dc" {
    name = "${var.vsphere_datacenter}"
}

data "vsphere_datastore" "datastore" {
    name          = "${var.vsphere_datastore}"
    datacenter_id = "${data.vsphere_datacenter.dc.id}"
}

data "vsphere_resource_pool" "pool" {
    name          = "${var.vsphere_resource_pool}"
    datacenter_id = "${data.vsphere_datacenter.dc.id}"
}

data "vsphere_network" "network" {
    name          = "${var.vsphere_sad_network}"
    datacenter_id = "${data.vsphere_datacenter.dc.id}"
}

resource "vsphere_virtual_machine" "sad" {
    count            = "${var.destroying ? 0 : 1}"
    name             = "${var.product_name}.${var.sad_name}"
    resource_pool_id = "${data.vsphere_resource_pool.pool.id}"
    datastore_id     = "${data.vsphere_datastore.datastore.id}"
    folder           = "${var.vsphere_root_folder}/${var.region_name}"

    num_cpus = "${var.vsphere_sad_vcpu}"
    memory   = "${var.vsphere_sad_memory}"
    guest_id = "${data.terraform_remote_state.image_info.baked_sad_guest_id}"

    scsi_type = "${data.terraform_remote_state.image_info.baked_sad_scsi_type}"

    wait_for_guest_net_timeout = "${var.vsphere_timeout}"

    annotation = <<-EOT
        Owner: ${var.lab90_vm_owner}
        Template: ${data.terraform_remote_state.image_info.baked_sad_source_image}
        Admin node: ${trimspace(file("/etc/hostname"))}
        Last modified: ${timestamp()}
        EOT

    network_interface {
        network_id   = "${data.vsphere_network.network.id}"
        adapter_type = "${data.terraform_remote_state.image_info.baked_sad_network_interface_type}"
    }

    disk {
        label = "disk0"
        size = "${data.terraform_remote_state.image_info.baked_sad_disk_size}"
    }

    extra_config {
        guestinfo.cloudinit.metadata = "${data.template_file.sad_cloudinit_metadata.rendered}"
        guestinfo.metadata = "${data.template_file.sad_cloudinit_metadata.rendered}"
        guestinfo.cloudinit.userdata = "${data.template_cloudinit_config.sad_cloudinit_userdata.rendered}"
        guestinfo.userdata = "${data.template_cloudinit_config.sad_cloudinit_userdata.rendered}"
    }

    clone {
        template_uuid = "${data.terraform_remote_state.image_info.baked_sad_uuid}"
        timeout = "${var.vsphere_timeout}"
    }

    connection {
        type = "ssh"
        user = "uemcloud"
        private_key = "${file(pathexpand("~/.ssh/id_rsa"))}"
    }

# workaround for terraform 0.11 crypto issue connecting to ubuntu 22.04+
#    provisioner "remote-exec" {
#        inline = [
#            "while [ ! -f /var/lib/cloud/instance/boot-finished ]; do echo 'Waiting for cloud-init...'; sleep 5; done"
#        ]
#        connection {
#            script_path = "/var/tmp/wait_for_cloud_init.sh"
#        }
#    }

    provisioner "local-exec" {
        command = <<-EOT
            while ! nc -w2 -zv ${self.default_ip_address} 22 ; do sleep 5 ; done
            sleep 10
            ssh -qn -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null ${self.default_ip_address} 'while [ ! -f /var/lib/cloud/instance/boot-finished ]; do echo "Waiting for cloud-init..."; sleep 5; done'
        EOT
    }

    provisioner "local-exec" {
        command = <<-EOT
            export ANSIBLE_HOST_KEY_CHECKING=False
            export ANSIBLE_SSH_PIPELINING=True
            ansible-playbook -i '${self.default_ip_address},' -u uemcloud --extra-vars 'vars_file=${path.module}/ansible_vars.yml' ${var.sad_ansible_playbook}
        EOT
    }

    # prevent issues if we need to make manual changes after deployment, or retry deployment
    lifecycle {
        ignore_changes = ["cpu_share_level", "extra_config", "ept_rvi_mode", "hv_mode"]
    }
}

data "template_file" "sad_cloudinit_metadata" {
    template = "${file("${path.module}/cloudinit_metadata.tpl")}"

    vars {
        instance_id = "${var.sad_name}"
        dns_nameservers = "${join(" ", var.vsphere_dns_servers)}"
        dns_search = "${var.machine_domain}"
    }
}

data "template_file" "sad_cloudinit_userdata" {
    template = "${file("${path.module}/cloudinit_userdata_sad_lab90.tpl")}"
    vars = {
        apt_server = "${var.apt_server}"
        bbsadmin_authorized_key = "${file("${var.bbsadmin_ssh_authorized_key_path}")}"
        encoded_fluentbit_env = "${base64encode(file("${path.module}/fluent-bit.sad.env"))}"
        encoded_fluentbit_yaml = "${base64encode(file("${path.module}/fluent-bit.sad.yaml"))}"
        encoded_fluentbit_cert = "${base64encode(file("${var.fluent_bit_cert_path}"))}"
        encoded_fluentbit_key = "${base64encode(file("${var.fluent_bit_key_path}"))}"
        encoded_fluentbit_include = "${var.fluent_bit_custom_include == "true" ? base64encode(file("${var.fluent_bit_custom_include_path}")) : var.fluent_bit_syslog_to_kafka == "true" ? base64encode(file("${path.module}/fluent-bit-include.syslog.yaml")) : base64encode(file("${path.module}/fluent-bit-include.null.yaml"))}"
        machine_domain = "${var.machine_domain}"
        machine_name = "${var.sad_name}"
        product_name = "${var.product_name}"
        ssh_authorized_key = "${file("/opt/uemcloud/.ssh/id_rsa.pub")}"
        ssh_users = "${base64encode("uemcloud\nbbsadmin")}"  # uemcloud and bbsadmin
        ssh_groups = "${base64encode(join("\n", var.ssh_allowed_groups))}"
        sudo_rules = "${base64encode("uemcloud ALL=(ALL) NOPASSWD:ALL\nbbsadmin ALL=(ALL) NOPASSWD:ALL\n${join("\n", formatlist("%%%s ALL=(ALL) ALL", var.ssh_allowed_groups))}")}"
        user_lock_passwd = "${var.env_type_sad == "lab" ? false : true}"
        user_passwd = "${var.env_type_sad == "lab" ? var.sad_password : ""}"
    }
}

data "template_file" "cloudinit_userdata_zabbix_psk" {
    template = "${var.zabbix_psk == "" ? "" : file("${path.module}/cloudinit_userdata_zabbix_psk.tpl")}"
    vars = {
        zabbix_psk = "${base64encode(var.zabbix_psk)}"
        zabbix_psk_identity = "${var.zabbix_psk_identity}"
        zabbix_psk_ar_script = "${base64encode(file("${path.module}/zabbix_psk_ar.sh"))}"
    }
}

data "template_file" "cloudinit_userdata_hold_packages" {
    template = "${var.hold_packages == "" ? "" : file("${path.module}/cloudinit_userdata_hold_packages.tpl")}"
    vars = {
        hold_packages = "${var.hold_packages}"
    }
}

resource "dns_a_record_set" "sad" {
    zone = "${var.dns_internal_zone}."
    # use replace to allow names not directly under the dns_internal_zone, and ensure it doesn't end with a dot
    # e.g. if machine_domain is bemscloud.sw.rim.net and dns_internal_zone is sw.rim.net
    name = "${replace("${var.sad_name}.${replace(var.machine_domain,var.dns_internal_zone,"")}", "/\\.$/","")}"
    addresses = ["${vsphere_virtual_machine.sad.*.default_ip_address}"]
    ttl = 61
}

output "dest_slaveadmin_ip" {
    value = "${join("", vsphere_virtual_machine.sad.*.default_ip_address)}"
}
