#!/usr/bin/env bash
set -o errexit
source govc_env.sh

if [ -n "`govc vm.info -vm.ipath="/$GOVC_DATACENTER/$GOVC_FOLDER/$GOVC_SAD_NAME" | grep 'Power state:' | grep 'poweredOff'`" ]; then
    echo "$GOVC_SAD_NAME is already powered off"
else
    echo "Shutting down $GOVC_SAD_NAME"
    govc_retry vm.power -s -vm.ipath="/$GOVC_DATACENTER/$GOVC_FOLDER/$GOVC_SAD_NAME"

    echo "Waiting for $GOVC_SAD_NAME to power off..."
    while ! govc vm.info -vm.ipath="/$GOVC_DATACENTER/$GOVC_FOLDER/$GOVC_SAD_NAME" | grep 'Power state:' | grep 'poweredOff'; do
        sleep 2
    done
fi
