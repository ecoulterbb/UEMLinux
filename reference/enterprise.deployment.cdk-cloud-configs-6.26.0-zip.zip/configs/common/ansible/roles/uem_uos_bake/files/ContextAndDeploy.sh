#!/usr/bin/env bash

function exit_script
{
    if [ $1 -ne 0 ]; then
        echo "Script ContextAndDeploy.sh failed."
    else
        echo "Script ContextAndDeploy.sh completed."
    fi
    exit $1
}

exec >  >(tee -ia /opt/uemcloud/context.log)
exec 2> >(tee -ia /opt/uemcloud/context.log >&2)

echo "Running ContextAndDeploy.sh."

# increase the max number of open files to 64k (EMM-71667)
ulimit -n 65535

# increase the max core size (EMM-145283)
ulimit -c unlimited

echo "`date`: deployment start"

cd /opt/uemcloud

ROOTDIR=CoreUILinux
echo "Using package: $ROOTDIR"

#
# injecting contextual properties
#
fromFile=/opt/uemcloud/machine.properties
# there should be only one directory in tarball/
toFileRoot=`stat -c "%n" $ROOTDIR*`
# Copy context.properties over to machine.properties
cp $fromFile $toFileRoot/context/machine.properties

if [ ! -d "$ROOTDIR" ]; then
    ln -s $ROOTDIR* $ROOTDIR
fi
chown -R uemcloud:uemcloud $ROOTDIR*
cd $ROOTDIR

./context/context.sh
rc=$?
if [ $rc -ne 0 ]
then
    echo "Contextualization failed ($rc)"
    exit_script $rc
fi

su -c './context/start.sh' uemcloud
rc=$?
if [ $rc -ne 0 ]
then
    echo "Starting services failed ($rc)"
    exit_script $rc
fi

# restart jmxcollector
systemctl restart jmxcollector-uemcloud-core
systemctl restart jmxcollector-uemcloud-ui

exit_script 0
