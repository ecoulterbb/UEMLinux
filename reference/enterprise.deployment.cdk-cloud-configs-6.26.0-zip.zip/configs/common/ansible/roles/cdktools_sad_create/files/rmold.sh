#!/usr/bin/env bash

# Will delete files from FILEPATH until disk usage is under TARGET_PERCENT usage

if [ "$#" -ne 2 ]
then
	echo "Invalid number of parameters -- exactly two parameters expected:"
	echo ""
	echo "    $0 TARGET_PERCENT PATH"
	echo ""
	echo "Will delete files from FILEPATH until disk usage is under TARGET_PERCENT usage"
	echo "EG: $0 95 /persistent/logs"
	exit 1
fi

# Path to delete files from
FILEPATH=$2

if [ ! -d ${FILEPATH} ];
then
    echo "ERROR: ${FILEPATH} is not a valid path -- exiting"
    exit 1
fi

# Target disk space usage
TARGET=$1

if [[ ${TARGET} -lt 1 || ${TARGET} -gt 99 ]]
then
    echo "ERROR: TARGET_PERCENT (${TARGET}) must be between 1-99 -- exiting"
    exit 1
fi

echo -n "Generating ordered list of files: "
# changed to use cut instead of awk, so we can have the 2nd field and everything after that, to allow for directories with spaces in the name
OLDESTFILELIST=$(find ${FILEPATH} -type f -printf '%T+ %p\n' | sort | cut -d " " -f 2- | head -n 1000)
echo "Done!"

#change internal field separator to be a carriage return, or the next bit has issues with spaces in dir names.
IFS=$'\n'

COUNTER=0
DISKFULL=$(df ${FILEPATH} | tail -1 | awk '{print $5}'| cut -d "%" -f1 -)
for OLDESTFILE in ${OLDESTFILELIST}; do
    DISKFULL=$(df ${FILEPATH} | tail -1 | awk '{print $5}'| cut -d "%" -f1 -)
    echo -ne "${DISKFULL}% Used: "
    if [ ${DISKFULL} -lt ${TARGET} ]
    then
        logger -p daemon.notice "Deleted ${COUNTER} files -- Disk usage is at ${DISKFULL}%, under ${TARGET}% -- complete"
        echo "Deleted ${COUNTER} files -- Disk usage is at ${DISKFULL}%, under ${TARGET}% -- complete"
        break
    fi

    echo "Deleting [${OLDESTFILE}]"
    rm -f ${OLDESTFILE}
    COUNTER=$(expr ${COUNTER} + 1)
    # small sleep to keep disk IO down
    sleep 0.01
done

if [ ${DISKFULL} -ge ${TARGET} ] ; then
    logger -p daemon.notice "WARNING: usage is above ${TARGET}%, but no more files are left in the list to delete -- I may need to be run again."
    echo "WARNING: usage is above ${TARGET}%, but no more files are left in the list to delete -- I may need to be run again."
fi

# find and delete empty directories
while $(test $(find ${FILEPATH} -type d -empty | wc -l) -gt 1) ; do find ${FILEPATH} -type d -empty -exec rmdir {} \; 2>/dev/null ; done
