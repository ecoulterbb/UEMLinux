#!/bin/bash

# generate random string
RS=$(dd if=/dev/urandom bs=64 count=1 2>/dev/null | base64 -w0)
# log random string
logger $RS

# check if it shows up
sleep 5
grep $RS /var/log/syslog
if [ $? -eq 0 ]
then
  exit 0
else
  systemctl restart rsyslog
fi
