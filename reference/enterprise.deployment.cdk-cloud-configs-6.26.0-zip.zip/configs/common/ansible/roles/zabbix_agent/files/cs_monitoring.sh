DATA_DIR=/opt/uemcloud/.cs_monitoring

ls $DATA_DIR/*key_id.txt >/dev/null
if [[ $? -eq 2 ]]
then
  exit 1
fi

if [[ $1 == "raw" ]]
then
  for i in $(ls $DATA_DIR/*key_id.txt | sed -e 's/\.key_id\.txt$//')
  do
    echo -n "$(basename $i):$(cat $i.key_id.txt);$(cat $i.end_date.txt)//"
  done | sed -e 's|//$||'
elif [[ $1 == "end_date_ttl" ]]
then
  EXPIRY_DATE=$( date +%s -d $(cat $DATA_DIR/*.end_date.txt | sort | head -1) 2>/dev/null )
  if [[ $? -eq 1 ]]
  then
    exit 1
  fi
  NOW=$( date +%s )
  echo $(( EXPIRY_DATE - NOW ))
elif [[ $1 == "key_id" ]]
then
  cat $DATA_DIR/*.key_id.txt | sort | uniq | tr '\n' ',' | sed -e 's/,$//'
fi
