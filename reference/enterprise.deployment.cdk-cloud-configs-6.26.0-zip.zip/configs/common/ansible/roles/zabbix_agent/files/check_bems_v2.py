#!/usr/bin/python

import os,urllib.request,urllib.error,urllib.parse,json,time,traceback,sys,platform,base64,ssl

PERSIST_PATH="/opt/uemcloud/check_bems_v2.json"

thisData={}
previousData={}
stats={}
elapsed=0
bemsLog=""
hostname=platform.node()
bootTime=None


def get_bems_mail_tenant_checks():

    stats = {}
    bems_mail_tenant_checks = {"TenantsCount":1,"TenantsWithConnectedUsersCount":1,"TenantsWithEWSCount":1}

    for checks in bems_mail_tenant_checks:
        request = urllib.request.Request("https://localhost:8443/monitor/mail.tenants/%s" % checks)
        auth = base64.b64encode('monadmin:monPassw0rd'.encode('ascii')).decode("ascii")
        request.add_header("Authorization", "Basic %s" % auth)
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        result = urllib.request.urlopen(request, context=ctx)
        response = json.load(result)

        for key, value in list(response.items()):
            bems_mail_tenant_checks[key] = value

    for key, value in list(bems_mail_tenant_checks.items()):
        status = value
        description = "BEMS_MAILTENANT_" + key
        print("=".join([str(x) for x in [description, status]]))

def get_bems_mail_sync_checks():

    stats = {}
    bems_mail_sync_checks = {"syncSuccesses":0,"vipAlertsGenerated":0,"processInboxInProgress":0,"standardPushesGenerated":0,"getAndRefreshSubFolderEwsIdSettingsInProgress":0,"processSubfolderInProgress":0,"richPushesGenerated":0,"subFolderPushesGenerated":0,"getWellKnownFoldersInProgress":0,"syncErrors":0,"notificationsBeingProcessed":0}

    for checks in bems_mail_sync_checks:
        request = urllib.request.Request("https://localhost:8443/monitor/mail.sync/%s" % checks)
        auth = base64.b64encode('monadmin:monPassw0rd'.encode('ascii')).decode("ascii")
        request.add_header("Authorization", "Basic %s" % auth)
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        result = urllib.request.urlopen(request, context=ctx)
        response = json.load(result)

        for key, value in list(response.items()):
            bems_mail_sync_checks[key] = value

    for key, value in list(bems_mail_sync_checks.items()):
        status = value
        description = "BEMS_MAILSYNC_" + key
        print("=".join([str(x) for x in [description, status]]))

def get_bems_ewslistener_checks():

    stats = {}
    request = urllib.request.Request("https://localhost:8443/monitor/mail.ewslistener")
    auth = base64.b64encode('monadmin:monPassw0rd'.encode('ascii')).decode("ascii")
    request.add_header("Authorization", "Basic %s" % auth)
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    result = urllib.request.urlopen(request, context=ctx)
    response = json.load(result)
    bems_ewslistener_checks_results = {}

    for endpoint in ['EWSUserStats']:
        bems_ewslistener_checks_results[endpoint] = {}
        for check in ["EWSConnectedUserCount"]:
            bems_ewslistener_checks_results[endpoint][check] = response['metrics'][endpoint][check]

    for endpoint in ['EWSUserStats']:
        for key,value in list(bems_ewslistener_checks_results[endpoint].items()):
            status = value
            description = "BEMS_EWSLISTENER_" + key
            print("=".join([str(x) for x in [description, status]]))

def get_bems_ewslistener2_checks():

    stats = {}
    request = urllib.request.Request("https://localhost:8443/monitor/mail.ewslistener")
    auth = base64.b64encode('monadmin:monPassw0rd'.encode('ascii')).decode("ascii")
    request.add_header("Authorization", "Basic %s" % auth)
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    result = urllib.request.urlopen(request, context=ctx)
    response = json.load(result)
    bems_ewslistener2_checks_results = {}

    for endpoint in ['EWSListenerStats']:
        bems_ewslistener2_checks_results[endpoint] = {}
        for check in ["pendingSubscriptionRequests","notificationsReceived","notificationsDropped","streamingConnectionsTotal","streamingConnectionsOpen","streamingConnectionsClosed","messageQueueSize"]:
            bems_ewslistener2_checks_results[endpoint][check] = response['metrics'][endpoint][check]

    for endpoint in ['EWSListenerStats']:
        for key,value in list(bems_ewslistener2_checks_results[endpoint].items()):
            status = value
            description = "BEMS_EWSLISTENER_" + key
            print("=".join([str(x) for x in [description, status]]))

def get_bems_systembugs_check():

    stats = {}
    bems_systembugs_check = {"BugCount":1}

    for checks in bems_systembugs_check:
        request = urllib.request.Request("https://localhost:8443/monitor/system.bugs/%s" % checks)
        auth = base64.b64encode('monadmin:monPassw0rd'.encode('ascii')).decode("ascii")
        request.add_header("Authorization", "Basic %s" % auth)
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        result = urllib.request.urlopen(request, context=ctx)
        response = json.load(result)

        for key, value in list(response.items()):
            bems_systembugs_check[key] = value

    for key, value in list(bems_systembugs_check.items()):
        status = value
        description = "BEMS_SYSTEMBUGS_" + key
        print("=".join([str(x) for x in [description, status]]))

def get_bems_users_check():

    stats = {}
    bems_users_check = {"StaleUsersCount":1,"QuarantinedUsersCount":1,"NewUsersCount":1,"UsersCount":1,"UnknownUsersCount":1}

    for checks in bems_users_check:
        request = urllib.request.Request("https://localhost:8443/monitor/mail.users/%s" % checks)
        auth = base64.b64encode('monadmin:monPassw0rd'.encode('ascii')).decode("ascii")
        request.add_header("Authorization", "Basic %s" % auth)
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        result = urllib.request.urlopen(request, context=ctx)
        response = json.load(result)

        for key, value in list(response.items()):
            bems_users_check[key] = value

    for key, value in list(bems_users_check.items()):
        status = value
        description = "BEMS_USERS_" + key
        print("=".join([str(x) for x in [description, status]]))

def get_bems_users_check2():

    stats = {}
    bems_users_check2 = {"ErrorUsersCount":1}

    for checks in bems_users_check2:
        request = urllib.request.Request("https://localhost:8443/monitor/mail.users/ErrorUsersCount/%s" % checks)
        auth = base64.b64encode('monadmin:monPassw0rd'.encode('ascii')).decode("ascii")
        request.add_header("Authorization", "Basic %s" % auth)
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        result = urllib.request.urlopen(request, context=ctx)
        response = json.load(result)

        for key, value in list(response.items()):
            bems_users_check2[key] = value

    for key, value in list(bems_users_check2.items()):
        status = value
        description = "BEMS_USERS_" + key
        print("=".join([str(x) for x in [description, status]]))

def get_bems_push_notifications_checks():

    stats = {}
    #bems_push_notificatons_apns_checks = ["successfulPushes","failedPushes"]
    request = urllib.request.Request("https://localhost:8443/monitor/push.notifications")
    auth = base64.b64encode('monadmin:monPassw0rd'.encode('ascii')).decode("ascii")
    request.add_header("Authorization", "Basic %s" % auth)
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    result = urllib.request.urlopen(request, context=ctx)
    response = json.load(result)
    bems_push_notifications_checks_results = {}

    for endpoint in ['APNS', 'gcm', 'GNP']:
        bems_push_notifications_checks_results[endpoint] = {}
        for check in ["successfulPushes","failedPushes"]:
            bems_push_notifications_checks_results[endpoint][check] = response['metrics'][endpoint][check]

    for endpoint in ['APNS', 'gcm', 'GNP']:
        for key,value in list(bems_push_notifications_checks_results[endpoint].items()):
            status = value
            description = "BEMS_PUSH_" + endpoint + "_" + key
            print("=".join([str(x) for x in [description, status]]))

def get_bems_producer_check():

    producer = 0
    workers = 0
    workers_in_good_state = 0
    request = urllib.request.Request("https://localhost:8443/monitor/mail.ha")
    auth = base64.b64encode('monadmin:monPassw0rd'.encode('ascii')).decode("ascii")
    request.add_header("Authorization", "Basic %s" % auth)
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    result = urllib.request.urlopen(request, context=ctx)
    response = json.load(result)
    if response['metrics']['Producer'] != None:
        producer = 1
        for value in response['metrics']['Producer']['workerStatus']:
            workers+=1
            if value['status'] == 'GOOD':
                workers_in_good_state+=1
    print("BEMS_MAILHA_IsProducer=" + str(producer))
    print("BEMS_MAILHA_WorkerCount=" + str(workers))
    print("BEMS_MAILHA_WorkerGoodState=" + str(workers_in_good_state))

def debug(t):
    if "--verbose" in sys.argv:
        for line in t.splitlines():
            print("# "+line.rstrip())

def setStatAndRate(name,prevValue,thisValue):
    global stats,elapsed
    stats[name]=thisValue
    stats["rate_"+name]=(thisValue-prevValue)/elapsed
    
def printResult(description,count,rateInOk,rateInFail,rateOutOk,rateOutFail):
    global  stats,hostname,bootTime

    count=stats.get(count,0)
    rateInOk=stats.get(rateInOk,0)
    rateInFail=stats.get(rateInFail,0)
    rateOutOk=stats.get(rateOutOk,0)
    rateOutFail=stats.get(rateOutFail,0)
    
    r=0
    status="%d"%(count)
    if not bootTime:
        r=1
        status="No stats available"
    
    perfdata=""
    perfdata+="count=%d;;; "%(count)
    perfdata+="rateInOk=%.4f/s;;; "%(rateInOk)
    perfdata+="rateInFail=%.4f/s;;; "%(rateInFail)
    perfdata+="rateOutOk=%.4f/s;;; "%(rateOutOk)
    perfdata+="rateOutFail=%.4f/s;;; "%(rateOutFail)

    perfdata+="reserved6=0;;; "
    perfdata+="reserved7=0;;; "
    perfdata+="reserved8=0;;; "
    perfdata+="reserved9=0;;; "
    
    debug(" ")
    print("|".join([str(x) for x in [hostname,description,r,status,perfdata]]))

get_bems_mail_tenant_checks()
get_bems_mail_sync_checks()
get_bems_ewslistener_checks()
get_bems_ewslistener2_checks()
get_bems_systembugs_check()
get_bems_users_check()
get_bems_users_check2()
get_bems_push_notifications_checks()
get_bems_producer_check()
