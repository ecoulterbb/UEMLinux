#!/bin/bash

URL="http://127.0.0.1:7999/backendstatus?format=json"
WGET_BIN="/usr/bin/wget"
NGINX_STATS=$($WGET_BIN -q "$URL" -O - 2>&1)

if [ $? -ne 0 -o -z "$NGINX_STATS" ]; then
  echo $ERROR_DATA
  exit 1
fi

if [ "$#" -eq 0 ]; then

  NGINX_POOLS=`echo "$NGINX_STATS" | jq -r 'keys[]'`

  size=0
  count=0
  for i in $NGINX_POOLS; do size=$((size+1)); done

  echo "{"
  echo "\"data\":["
  for i in $NGINX_POOLS;
  do
    count=$((count+1))
    if [ $count == $size ]
    then
      echo "{ \"{#POOLNAME}\":\"$i\"  }"
    else
      echo "{ \"{#POOLNAME}\":\"$i\"  },"
    fi
  done
  echo "]"
  echo "}"
fi

if [ "$#" -eq 2 ]; then

  if [ "$2" == "down" ]; then
    NGINX_POOLS=`echo "$NGINX_STATS" | jq "[.$1[] | select(.status ==\"down\")] | length"`
    echo "$NGINX_POOLS"
  fi
  if [ "$2" == "up" ]; then
    NGINX_POOLS=`echo "$NGINX_STATS" | jq "[.$1[] | select(.status ==\"up\")] | length"`
    echo "$NGINX_POOLS"
  fi
  if [ "$2" == "total" ]; then
    NGINX_POOLS=`echo "$NGINX_STATS" | jq ".$1 | length"`
    echo "$NGINX_POOLS"
  fi
fi
