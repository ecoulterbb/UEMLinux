#!/bin/bash -x

# gather a bunch of data for SDS for analysis - BBNOSSE-89970

umask 022

PREFIX="$(hostname -f)_$(date +%Y%m%d_%H%M%S)"

[ "${1}" ] && TICKET="${1}" || TICKET="BBNOSSE-89970"

mkdir -v -p  /mnt/tmp/${TICKET}
chmod 1777 /mnt/tmp

# get output of top
echo top
top -H -b -d 2 -n 5 -c -w 512 | tee -a /mnt/tmp/${TICKET}/${PREFIX}_top.txt > /dev/null 2>/dev/null &

# get iotop for 30 seconds
echo iotop
iotop -b -n 6 -o -d 5 | tee -a /mnt/tmp/${TICKET}/${PREFIX}_iotop.txt > /dev/null 2>/dev/null &

# get output of lsof
echo lsof
lsof -s | tee -a /mnt/tmp/${TICKET}/${PREFIX}_lsof.txt > /dev/null 2>/dev/null &

# wait for captures to be done
echo "waiting..."
wait < <(jobs -p)

# zip
pushd /mnt/tmp/${TICKET}
if [ -n "$(which zip 2>/dev/null)" ] ; then
    echo zip
    zip -m /mnt/tmp/${TICKET}/${PREFIX}_meminfo.zip $(ls -1 ${PREFIX}*.txt)
else
    tar --remove-files --directory=/mnt/tmp/${TICKET}/ -zcvf /mnt/tmp/${TICKET}/${PREFIX}_meminfo.tgz $(ls -1 ${PREFIX}*.txt)
fi
popd

echo "fixing permissions"
chmod a+r /mnt/tmp/${TICKET}/${PREFIX}*
chown -R uemcloud:uemcloud /mnt/tmp/${TICKET}/

# when the collector runs on the mad, it does that out of cron every 15 minutes, so this is just a fallback to make sure the disk does not get full
echo "cleaning up files older than 4 hours"
find /mnt/tmp/${TICKET}/ -type f -mmin +240 -exec rm -vf {} \;
