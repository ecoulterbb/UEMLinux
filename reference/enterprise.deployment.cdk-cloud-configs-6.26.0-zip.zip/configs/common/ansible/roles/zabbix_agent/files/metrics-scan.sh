#!/bin/bash

umask 0022

timeout 10s python3 /opt/uemcloud/check_bems_v2.py > /opt/uemcloud/metrics
if [[ $? -ne 0 ]] ; then
    exit 0
else
    sync
    sleep 2

    refreshhashcount=0
    refresh=$(curl http://localhost:9999/metrics 2>/dev/null | egrep '^log_metric_counter_refresh_hash_count')
    if [[ $? -eq 0 ]] ; then
        refreshhashcount=$(echo ${refresh} | awk '{print $2}')
    fi
    echo "BEMS_LOG_refreshhashcount=${refreshhashcount}" >> /opt/uemcloud/metrics

    echo "BEMS_HTTPMETRICS_lastupdated=$(date +%s)" >> /opt/uemcloud/metrics
    cp -f /opt/uemcloud/metrics /opt/uemcloud/metrics.txt
    chmod 644 /opt/uemcloud/metrics.txt
    awk -F'=' '{metric=tolower($1); gsub(/_/,"_",metric); print metric" "$2}' /opt/uemcloud/metrics > /var/lib/prometheus/node-exporter/bems_metrics.prom
fi
