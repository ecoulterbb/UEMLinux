import xml.etree.ElementTree as ET
import os
import re

tree = ET.parse('/opt/uemcloud/post_build/manifest.xml')

print ("Bundle:", tree.findall("./info/productShortName")[0].text, tree.findall("./info/productVersion")[0].text)
cdk = []
for file in os.listdir('/opt/uemcloud/artifacts'):
  m = re.match("cdk-tools-([0-9.]*)-.*\.jar",file)
  if m:
    for a in m.groups():
      cdk.append(a)
print ("CDK:", cdk)

comps = []
for comp in tree.findall("./components/component"):
  names = []
  for name in comp.findall("./componentName"):
    names.append(name.text)
  vers = []
  for version in comp.findall("./version"):
    vers.append(version.text)
  comps.append( (names, vers) )
print ("Components:", comps)

