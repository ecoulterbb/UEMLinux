#!/bin/bash 

# The majority of this scrpt uses source or mddified source from ssl-cert-check
# ssl-cert-checks ource: http://prefetch.net/code/ssl-cert-check

#-------------------------------------------#
# Slurp Variables
#-------------------------------------------#

if [ -f /opt/context/context.sh ]; then
          . /opt/context/context.sh
elif [ -f ./context.sh ]; then
          . context.sh
fi

#-------------------------------------------#
# VARIABLES FROM CONTEXT.SH SLURP
#-------------------------------------------#

# HOSTNAME = vm hostname (short) from context

if [ -z "${HOSTNAME}" ]
	then
		echo "HOSTNAME Variable Is Not Set"
		exit 1;
fi

#-------------------------------------------#
# read config file based on ${HOSTNAME}
#-------------------------------------------#

SCRIPT="$(basename $0)"
DIR="$(dirname $0)"
SCRIPTBASE="${SCRIPT%.*}"
CONFIGFILE="${DIR}/${SCRIPTBASE}_${HOSTNAME}.cfg"

# allow override of config file from command line
if [ -n "${1}" ] ; then
	CONFIGFILE="${1}"
fi

if [ -f ${CONFIGFILE} ]; then
        . ${CONFIGFILE}
else
    echo "Unable to find config file: ${CONFIGFILE}"
    exit 2;
fi

#-------------------------------------------#
# Additional Variables
#-------------------------------------------#

DELAY="5" #time between checks

#-------------------------------------------#
# Purpose: Convert a date from MONTH-DAY-YEAR to Julian format
# Acknowledgements: Code was adapted from examples in the book
#                         "Shell Scripting Recipes: A Problem-Solution Approach"
#                         ( ISBN 1590594711 )
# Arguments:
#    $1 -> Month (e.g., 06)
#    $2 -> Day    (e.g., 08)
#    $3 -> Year  (e.g., 2006)
#-------------------------------------------#

date2julian() {

     if [ "${1}" != "" ] && [ "${2}" != ""  ] && [ "${3}" != "" ]
     then
          ## Since leap years add aday at the end of February, 
          ## calculations are done from 1 March 0000 (a fictional year)
          d2j_tmpmonth=$((12 * ${3} + ${1} - 3))
          
          ## If it is not yet March, the year is changed to the previous year
          d2j_tmpyear=$(( ${d2j_tmpmonth} / 12))
          
          ## The number of days from 1 March 0000 is calculated
          ## and the number of days from 1 Jan. 4713BC is added 
          echo $(( (734 * ${d2j_tmpmonth} + 15) / 24
                      - 2 * ${d2j_tmpyear} + ${d2j_tmpyear}/4 
                      - ${d2j_tmpyear}/100 + ${d2j_tmpyear}/400 + $2 + 1721119 ))
     else
          echo 0
     fi
}

#-------------------------------------------#
# Purpose: Convert a string month into an integer representation
# Arguments:
#    $1 -> Month name (e.g., Sep)
#-------------------------------------------#

getmonth() 
{
     case ${1} in
          Jan) echo 1 ;;
          Feb) echo 2 ;;
          Mar) echo 3 ;;
          Apr) echo 4 ;;
          May) echo 5 ;;
          Jun) echo 6 ;;
          Jul) echo 7 ;;
          Aug) echo 8 ;;
          Sep) echo 9 ;;
          Oct) echo 10 ;;
          Nov) echo 11 ;;
          Dec) echo 12 ;;
            *) echo  0 ;;
     esac
}

#-------------------------------------------#
# Purpose: Calculate the number of seconds between two dates
# Arguments:
#    $1 -> Date #1
#    $2 -> Date #2
#-------------------------------------------#

date_diff() 
{
     if [ "${1}" != "" ] &&  [ "${2}" != "" ]
     then
          echo $((${2} - ${1}))
     else
          echo 0
     fi
}

#-------------------------------------------#
# Do Stuff
#-------------------------------------------#

#while true ; do

    TIMESTART="$(date +%s)"
    
    for THIS_NUM in $(seq 0 $(( ${#SERVICE_NAME[@]} - 1 ))  ) ; do
    
        THIS_NAME="${SERVICE_NAME[${THIS_NUM}]}"
        THIS_HOST="${SERVICE_HOST[${THIS_NUM}]}"
        THIS_PORT="${SERVICE_PORT[${THIS_NUM}]}"
    
        MONTH=$(date "+%m")
        DAY=$(date "+%d")
        YEAR=$(date "+%Y")
        NOWJULIAN=$(date2julian ${MONTH#0} ${DAY#0} ${YEAR})
        WARNDAYS=60
        CERTDATE=$(echo | timeout 5s openssl s_client -CApath /etc/ssl/certs/ -connect ${THIS_HOST}:${THIS_PORT} 2>/dev/null | openssl x509 -noout -enddate | sed 's/notAfter\=//')
        set -- ${CERTDATE}
        MONTH=$(getmonth ${1})
    
        # Convert the date to seconds, and get the diff between NOW and the expiration date
        CERTJULIAN=$(date2julian ${MONTH#0} ${2#0} ${4})
        CERTDIFF=$(date_diff ${NOWJULIAN} ${CERTJULIAN})
        
#        echo "<metric type=\"IntCounter\" name=\"cloudbes|${THIS_NAME}|ServiceChecks:ssl certificate days until expired - ${THIS_HOST} port ${THIS_PORT}\" value=\"${CERTDIFF}\" />"
        echo "${THIS_NAME}_CertificateDaysUntilExpired=${CERTDIFF}"

    done

#-------------------------------------------#

    TIMEEND="$(date +%s)"
    TIMEDIFF="$(( ${TIMEEND} - ${TIMESTART} ))"
    TIMEDIFF="$(( ${DELAY} - ${TIMEDIFF} ))"

#    sleep ${TIMEDIFF}

#-------------------------------------------#

#done
