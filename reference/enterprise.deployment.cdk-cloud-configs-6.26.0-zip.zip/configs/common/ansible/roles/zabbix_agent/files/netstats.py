#!/usr/bin/env python
# vim: tabstop=8 expandtab shiftwidth=4 softtabstop=4
#
# netstats.py
# Copyright (C) 2014 BlackBerry, Inc.
# Author: Andrew Brown
# Version: 2.0
#
# This is a Wily EPAgent script that reports network statistics
#
# Version 2.0 to reflect this is taken from Andrew Brown's 'snmp/netstat' script, but re-using for grabbing values from the netstat. - Gary Ryan


import time
import sys
import re
import os


packet_loss_regex="IpExtInMcastPkts|IpExtOutMcastPkts|IpExtInBcastPkts|IpExtOutBcastPkts|IpExtInOctets|IpExtOutOctets|IpExtInMcastOctets|IpExtOutMcastOctets|IpExtInBcastOctets|IpExtOutBcastOctets"

def debug (text):
    if "--verbose" in sys.argv:
        print "# "+str(text)

def printstats(newdict, regex=None):
    f1 = open('/etc/zabbix/netstats.txt', 'w+')
    os.chmod('/etc/zabbix/netstats.txt', 0644)
    for key in newdict:
        if regex == None or re.search(regex, key):
            print >> f1, ('{0}={1}'.format(key, newdict[key]))


def getstat(f):
    var1 = f.readline().split(':')[1].split()
    var2 = f.readline().split(':')[1].split()
    debug(repr((var1, var2)))
    debug(len(var1))
    debug(len(var2))
    return var1, var2


def getstats (f):
    valuesdict = {}
    for s in ('TcpExt', 'IpExt'):
        keyslist, valuelist = getstat(f)
        for n in range(len(keyslist)):
            k = keyslist[n]
            v = valuelist[n]
            valuesdict[s+k]=int(v)

    debug(repr(valuesdict))
    return valuesdict


def do_stats (f, new):
    new = getstats(f)
    if len(new) > 0:
        printstats (new, packet_loss_regex)
    return (new)

def main():
    stats_new = {}
    f = open('/proc/net/netstat', 'r')
    values = {}
    do_stats(f, stats_new)


    sys.stdout.flush();


if __name__ == "__main__":
    main()
