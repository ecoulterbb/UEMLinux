#!/usr/bin/env python
# vim: tabstop=8 expandtab shiftwidth=4 softtabstop=4
#
# netstats.py
# Copyright (C) 2014 BlackBerry, Inc.
# Author: Andrew Brown
# Version: 1.2
#
# This is a Wily EPAgent script that reports network statistics
#
# Added additional metrics to grab from /proc/net/snmp and renamed this to 'snmp.py' to represent that we're grabbing it from that file. - Gary Ryan
# Had to add an if statement, not all VMs seem to have 'IcmpMsg' in the snmp file, so to ensure it continues to work if statement handles either or. - Gary Ryan

import time
import sys
import re
import os


packet_loss_regex="IpInReceives|IpInHdrErrors|IpInAddrErrors|IpInUnknownProtos|IpInDiscards|IpInDelivers|IpOutRequests|IpOutDiscards|IpOutNoRoutes|IcmpInErrors|IcmpInMsgs|IcmpOutMsgs|IcmpOutErrors|TcpInSegs|TcpOutSegs|TcpRetransSegs|UdpInDatagrams|UdpNoPorts|UdpInErrors|UdpOutDatagrams"


def debug (text):
    if "--verbose" in sys.argv:
        print "# "+str(text)


def printstats(newdict, regex=None):
    f1 = open('/etc/zabbix/snmp.txt', 'w+')
    os.chmod('/etc/zabbix/snmp.txt', 0644)
    for key in newdict:
        if regex == None or re.search(regex, key):
            print >> f1, ('{0}={1}'.format(key, newdict[key]))


def getstat(f):
    var1 = f.readline().split(':')[1].split()
    var2 = f.readline().split(':')[1].split()
    debug(repr((var1, var2)))
    debug(len(var1))
    debug(len(var2))
    return var1, var2


def getstats (f):
    valuesdict = {}

    if 'IcmpMsg' in open('/proc/net/snmp').read():

        for s in ('Ip', 'Icmp', 'IcmpMsg', 'Tcp', 'Udp', 'UdpLite'):
            keyslist, valuelist = getstat(f)
            for n in range(len(keyslist)):
                k = keyslist[n]
                v = valuelist[n]
                valuesdict[s+k]=int(v)

        debug(repr(valuesdict))
        return valuesdict
    else:
        for s in ('Ip', 'Icmp', 'Tcp', 'Udp', 'UdpLite'):
            keyslist, valuelist = getstat(f)
            for n in range(len(keyslist)):
                k = keyslist[n]
                v = valuelist[n]
                valuesdict[s+k]=int(v)

        debug(repr(valuesdict))
        return valuesdict


def do_stats (f, new):
    new = getstats(f)
    if len(new) > 0:
        printstats (new, packet_loss_regex)
    return (new)

def main():
    stats_new = {}
    f = open('/proc/net/snmp', 'r')
    values = {}
    do_stats(f, stats_new)


    sys.stdout.flush();


if __name__ == "__main__":
    main()
