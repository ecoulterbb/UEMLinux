#!/bin/bash

TEMPFILE=$(mktemp)
ENDPOINT=$1

[[ $1 == "" ]] && exit 1

echo | openssl s_client -connect $ENDPOINT 2> /dev/null | openssl x509 > $TEMPFILE
if [[ $? -eq 0 ]] ; then
    bash /etc/zabbix/wafl_cert_check.sh $TEMPFILE
fi
rm ${TEMPFILE}
