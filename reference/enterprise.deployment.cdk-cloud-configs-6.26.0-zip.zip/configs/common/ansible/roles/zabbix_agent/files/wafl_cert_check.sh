#!/bin/bash

# read SSL certificate as $CERT_PATH
# returns numbers of days until expiry

DEFAULT_CERT_PATH=/usr/local/openresty/nginx/conf/cert.crt
CERT_PATH="${1:-${DEFAULT_CERT_PATH}}"

if [[ -e $CERT_PATH ]] ; then
    EXPIRY_DATE=$(openssl x509 -in $CERT_PATH -noout -dates 2>/dev/null | grep notAfter)
    if [[ $? -eq 0 ]]; then
        EPOCH_EXPIRY=$(date +%s -d "$(echo $EXPIRY_DATE | cut -d= -f 2-)")
        EPOCH_NOW=$(date +%s)
        DAYS_TO_EXPIRY=$(( ($EPOCH_EXPIRY - $EPOCH_NOW) / 86400 ))
        echo $DAYS_TO_EXPIRY
        exit 0
    fi
fi
exit 1
