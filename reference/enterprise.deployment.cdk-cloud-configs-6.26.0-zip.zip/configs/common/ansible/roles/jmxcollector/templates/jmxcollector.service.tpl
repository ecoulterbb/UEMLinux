[Unit]
Description=jmxcollector for zabbix ({{ item }})
After=network.target auditd.service
StartLimitInterval=200
StartLimitBurst=3

[Service]
EnvironmentFile=/etc/default/jmxcollector-{{ item }}
WorkingDirectory=/opt/jmxcollector
ExecStart=/bin/bash -c "while ! nc -v -z 127.0.0.1 ${JMXPORT} ; do sleep 5 ; done && /usr/bin/java ${JAVA_OPTS} -cp ${CLASSPATH} ${CLASSMAIN} config=${CONFFILE} host=$(hostname -f) >${LOGFILE} 2>&1"
ExecStop=/usr/bin/pkill -HUP -f "${CLASSMAIN} config=${CONFFILE}"
Restart=always
RestartSec=30
User=uemcloud
Group=uemcloud
Requires=jmxcollector-{{ item }}-watchdog.service

[Install]
#WantedBy=multi-user.target
Alias=jmxcollector-{{ item }}.service
