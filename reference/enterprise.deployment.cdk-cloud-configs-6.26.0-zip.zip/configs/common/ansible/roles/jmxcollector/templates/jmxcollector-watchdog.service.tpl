[Unit]
Description=watchdog for jmxcollector {{ item }}
After=network.target auditd.service
StartLimitInterval=200
StartLimitBurst=3

[Service]
EnvironmentFile=/etc/default/jmxcollector-{{ item }}
WorkingDirectory=/opt/jmxcollector
ExecStart=/opt/jmxcollector/jmxcollector-watchdog.sh
Restart=always
RestartSec=30
User=uemcloud
Group=uemcloud

[Install]
Alias=jmxcollector-{{ item }}-watchdog.service
