#!/bin/bash

# wait for jmxcollector service to be available
while ! echo $METRIC | socat - udp:127.0.0.1:$POLLPORT;
do
  echo "jmxcollector service not ready"
  sleep 30
done
echo "jmxcollector service ready"

LAST_VALUE=init
while true
do
  QUERY=$(echo $METRIC | socat - udp:127.0.0.1:$POLLPORT)
  if [[ $? -eq 0 ]]
  then
    echo $QUERY
    if [[ "$LAST_VALUE" == "init" ]]; then
      LAST_VALUE=$QUERY
    else
      if [[ "$LAST_VALUE" == "$QUERY" ]]; then
        echo "Value stalled for $QUERY, restarting ${CONFFILE}"
        /usr/bin/pkill -HUP -f "${CLASSMAIN} config=${CONFFILE}"
      else
        LAST_VALUE=$QUERY
      fi
    fi
    sleep 120
  else
    # query failed
    echo "jmxcollector service not ready"
    sleep 30
    while ! echo $METRIC | socat - udp:127.0.0.1:$POLLPORT;
    do
      echo "jmxcollector service not ready"
      sleep 30
    done
    echo "jmxcollector service ready"
  fi
done
