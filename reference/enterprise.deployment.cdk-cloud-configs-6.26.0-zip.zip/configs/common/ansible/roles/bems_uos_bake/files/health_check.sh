#!/bin/bash

alert_dumps=0

echo '****************************************'
echo '**      BEMS HEALTH CHECK SCRIPT      **'
echo '****************************************'

# karaf process
echo 'Apache Karaf pid:'
jcmd | grep karaf
if [[ $? -ne 0 ]]; then
  echo 'ERROR - BEMS PNS service not running!'
  exit 0
fi
echo '****************************************'


# health check
echo 'HTTP health check (port 8181):'
http_return_code=$(curl -m10 -o /dev/null -w '%{http_code}' http://127.0.0.1:8181/health 2>/dev/null)
rc=$?
if [[ $rc -eq 0 ]] ; then
  if [[ $http_return_code -eq 200 ]] ; then
    echo "OK - health check responsive, returning HTTP ${http_return_code}"
  else
    echo "ERROR - health check responsive, returning HTTP ${http_return_code}"
    alert_dumps=1
  fi
elif [[ $rc -eq 7 ]] ; then
  echo "ERROR - health check port unavailable, check if karaf is running?"
else
  echo "ERROR - health check failing, curl return code $rc, likely timing out"
  alert_dumps=1
fi
echo '****************************************'

# http metric check
echo 'HTTP metric check (port 8443):'
http_return_code=$(curl --tls-max 1.2 -m10 -o /dev/null -w '%{http_code}' -u monadmin:monPassw0rd -k https://localhost:8443/monitor/mail.tenants 2>/dev/null) 
rc=$?
if [[ $rc -eq 0 ]] ; then
  if [[ $http_return_code -eq 200 ]] ; then
    echo "OK - metric check responsive, returning HTTP ${http_return_code}"
  else
    echo "ERROR - metric check responsive, returning HTTP ${http_return_code}"
    alert_dumps=1
  fi
elif [[ $rc -eq 7 ]] ; then
  echo "ERROR - metric check unavailable, check if karaf is running?"
else
  echo "ERROR - metric check failing, curl return code $rc, likely timing out"
  alert_dumps=1
fi
echo '****************************************'

# alert user to dumps needed
if [[ $alert_dumps -eq 1 ]]; then
  echo '**  Thread dumps and heap dumps should be taken!!'
  echo '**  Run (as uemcloud):'
  echo '**  heapdump'
  echo '**  threaddump'
  echo '****************************************'
fi
