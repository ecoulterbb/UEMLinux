#!/usr/bin/env bash

function exit_script
{
    if [ $1 -ne 0 ]; then
        echo "Script ContextAndDeploy.sh failed."
    else
        echo "Script ContextAndDeploy.sh completed."
    fi
    exit $1
}

exec >  >(tee -ia /opt/uemcloud/context.log)
exec 2> >(tee -ia /opt/uemcloud/context.log >&2)

echo "Running ContextAndDeploy.sh."

# increase the max number of open files to 64k (EMM-71667)
ulimit -n 65535

echo "`date`: deployment start"

cd /opt/uemcloud

ROOTDIR=BEMSLinux
echo "Using package: $ROOTDIR"

#
# injecting contextual properties
#
fromFile=/opt/uemcloud/machine.properties
# there should be only one directory in tarball/
toFileRoot=`stat -c "%n" $ROOTDIR`
# Copy context.properties over to machine.properties
cp $fromFile $toFileRoot/context/machine.properties

chown -R uemcloud:uemcloud $ROOTDIR
cd $ROOTDIR
find . -type d -name bin -exec chmod -R +x {} \;

./context/context.sh
rc=$?
if [ $rc -ne 0 ]
then
    echo "Contextualization failed ($rc)"
    exit_script $rc
fi

if [ "x${USE_SYSTEMD}" == "xtrue" ]
then
    sed -i '/# Do not modify anything beyond this point/iexport BES_ROOT=/opt/uemcloud/BEMSLinux' /opt/uemcloud/BEMSLinux/bems/bin/karaf-service
    sed -i '/# Do not modify anything beyond this point/iexport KARAF_HOME=/opt/uemcloud/BEMSLinux/bems' /opt/uemcloud/BEMSLinux/bems/bin/karaf-service
    sed -i '/# Do not modify anything beyond this point/iif [ -e /opt/uemcloud/kvcs.sh ]; then . /opt/uemcloud/kvcs.sh ; fi' /opt/uemcloud/BEMSLinux/bems/bin/karaf-service
    sed -i '/^\[Service\]$/aLimitNOFILE=1048576' /opt/uemcloud/BEMSLinux/bems/bin/karaf.service
    sed -i '/^\[Service\]$/aLimitCORE=0' /opt/uemcloud/BEMSLinux/bems/bin/karaf.service
    sed -i '/^\[Service\]$/aUser=uemcloud' /opt/uemcloud/BEMSLinux/bems/bin/karaf.service
    sed -i '/^\[Unit\]$/aWants=jmxcollector-bemscloud.service' /opt/uemcloud/BEMSLinux/bems/bin/karaf.service
    sed -i '/^\[Unit\]$/aPartOf=karaf.service' /lib/systemd/system/jmxcollector-bemscloud.service

    ln -s /opt/uemcloud/BEMSLinux/bems/bin/karaf.service /lib/systemd/system

    systemctl daemon-reload
    systemctl enable karaf
    systemctl start karaf
else
    if [ -e /opt/uemcloud/kvcs.sh ]
    then
        source /opt/uemcloud/kvcs.sh
    fi

    su -c './context/start.sh' uemcloud
    rc=$?
    if [ $rc -ne 0 ]
    then
        echo "Starting services failed ($rc)"
        exit_script $rc
    fi

    # restart jmxcollector
    systemctl restart jmxcollector-bemscloud
fi

exit_script 0
