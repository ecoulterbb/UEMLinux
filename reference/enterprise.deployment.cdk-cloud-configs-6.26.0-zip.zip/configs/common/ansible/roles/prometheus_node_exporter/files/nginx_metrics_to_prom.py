#!/usr/bin/python3
import json
import os
import requests
import json
import re
import logging
import sys

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def write_prometheus_metrics_to_file(metrics_string, output_dir="/var/lib/prometheus/node-exporter", filename="nginx.prom"):
    """
    Writes the Prometheus metrics string to a file in the specified directory.
    Args:
        metrics_string (str): The metrics in Prometheus exposition format.
        output_dir (str): The directory where the file will be written.
        filename (str): The name of the output file.
    Returns:
        bool: True if successful, False otherwise.
    """
    try:
        # Input validation
        if not metrics_string or not isinstance(metrics_string, str):
            raise ValueError("metrics_string must be a non-empty string")

        # Set umask and create directory
        os.umask(0o022)
        os.makedirs(output_dir, exist_ok=True)

        # Write file
        filepath = os.path.join(output_dir, filename)
        with open(filepath, "w") as f:
            f.write(metrics_string)

        logging.info(f"Prometheus metrics written to: {filepath}")
        return True

    except (PermissionError, OSError, IOError) as e:
        logging.error(f"Failed to write metrics to {output_dir}/{filename}: {e}")
        return False

    except Exception as e:
        logging.error(f"Unexpected error: {e}", exc_info=True)
        return False

def json_to_prometheus_metrics(json_data, prefix="nginx_backendstatus"):
    """
    Converts a dictionary of JSON data into Prometheus exposition format.
    Args:
        json_data (dict): The dictionary containing the nginx backend metrics.
        prefix (str): A prefix to add to all metric names.
    Returns:
        str: A string in Prometheus exposition format.
    """
    def sanitize_metric_name(name):
        """
        Sanitize a string to be a valid Prometheus metric name.
        Prometheus metric names must match: [a-zA-Z_:][a-zA-Z0-9_:]*
        """
        if not name:
            return "unknown"

        # Convert to string and lowercase
        name = str(name).lower()

        # Replace common separators with underscores
        name = name.replace('.', '_').replace('-', '_').replace(' ', '_')

        # Replace any other non-alphanumeric characters (except underscore and colon) with underscore
        name = re.sub(r'[^a-z0-9_:]', '_', name)

        # Remove consecutive underscores
        name = re.sub(r'_+', '_', name)

        # Remove leading/trailing underscores
        name = name.strip('_')

        # Ensure it starts with a letter or underscore (not a number)
        if name and name[0].isdigit():
            name = '_' + name

        # Ensure it's not empty after sanitization
        if not name:
            return "unknown"

        return name

    def sanitize_label_value(value):
        """
        Sanitize a label value by escaping special characters.
        Label values can contain any Unicode characters, but backslashes,
        double quotes, and line breaks must be escaped.
        """
        if value is None:
            return ""

        value = str(value)
        # Escape backslashes first, then quotes and newlines
        value = value.replace('\\', '\\\\')
        value = value.replace('"', '\\"')
        value = value.replace('\n', '\\n')

        return value

    def safe_get_value(item, key, default=0):
        """Safely get a value from a dictionary with type checking."""
        try:
            value = item.get(key, default)
            # Convert to number if possible
            if isinstance(value, (int, float)):
                return value
            elif isinstance(value, str) and value.isdigit():
                return int(value)
            else:
                logging.warning(f"Non-numeric value for '{key}': {value}, using default {default}")
                return default
        except Exception as e:
            logging.warning(f"Error getting value for key '{key}': {e}, using default {default}")
            return default

    try:
        # Input validation
        if not isinstance(json_data, dict):
            raise TypeError(f"json_data must be a dictionary, got {type(json_data)}")

        if not json_data:
            logging.warning("Empty json_data provided")
            return ""

        # Sanitize prefix
        prefix = sanitize_metric_name(prefix)

        metrics = []

        for key, value in json_data.items():
            try:
                # Sanitize key for Prometheus metric name
                sanitized_key = sanitize_metric_name(key)

                # Handle different data types
                if isinstance(value, list):
                    # Process each item in the list
                    for index, item in enumerate(value):
                        try:
                            if not isinstance(item, dict):
                                logging.warning(f"Expected dict in list for key '{key}', got {type(item)}")
                                continue

                            # Safely get and sanitize the name field
                            member_name = item.get('name', f'member_{index}')
                            sanitized_member = sanitize_label_value(member_name)

                            # Safely get status
                            status = item.get('status', 'unknown')
                            status_value = 1 if str(status).lower() == 'up' else 0

                            # Safely get connections count
                            conns = safe_get_value(item, 'conns', 0)

                            # Add metrics with sanitized labels
                            metrics.append(
                                    f'{prefix}_status{{pool="{sanitize_label_value(sanitized_key)}",'
                                    f'member="{sanitized_member}"}} {status_value}'
                                    )
                            metrics.append(
                                    f'{prefix}_connections{{pool="{sanitize_label_value(sanitized_key)}",'
                                    f'member="{sanitized_member}"}} {conns}'
                                    )
                            metrics.append("")

                        except Exception as e:
                            logging.error(f"Error processing list item {index} for key '{key}': {e}")
                            continue

                elif isinstance(value, (int, float)):
                    # Handle scalar numeric values
                    metrics.append(f"{prefix}_{sanitized_key} {value}")
                    metrics.append("")

                elif isinstance(value, dict):
                    # Handle nested dictionaries
                    logging.info(f"Nested dict found for key '{key}', skipping (not implemented)")
                    continue

                else:
                    # Log unexpected types
                    logging.warning(f"Unexpected value type for key '{key}': {type(value)}")
                    continue

            except Exception as e:
                logging.error(f"Error processing key '{key}': {e}")
                continue

        return "\n".join(metrics)

    except Exception as e:
        logging.error(f"Error in json_to_prometheus_metrics: {e}", exc_info=True)
        return ""

def stubstatus_to_prometheus_metrics(text, prefix="nginx"):
    """
    Converts output from stub_status into Prometheus exposition format.
    Args:
        text (str): The output containing the nginx metrics.
        prefix (str): A prefix to add to all metric names.
    Returns:
        str: A string in Prometheus exposition format.
    Raises:
        ValueError: If text is empty or invalid format.
    """
    try:
        # Input validation
        if not text or not isinstance(text, str):
            raise ValueError("Input text must be a non-empty string")

        metrics = []
        lines = text.splitlines()

        # Validate minimum number of lines
        if len(lines) < 4:
            raise ValueError(f"Expected at least 4 lines, got {len(lines)}")

        # Parse line 0: Active connections
        r_line0 = r"^Active connections: ([0-9]+)"
        m_line0 = re.search(r_line0, lines[0])
        if not m_line0:
            raise ValueError(f"Failed to parse active connections from line: '{lines[0]}'")
        metrics.append(f"{prefix}_connections_active {m_line0.group(1)}")

        # Parse line 2: Accepted/Handled connections and Requests
        r_line2 = r"([0-9]+) ([0-9]+) ([0-9]+)"
        m_line2 = re.search(r_line2, lines[2])
        if not m_line2:
            raise ValueError(f"Failed to parse connection stats from line: '{lines[2]}'")
        metrics.append(f"{prefix}_connections_accepted {m_line2.group(1)}")
        metrics.append(f"{prefix}_connections_handled {m_line2.group(2)}")
        metrics.append(f"{prefix}_requests_handled {m_line2.group(3)}")

        # Parse line 3: Reading/Writing/Waiting
        r_line3 = r"Reading: ([0-9]+) Writing: ([0-9]+) Waiting: ([0-9]+)"
        m_line3 = re.search(r_line3, lines[3])
        if not m_line3:
            raise ValueError(f"Failed to parse reading/writing/waiting from line: '{lines[3]}'")
        metrics.append(f"{prefix}_connections_reading {m_line3.group(1)}")
        metrics.append(f"{prefix}_connections_writing {m_line3.group(2)}")
        metrics.append(f"{prefix}_connections_waiting {m_line3.group(3)}")

        metrics.append("")
        return "\n".join(metrics)

    except IndexError as e:
        logging.error(f"Line index error in stub_status parsing: {e}")
        logging.error(f"Text received: {text}")
        raise ValueError(f"Invalid stub_status format: missing expected lines") from e

    except AttributeError as e:
        logging.error(f"Regex match error in stub_status parsing: {e}")
        raise ValueError(f"Failed to extract metrics from stub_status") from e

    except Exception as e:
        logging.error(f"Unexpected error parsing stub_status: {e}")
        raise

def fetch_nginx_endpoint(url, timeout=5):
    """
    Fetch data from nginx endpoint with error handling.

    Args:
        url (str): The endpoint URL
        timeout (int): Request timeout in seconds

    Returns:
        str: Response text, or empty string on error
    """
    try:
        response = requests.get(url, timeout=timeout)
        response.raise_for_status()
        return response.text
    except requests.exceptions.Timeout:
        logging.error(f"Timeout: Request to {url} took longer than {timeout} seconds")
    except requests.exceptions.ConnectionError:
        logging.error(f"Connection error: Could not connect to {url}")
    except requests.exceptions.HTTPError as e:
        logging.error(f"HTTP error fetching {url}: {e}")
    except requests.exceptions.RequestException as e:
        logging.error(f"Error fetching {url}: {e}")
    return ""

if __name__ == "__main__":
    try:
        REQUEST_TIMEOUT = 5

        # Convert backend to Prometheus format
        logging.info("Fetching backend status...")
        nginx_backend_text = fetch_nginx_endpoint(
                'http://127.0.0.1:7999/backendstatus?format=json',
                timeout=REQUEST_TIMEOUT
                )

        backend_metrics = ""
        if nginx_backend_text:
            try:
                backend_metrics = json_to_prometheus_metrics(json.loads(nginx_backend_text))
                logging.info("Backend metrics collected successfully")
            except (ValueError, KeyError) as e:
                logging.error(f"Error parsing backend JSON: {e}")

        # Convert stub_status to Prometheus format
        logging.info("Fetching stub status...")
        nginx_stub_text = fetch_nginx_endpoint(
                'http://127.0.0.1:7999/stub_status',
                timeout=REQUEST_TIMEOUT
                )

        stub_metrics = ""
        if nginx_stub_text:
            try:
                stub_metrics = stubstatus_to_prometheus_metrics(nginx_stub_text)
                logging.info("Stub status metrics collected successfully")
            except Exception as e:
                logging.error(f"Error parsing stub status: {e}")

        # Write metrics to file
        if stub_metrics or backend_metrics:
            combined_metrics = (stub_metrics + "\n" + backend_metrics)

            if write_prometheus_metrics_to_file(combined_metrics):
                logging.info("Metrics successfully written to file")
                sys.exit(0)
            else:
                logging.error("Failed to write metrics to file")
                sys.exit(1)
        else:
            logging.error("No metrics collected, skipping file write")
            sys.exit(1)

    except Exception as e:
        logging.error(f"Unexpected error: {e}", exc_info=True)
        sys.exit(1)
