# lld_jmxcollector.ps1

$list = (C:\tools\jmxcollector\query_jmxcollector.ps1 list)
$full_metrics = ($list | Select-String -Pattern "^$($Args[0])")
$names = ($full_metrics) -replace "^$($Args[0])","" -replace ':.*$',''
$inside = ( ($names) | ForEach-Object { $name=$_.Trim(); Write-Output "{ `"{#NAME}`":`"$name`" }" } )-join ','
"{ `"data`": [ $inside ] }"
