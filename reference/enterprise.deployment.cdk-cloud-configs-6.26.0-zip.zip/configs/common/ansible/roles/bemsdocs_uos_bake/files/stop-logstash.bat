for /f "tokens=2" %%i in ('tasklist /SVC ^| findstr LogstashService') do (
   taskkill /f /T /PID %%i
)  
