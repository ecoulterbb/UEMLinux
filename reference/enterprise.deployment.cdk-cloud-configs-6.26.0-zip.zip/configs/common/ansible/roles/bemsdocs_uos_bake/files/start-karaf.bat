rmdir /q /s C:\BEMSDocsWindows\bems\data
mkdir __upload_dir__
sc.exe start bemsdocs
sc.exe start JMXCollectorService
