for /f "tokens=2" %%i in ('tasklist /SVC ^| findstr JMXCollectorService') do (
   taskkill /f /T /PID %%i
)  
