# query_jmxcollector.ps1

$client = New-Object System.Net.Sockets.UDPClient
$endpoint = New-Object System.Net.IPEndPoint([System.Net.IPAddress]::Parse('127.0.0.1'),'12121')
$client.connect($endpoint)
$client.client.ReceiveTimeout = 500

$query = [Text.Encoding]::ASCII.GetBytes($Args[0])

[void] $client.send($query, $query.length)

Try {
  while ($true) {
    [Text.Encoding]::ASCII.GetString($client.receive([ref]$endpoint))
  }
} Catch {
}

[void] $client.close()
