# zabbix_ar.ps1
# watch zabbix logs for unencrypted connect to Zabbix
Do {
Start-Sleep -s 15
}
Until (Select-String -Path C:\tools\zabbix\zabbix_agentd.log -Pattern 'connection of type "unencrypted" is not allowed for host')

# then swap it over
((Get-Content -path C:\tools\zabbix\conf\zabbix_agentd.conf -Raw) -replace 'TLSConnect=unencrypted','TLSConnect=psk') | Set-Content -Path C:\tools\zabbix\conf\zabbix_agentd.conf

# restart service
Restart-Service 'Zabbix Agent'
