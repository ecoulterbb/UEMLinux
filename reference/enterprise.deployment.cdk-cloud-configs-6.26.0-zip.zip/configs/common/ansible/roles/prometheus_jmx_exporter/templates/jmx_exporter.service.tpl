[Unit]
Description=JMX Exporter for Prometheus for ({{ item }})
After=network.target auditd.service
StartLimitInterval=200
StartLimitBurst=3

[Service]
EnvironmentFile=/etc/default/jmx_exporter-{{ item }}
WorkingDirectory=/opt/prometheus/jmx_exporter
ExecStart=/bin/bash -c "while ! nc -v -z 127.0.0.1 ${JMXPORT} ; do sleep 5 ; done && /usr/bin/java -jar ${JAR} ${JMX_EXPORTER_PORT} ${CONFFILE} >${LOGFILE} 2>&1"
Restart=always
RestartSec=30
User=uemcloud
Group=uemcloud

[Install]
#WantedBy=multi-user.target
Alias=jmx_exporter-{{ item }}.service
